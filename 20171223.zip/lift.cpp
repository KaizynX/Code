#include <cstdio>
#include <iostream>
#include <cmath>
#define LL long long
using namespace std;
const int Maxn = 5000 +5;
const int mo = 1000000007;

int n,a,b,k;
int f[Maxn][Maxn];
// f[k][sum]
// | x - y | < | x - b |

int main()
{
	freopen("lift.in","r",stdin);
	freopen("lift.out","w",stdout);
	int dis,now,ans=0,i,j;
	scanf("%d%d%d%d",&n,&a,&b,&k);
	f[0][a]=1;
	for(i=1;i<=k;++i)
	{
		for(now=1;now<=n;++now)
		{
			if(f[i-1][now]!=0)
			{
				dis=abs(now-b);
				for(j=1;j<dis;++j)
				{
					if(now+j<=n)
					{
						f[i][now+j]=(f[i][now+j]+f[i-1][now])%mo;
					}
					if(now-j>=1)
					{
						f[i][now-j]=(f[i][now-j]+f[i-1][now])%mo;
					}
				}
			}
		}
	}
	for(int i=1;i<=n;++i)
	{
		ans=(ans+f[k][i])%mo;
	}
	printf("%d",ans);
	return 0;
}
