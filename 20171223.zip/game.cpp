#include <cstdio>
#include <iostream>
#include <algorithm>
#include <queue>
#define LL long long 
using namespace std;
const int Maxn = 100000+5;

int n,s,t,ua,ub,pa,pb,sa,sb;
int a[Maxn],b[Maxn];
LL ans;
queue<int> qs,qt;

int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int cur;
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
	{
		scanf("%d",&cur);
		a[i]=a[i-1];
		b[i]=b[i-1];
		if(cur==1)a[i]++;
		else b[i]++;//cur==2
	}
	// ����ö�ٷ�
	for(t=max(a[n],b[n]);t>=1;--t)
	{
		sa=0;sb=0;ua=0;ub=0;
		pa=lower_bound(a+1,a+1+n,ua+t)-a;
		pb=lower_bound(b+1,b+1+n,ub+t)-b;
		while(pa<n || pb<n)
		{
			if(pa<pb)
			{
				sa++;
				cur=pa;
			}
			else if(pb<pa)
			{
				sb++;
				cur=pb;
			}
			ua=a[cur];
			ub=b[cur];
			pa=lower_bound(a+1+cur,a+1+n,ua+t)-a;
			pb=lower_bound(b+1+cur,b+1+n,ub+t)-b;
		}
		if(pa==n)
		{
			sa++;
			if(sa>sb)
			{
				ans++;
				qs.push(sa);
				qt.push(t);
			}
		}
		else if(pb==n)
		{
			sb++;
			if(sb>sa)
			{
				ans++;
				qs.push(sb);
				qt.push(t);
			}
		}
	}
	printf("%lld\n",ans);
	while(ans--)
	{
		printf("%d %d\n",qs.front(),qt.front());
		qs.pop();
		qt.pop();
	}
	return 0;
}
