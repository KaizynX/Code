#include <cstdio>
#include <iostream>
#include <algorithm>
#define LL long long 
using namespace std;
const int Maxn = 1000000+5;
const int Maxr = 1000000000+5;
const int Maxb = 1000+5;

int N,R,V;
struct sub
{
	int a,b;
	bool operator < (const sub & c)const 
	{
		return b<c.b;
	}
}s[Maxn];

int getint();

int main()
{
	freopen("exam.in","r",stdin);
	freopen("exam.out","w",stdout);
	int cur;
	LL sum=0,need,neednum,canget,ans=0;
	N=getint();
	R=getint();
	V=getint();
	need=N*V;
	for(int i=1;i<=N;++i)
	{
		s[i].a=getint();
		s[i].b=getint();
		sum+=s[i].a;
	}
	sort(s+1,s+1+N);
	cur=1;
	while(sum<need)
	{
		neednum=need-sum;
		canget=R-s[cur].a;
		if(canget>neednum)
		{
			ans+=neednum*s[cur].b;
			sum+=neednum;
		}
		else
		{
			ans+=canget*s[cur].b;
			sum+=canget;
		}
		cur++;
	}
	printf("%lld",ans);
	return 0;
}

int getint()
{
	int res=0;
	char c=getchar();
	while (c<'0' || c>'9')
		c=getchar();
	while (c>='0' && c<='9')
	{
		res=res*10+c-'0';
		c=getchar();
	}
	return res;
}
