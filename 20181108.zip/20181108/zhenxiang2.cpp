#include <bits/stdc++.h>

using namespace std;

const int Maxn = 1e5+7;

int n, a[Maxn];
long long ans, f[Maxn][2];
vector<int> e[Maxn];
vector<long long> line;

long long treedp(int cur, int fa)
{
	long long secm = 0, maxx;
    for(vector<int>::iterator it = e[cur].begin(); it != e[cur].end(); ++it)
    {
        if(*it == fa) continue;
        maxx = max(treedp(*it, cur), maxx);
        // f[cur][1] = max(f[cur][1], f[*it][1]);
        if(f[*it][1] > f[cur][1])
        {
        	secm = f[cur][1];
        	f[cur][1] = f[*it][1];
		}
		else secm = max(secm, f[*it][1]);
		
		if(f[*it][2]) // *it has more than two child
        	f[cur][2] = max(f[cur][2], f[*it][2]);
    }
    
    if(secm) // cur has more than two child
	{
		secm += f[cur][1];
		line.push_back(secm);
		f[cur][2] = max(f[cur][2], secm);
	}
    f[cur][1] += a[cur];
    if(f[cur][2]) // cur has more than two child
		f[cur][2] += a[cur];
	
	ans = max(ans, max(f[cur][1], f[cur][2]));
}

int main()
{
	//freopen("zhenxiang.in", "r", stdin);
	//freopen("zhenxiang.out", "w", stdout);
	scanf("%d", &n);
	for(int i = 1; i <= n; ++i) scanf("%d", a+i);
	for(int i = 1, u, v; i < n; ++i)
	{
		scanf("%d%d", &u, &v);
		e[u].push_back(v);
		e[v].push_back(u);
	}
	treedp(1, 0);
	nth_element(line.begin(), line.end()-2, line.end());
	/*
	for(vector<long long>::iterator it = line.begin(); it != line.end(); ++it)
		printf("%lld ", *it);
		putchar('\n');
	*/
	ans = max(ans, line.back()+line[line.size()-2]);
	printf("%lld\n", ans);
	return 0;
}
