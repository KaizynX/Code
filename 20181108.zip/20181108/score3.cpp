#include <bits/stdc++.h>

using namespace std;

//const int Maxk = 1e3+7;
//const int Maxt = 1e2+7;
const int Maxk = 12;
const int Maxt = 12;
const int MOD = 1e9+7;

int a, b, k, t;
long long ans;
int c[Maxt*Maxk*2];
int *v;
// f[t][k] at t get val k

void solve(int cur, int sum)
{
	if(cur > t)
	{
		if(++v[sum] >= MOD) v[sum] -= MOD;
		return;
	}
	for(int i = -k; i <= k; ++i)
		solve(cur+1, sum+i);
}

int main()
{
	// freopen("score.in", "r", stdin);
	// freopen("score.out", "w", stdout);
	scanf("%d%d%d%d", &a, &b, &k, &t);
	v = &c[Maxt*Maxk];
	solve(1, 0);
	for(int i = -k*t; i <= k*t; ++i)
		for(int j = max(i-a+b+1, -k*t); j <= k*t; ++j)
			(ans += 1ll*v[i]*v[j]%MOD) %= MOD;
	printf("%lld\n", ans);
	return 0;
}
