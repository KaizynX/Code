#include <bits/stdc++.h>

using namespace std;

//const int Maxk = 1e3+7;
//const int Maxt = 1e2+7;
const int Maxk = 12;
const int Maxt = 12;
const int MOD = 1e9+7;

int a, b, k, t;
long long ans;
int c[Maxt][2*Maxk*Maxt];
int *f[Maxt];
// f[t][k] at t get val k

int main()
{
	// freopen("score.in", "r", stdin);
	// freopen("score.out", "w", stdout);
	scanf("%d%d%d%d", &a, &b, &k, &t);
	for(int i = 0; i <= t; ++i) f[i] = &c[i][Maxk*Maxt];
	f[0][0] = 1;
	for(int i = 1; i <= t; ++i) // at t
		for(int j = -k*i; j <= k*i; ++j) // val at t
			for(int v = -k; v <= k; ++v) // this time choose
				if(j-v >= -k*i && j-v <= k*i) // j-v last time
					(f[i][j] += f[i-1][j-v]) %= MOD;
	for(int i = -k*t; i <= k*t; ++i)
		for(int j = max(i-a+b+1, -k*t); j <= k*t; ++j)
			(ans += 1ll*f[t][i]*f[t][j]%MOD) %= MOD;
	printf("%lld\n", ans);
	return 0;
}
