#include <bits/stdc++.h>

using namespace std;

const int Maxn = 1e5+7;

int n, k;
int a[Maxn];

inline void print(int *x)
{
	for(int i = 1; i < n; ++i)
		printf("%d ", x[i]);
	printf("%d\n", x[n]);
}

int main()
{
	freopen("magic.in", "r", stdin);
	freopen("magic.out", "w", stdout);
	scanf("%d%d", &n, &k);
	for(int i = 1; i <= n; ++i) scanf("%d", a+i);
	if(k == 1)
	{
		for(int i = 1; i <= n; ++i) a[i] = i;
		print(a);
		return 0;
	}
	for(int i, j, flag = 1; flag;)
		for(i = 1, flag = 0; (j = i+k) <= n; ++i)
			for(; j <= n; ++j)
				if(a[j] < a[i] && a[i]-a[j] == 1)
					swap(a[i], a[j]), flag = 1;
	print(a);
	return 0;
}
