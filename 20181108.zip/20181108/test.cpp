#include <bits/stdc++.h>

using namespace std;

const int Maxn = 1e5+7;

int n, a[Maxn];
long long ans, f[Maxn][2];
vector<int> e[Maxn];
vector<long long> line;

int main()
{
	//freopen("zhenxiang.in", "r", stdin);
	//freopen("zhenxiang.out", "w", stdout);
	line.push_back(5);
	line.push_back(0);
	line.push_back(0);
	line.push_back(2);
	line.push_back(1);
	nth_element(line.begin(), line.begin()+2, line.end());
	for(vector<long long>::iterator it = line.begin(); it != line.end(); ++it)
		printf("%lld ", *it);
	return 0;
}
