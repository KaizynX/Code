#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#define DEBUG

using namespace std;

const int Maxn = 5e3+7;

int T, n, r, ans, choose;
int tr[Maxn];

struct Weapen { int at, de; } a[Maxn];
bool cmp_a(const Weapen &x, const Weapen &y) { return x.at < y.at; }
bool cmp_d(const Weapen &x, const Weapen &y) { return x.de > y.de; }

inline void update(int x)
{
	for( ; x <= n; x += x&-x) tr[x]++;
}

inline int query(int x)
{
	int res = 0;
	for( ; x; x -= x&-x) res += tr[x];
	return res;
}

int main()
{
	//freopen("submax.in", "r", stdin);
	//freopen("submax.out", "w", stdout);
	scanf("%d", &T);
	while(T--)
	{
		scanf("%d%d", &n, &r);
		for(int i = 1; i <= n; ++i)
			scanf("%d", &a[i].at);
		for(int i = 1; i <= n; ++i)
			scanf("%d", &a[i].de);

		ans = 0;
		choose = n/(r+1) + (n%(r+1) != 0);
		memset(tr, 0, sizeof(int)*(n+1));
		// ��ɢ��������
		sort(a+1, a+n+1, cmp_a);
		for(int i = 1; i <= n; ++i)
			a[i].at = i;
		// ̰��
		sort(a+1, a+n+1, cmp_d);
		for(int i = 1, cnt = 0; cnt < choose; ++i)
		{
			if(query(a[i].at)+1 <= a[i].at/(r+1))
			{
				update(a[i].at);
				ans += a[i].de;
			}
		}
		printf("%d\n", ans);
	}
	return 0;
}
