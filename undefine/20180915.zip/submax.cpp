#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>

using namespace std;

const int Maxn = 5e3+7;

int T, n, r, ans, choose, fa[Maxn];

struct Weapen { int at, de; } a[Maxn];
bool cmp_a(const Weapen &x, const Weapen &y) { return x.at < y.at; }
bool cmp_d(const Weapen &x, const Weapen &y) { return x.de > y.de; }
int getf(int s) { return fa[s] == s ? s : fa[s] = getf(fa[s]); }

int main()
{
	//freopen("submax.in", "r", stdin);
	//freopen("submax.out", "w", stdout);
	scanf("%d", &T);
	while(T--)
	{
		scanf("%d%d", &n, &r);
		for(int i = 1; i <= n; ++i)
			scanf("%d", &a[i].at);
		for(int i = 1; i <= n; ++i)
			scanf("%d", &a[i].de);

		ans = 0;
		choose = n/(r+1) + (n%(r+1) != 0);
		for(int i = 1; i <= n; ++i) fa[i] = i;
		// ��ɢ��������
		sort(a+1, a+n+1, cmp_a);
		for(int i = 1; i <= n; ++i)
			a[i].at = i;
		// the biggest one must choose
		ans += a[n].de;
		// and the biggest one set at last group
		fa[choose] = choose-1;

		sort(a+1, a+n+1, cmp_d);
		for(int i = 1, cnt = 0; i <= n; ++i)
		{
			if(a[i].at == n) continue;
			int tmp = a[i].at/(r+1);
			int fx = getf(tmp);
			if(fx)
			{
				ans += a[i].de;
				fa[fx] = getf(fx-1);
				++cnt;
			}
			if(cnt >= choose) break;
		}
		printf("%d\n", ans);
	}
	return 0;
}
