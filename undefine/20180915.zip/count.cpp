#include <cstdio>
#include <iostream>

using namespace std;

const int Maxm = 30;

int m;
long long n, ans, a[Maxm];

long long gcd(long long a, long long b)
{
	return b == 0 ? a : gcd(b, a%b);
}

int main()
{
	freopen("count.in", "r", stdin);
	freopen("count.out", "w", stdout);
	scanf("%lld%d", &n, &m);
	for(int i = 0; i < m; ++i)
		scanf("%lld", a+i);
	long long lcm;
	for(int i = 1, cnt; i < (1<<m); ++i)
	{
		cnt = 0;
		lcm = 0;
		for(int j = 0; j < m; ++j)
			if(i & (1<<j))
			{
				if(cnt == 0) lcm = a[j];
				else lcm = lcm*a[j]/gcd(lcm, a[j]);
				++cnt;
			}
		ans += (n/lcm)*(cnt&1 ? 1 : -1);
	}
	printf("%lld\n", n-ans);
	return 0;
}
