#include <cstdio>
#include <iostream>
#include <algorithm>

using namespace std;

const int Maxn = 5e3+7;

int n, k, a[Maxn];
int v[Maxn*Maxn], cnt;

int find_kth(int l, int r, int k)
{
	int i = l, j = r;
	int xxxl = l+rand()%(r-l+1);
	swap(v[i], v[xxxl]);
	int key = v[i];
	while(i < j)
	{
		while(i < j && v[j] < key) j--;
		v[i] = v[j];
		while(i < j && v[i] >= key) i++;
		v[j] = v[i];
	}
	v[i] = key;
	if(i == k) return key;
	else if(i > k) return find_kth(l, i-1, k);
	else return find_kth(i+1, r, k);
}

int main()
{
	freopen("kth.in", "r", stdin);
	freopen("kth.out", "w", stdout);
	scanf("%d%d", &n, &k);
	for(int i = 1; i <= n; ++i)
		scanf("%d", a+i);
	for(int l = 1, maxv, minv; l <= n; ++l)
	{
		maxv = minv = a[l];
		for(int r = l; r <= n; ++r)
		{
			if(a[r] < minv) minv = a[r];
			if(a[r] > maxv) maxv = a[r];
			v[++cnt] = maxv-minv;
		}
	}
	printf("%d\n", find_kth(1, cnt, k));
	return 0;
}
