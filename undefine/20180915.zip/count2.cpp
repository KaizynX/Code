#include <cstdio>
#include <iostream>
#define DEBUG

using namespace std;

const int Maxm = 30;

int m;
long long n, ans, a[Maxm];

long long gcd(long long a, long long b)
{
	return b == 0 ? a : gcd(b, a%b);
}

int main()
{
	//freopen("count.in", "r", stdin);
	//freopen("count.out", "w", stdout);
	scanf("%lld%d", &n, &m);
	for(int i = 0; i < m; ++i)
		scanf("%lld", a+i);
	for(int i = 1, cnt; i < (1<<m); ++i)
	{
		cnt = 0;
		long long mul = 1, lcm, gccd = 0;
		for(int j = 0; j < m; ++j)
			if(i & (1<<j))
			{
				mul *= a[j];
				gccd = gcd(a[j], gccd);
				++cnt;
			}
		lcm = mul/gccd;
		ans += (n/lcm)*(cnt&1 ? 1 : -1);
#ifdef DEBUG
		printf("gcd:%lld lcm:%lld ans:%lld\n", gccd, mul, ans);
#endif
	}
	printf("%lld\n", n-ans);
	return 0;
}
