#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
template<class T>inline void print(T x){
	static int stk[105],top;
	if(x==0)putchar('0');
	while(x)stk[++top]=x%10,x/=10;
	while(top)putchar(stk[top--]+'0');
}
const int M=2e6+5;
struct node{
	int l,r,v;
	bool operator <(const node &A)const{
		return v<A.v;
	}
}A[M];
int cas,n,m,fa[M];
int getfa(int x){
	int y = x;
	while (y != fa[y]) y = fa[y];
	while (x != y) {
		int t = fa[x];
		fa[x] = y, x = t;
	}
	return y;
}
signed main(){
	scanf("%d",&cas);
	for(int _=1;_<=cas;_++){
		scanf("%d%d",&n,&m);
		for(int i=1;i<=m;i++)scanf("%d%d%d",&A[i].l,&A[i].r,&A[i].v);
		for(int i=1;i<=n+2;i++)fa[i]=i;
		sort(A+1,A+1+m);
		__int128 res=0;
		for(int i=1;i<=m;i++){
			int l=A[i].l,r=A[i].r,v=A[i].v;
			res+=1ll*(r-l)*(r-l+1)/2*v;
			int x=getfa(l);
			while(x<r){
				fa[x]=getfa(x+1);
				res-=v;
				x=getfa(x);
			}
		}
		if(getfa(1)==getfa(n))printf("Case #%d: ",_),print(res);
		else printf("Case #%d: Gotta prepare a lesson",_);
		if(_!=cas)puts("");
	}
	return 0;
}


