#include <bits/stdc++.h>
//#define DEBUG
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
const int N = 1e5+7;

int n, m;
vector<int> e[N];

void solve() {
	scanf("%d%d", &n, &m);
	for (int i = 1, D; i <= n; ++i) {
		scanf("%d", &D);
		e[i].resize(D);
		for (int j = 0; j < D; ++j) scanf("%d", &e[i][j]);
	}
	for (int i = 1, S, L; i <= m; ++i) {
		scanf("%d%d", &S, &L);
		for (int j = 1, R; j <= L; ++j) {
			scanf("%d", &R);
			if (R > (int)e[S].size()) S = 0;
			else S = e[S][R-1]; 
		}
		if (S == 0) printf("Packet Loss");
		else printf("%d", S);
		if (i < m) puts("");
	}
}

signed main() {
	int T;
	scanf("%d", &T);
	for (int i = 1; i <= T; ++i) {
		printf("Case #%d: \n", i);
		solve();
		for (int i = 1; i <= n; ++i) {
			e[i] = vector<int>();
		}
		if (i < T) puts("");
	}
	return 0;
}
