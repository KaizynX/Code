#include <bits/stdc++.h>
//#define DEBUG
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
const int N = 1e5+7;

int n, k;
int a[N], p[N], cnt[N];
set<int> ids;
set<pii> q;

inline int get_id(int t) {
	if (ids.empty()) return -1;
	t %= k;
	auto it = ids.lower_bound(t);
	if (it == ids.end()) return *ids.begin();
	else return *it;	
}

signed main() {
	scanf("%d%d", &k, &n);
	for (int i = 0; i < k; ++i) ids.insert(i);
	for (int i = 0; i < n; ++i) {
		scanf("%d%d", a+i, p+i);
		while (q.size() && q.begin()->first <= a[i]) {
			ids.insert(q.begin()->second);
			q.erase(q.begin());
		}
		int id = get_id(i);
	#ifdef DEBUG
	cout << id << '\n';
	#endif
		if (id == -1) continue;
		++cnt[id];
		ids.erase(id);
		q.insert(pii{a[i]+p[i], id});
	}
	#ifdef DEBUG
	for (int i = 0; i < k; ++i) cout << cnt[i] << " \n"[i==k-1];
	#endif
	int mx = *max_element(cnt, cnt+k);
	for (int i = 0, fir = 1; i < k; ++i) if (cnt[i] == mx) {
		if (!fir) putchar(' ');
		printf("%d", i);
		fir = 0;
	}
	return 0;
}
