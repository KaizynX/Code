#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int M=1e5+5;
int n,OP[M],X[M],Y[M],cnt_s,cnt_t;
bitset<15005>SS[M],TT[M];
vector<int>E1[M],E2[M];
int de[M],Q[M],S[M],T[M],del[M],ans[M];
void add_edge(int a,int b){
	if(del[a]||del[b])return;
	E1[a].push_back(b);
	E2[b].push_back(a);
}
void rebuild(){
	for(int i=1;i<=n;i++)if(S[i]==0||T[i]==0)del[i]=1;
	for(int i=1;i<=n;i++)E1[i].clear(),E2[i].clear();
	for(int i=1;i<=n;i++)if(OP[i]==1)add_edge(X[i],Y[i]);
}
int mark[M],mark_S[M],mark_T[M];
int res_S[M*100],cnt_S[M*100],sum_S[M*100];
int res_T[M*100],cnt_T[M*100],sum_T[M*100];
void solve_S(int x,int c,int s,int r){
	if(del[x])return;
	if(mark_S[x])cnt_s++,cnt_S[cnt_s]=c,sum_S[cnt_s]=s,res_S[cnt_s]=r;
	c++;
	s+=x;
	r+=s;
	for(auto y:E2[x])solve_S(y,c,s,r);
}
void solve_T(int x,int c,int s,int r){
	if(del[x])return;
	if(mark_T[x])cnt_t++,cnt_T[cnt_t]=c,sum_T[cnt_t]=s,res_T[cnt_t]=r;
	c++;
	s+=x;
	r+=c*x;
	for(auto y:E1[x])solve_T(y,c,s,r);
}
void clean_S(int x,int v){
	if(del[x])return;
	T[x]-=v;
	if(T[x]==0)del[x]=1;
	for(auto y:E2[x])clean_S(y,v);
}
void clean_T(int x,int v){
	if(del[x])return;
	S[x]-=v;
	if(S[x]==0)del[x]=1;
	for(auto y:E1[x])clean_T(y,v);
}
signed main(){
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&OP[i]);
		if(OP[i]==1){
			scanf("%d%d",&X[i],&Y[i]);
			add_edge(X[i],Y[i]);
			de[Y[i]]++;
		}
		else if(OP[i]==2){
			scanf("%d",&X[i]);
			SS[X[i]][++cnt_s]=1;
			mark_S[X[i]]=1;
		}
		else if(OP[i]==3){
			scanf("%d",&X[i]);
			TT[X[i]][++cnt_t]=1;
			mark_T[X[i]]=1;
		}
		else{
			
		}
	}
	int L=0,R=0;
	for(int i=1;i<=n;i++)if(de[i]==0)Q[++R]=i;
	while(L<R){
		int x=Q[++L];
		for(auto y:E1[x]){
			de[y]--;
			if(de[y]==0)Q[++R]=y;
		}
	}
	for(int i=1;i<=n;i++){
		int x=Q[i];
		for(auto y:E2[x])SS[x]|=SS[y];
	}
	for(int i=n;i>=1;i--){
		int x=Q[i];
		for(auto y:E1[x])TT[x]|=TT[y];
	}
	for(int i=1;i<=n;i++)S[i]=SS[i].count();
	for(int i=1;i<=n;i++)T[i]=TT[i].count();
	rebuild();
	int now=0;
	for(int i=n;i>=1;i--){
		int op=OP[i],x=X[i],y=Y[i];
		if(op==1){
			if(del[x]||del[y])continue;
			cnt_s=cnt_t=0;
			solve_S(x,0,0,0);
			solve_T(y,0,0,0);
			for(int i=1;i<=cnt_s;i++)for(int j=1;j<=cnt_t;j++)
				now^=res_S[i]+res_T[j]+cnt_S[i]*sum_T[j];
			clean_S(x,cnt_t);
			clean_T(y,cnt_s);
		}
		else if(op==2){
			if(del[x])continue;
			cnt_s=cnt_t=0;
			solve_T(x,0,0,0);
			for(int j=1;j<=cnt_t;j++)now^=res_T[j];
			clean_T(x,1);
		}
		else if(op==3){
			if(del[x])continue;
			cnt_s=cnt_t=0;
			solve_S(x,0,0,0);
			for(int i=1;i<=cnt_s;i++)now^=res_S[i];
			clean_S(x,1);
		}
		else ans[i]=now;
		if(i%1000==0)rebuild();
	}
	int f=0;
	for(int i=1;i<=n;i++)if(OP[i]==4){
		if(f)puts("");
		f=1;
		printf("%d",ans[i]^now);
	}
	return 0;
}
/*
13
1 2 1
1 1 4
1 4 3
2 2
3 3
4
1 1 5
3 5
1 6 4
4
2 6
1 5 3
4
*/
