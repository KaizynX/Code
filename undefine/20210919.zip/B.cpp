#include <bits/stdc++.h>
//#define DEBUG
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
const int N = 1e5+7;

struct vec {
	ll x, y;
	vec operator-(const vec &b) const { return {x - b.x, y - b.y}; }
	ll sqr() { return x * x + y * y; }
	friend ll cross(vec a, vec b) {
		return a.x * b.y - a.y * b.x;
	}
	friend ll cross(vec a, vec b, vec c) {
		return cross(a - c, b - c);
	}
} a[N];
int n;
vector<vec> st;
void push(vec &v, int b) {
	while ((int)st.size() > b &&
		cross(*++st.rbegin(), st.back(), v) <= 0)
		st.pop_back();
	st.push_back(v); 
}
void convex() {
	st.clear();
	sort(a, a + n, [](vec a, vec b) {
		return make_pair(a.x, a.y) < make_pair(b.x, b.y);
	});
	for (int i = 0; i < n; i++) push(a[i], 1);
	int b = st.size();
	for (int i = n - 2; i >= 0; i--) push(a[i], b);
}
ll A[N];
signed main() {
	scanf("%lld", &A[n++]);
	while (scanf(",%lld", &A[n++]) == 1);
	n--;
	if (n <= 4) { printf("ERROR"); return 0; }
	if (n % 2 == 1) { printf("ERROR"); return 0; }
	for (int i = 0; i < n; i += 2) {
		a[i / 2].x = A[i];
		a[i / 2].y = A[i + 1];
	}
	n /= 2;
	for (int i = 0; i < n; i++)
	for (int j = i + 1; j < n; j++)
	for (int k = j + 1; k < n; k++) {
		if (cross(a[i], a[j], a[k]) == 0) {
			printf("ERROR");
			return 0;
		}
	}
	convex(); st.pop_back();
//	cout << st.size() << endl;
	
	if ((int)st.size() != n) { printf("ERROR"); return 0; }
	
	reverse(st.begin(), st.end());
	int p = 0;
	for (int i = 0; i < n; i++) {
		if (st[i].sqr() < st[p].sqr())
			p = i;
	}
	rotate(st.begin(), st.begin() + p, st.end());
	for (int i = 0; i < (int)st.size() - 1; i++) printf("%lld,%lld,", st[i].x, st[i].y);
	printf("%lld,%lld", st.back().x, st.back().y);
	return 0;
}
