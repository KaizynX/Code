#include <bits/stdc++.h>
//#define DEBUG
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
const int N = 1e5+7;
#define repeat(i, a, b) for (int i = a, ib = b; i < ib; i++)
#define repeat_back(i, a, b) for (int i = b - 1; ib = a; i >= ib; i--)
ll read() { ll x; scanf("%lld", &x); return x; }
vector<int> a[N];
stack<int> stk;
bool vis[N], instk[N];
int dfn[N], low[N], co[N], w[N];
vector<int> sz;
int n, dcnt;
void dfs(int x) {
	vis[x] = instk[x] = 1; stk.push(x);
	dfn[x] = low[x] = ++dcnt;
	for (auto p : a[x]) {
		if (!vis[p]) dfs(p);
		if (instk[p]) low[x] = min(low[x], low[p]);
	}
	if (low[x] == dfn[x]) {
		int t; sz.push_back(0);
		do {
			t = stk.top();
			stk.pop();
			instk[t] = 0;
			sz.back() += w[t];
			co[t] = sz.size() - 1;
		} while (t != x);
	}
}
void getscc() {
	fill(vis, vis + n, 0);
	sz.clear();
	repeat (i, 0, n) if (!vis[i]) dfs(i);
}
void shrink() {
	static vector<pii> eset;
	eset.clear();
	getscc();
	repeat (i, 0, n)
	for (auto p : a[i])
	if (co[i] != co[p])
		eset.push_back({co[i], co[p]});
	n = sz.size();
	repeat (i, 0, n) {
		a[i].clear();
		w[i] = sz[i];
	}
	for (auto i : eset) {
		a[i.first].push_back(i.second);
	}
}
ll readx() {
	int c = getchar(); while (!isalpha(c)) c = getchar();
	ll x = 0;
	char cx = getchar();
	while (isdigit(cx)) {
		x = x * 10 + cx - '0';
		cx = getchar();
	}
	ungetc(cx, stdin);
//	cout << "readx: " << (char)c << x << endl;
	return x * 26 + (c - 'A');
}
ll readx2() {
	int c = 0;
	while (!isalpha(c)) { c = getchar(); if (c == -1 || c == '\n' || c == ':') return -1; }
	ll x = 0;
	char cx = getchar();
	while (isdigit(cx)) {
		x = x * 10 + cx - '0';
		cx = getchar();
	}
	ungetc(cx, stdin);
//	cout << "readx2: " << (char)c << x << endl;
	return x * 26 + (c - 'A');
}
map<ll, int> id;
namespace lca {
	int dep[N], son[N], sz[N], top[N], fa[N], dfn[N];
	int dcnt = 0;
	void dfs1(int x) {
		dfn[x] = ++dcnt;
		sz[x] = 1; son[x] = -1;
		dep[x] = dep[fa[x]] + 1;
		for (auto p : a[x]) {
			if (p == fa[x]) continue;
			fa[p] = x; dfs1(p);
			sz[x] += sz[p];
			if (son[x] == -1 || sz[son[x]] < sz[p])
				son[x] = p; 
		}
	}
	void dfs2(int x, int tv) {
		top[x] = tv;
		if (son[x] == -1) return;
		dfs2(son[x], tv);
		for (auto p : a[x]) {
			if (p == fa[x] || p == son[x]) continue;
			dfs2(p, p);
		}
	}
	void init(int s) {
		fa[s] = s;
		dfs1(s); dfs2(s, s);
	}
	int lca(int x, int y) {
		while (top[x] != top[y])
		if (dep[top[x]] >= dep[top[y]]) x = fa[top[x]];
		else y = fa[top[y]];
		return dep[x] < dep[y] ? x : y;
	}
}
signed main() {
	int T = read();
	repeat (ca, 1, T + 1) {
		n = read(); id.clear();
		repeat (i, 0, n + 1) a[i].clear(); 
		repeat (i, 0, n) {
			id[readx()] = i; getchar();
			int t;
			while ((t = readx2()) != -1) {
//				cout << i << "-" << t << endl; 
				a[i].push_back(t);
			}
			a[n].push_back(i);
		}
		repeat (i, 0, n) for (auto &j : a[i]) j = id[j];
		int rt = n; 
		n++;
		repeat (i, 0, n) {
			cout << i << ": "; 
			for (auto &j : a[i]) cout << j << ' ';
			cout << endl;
		}
		shrink();
		rt = co[rt];
		cout << "rt: " << rt << endl; ///////////// 
		lca::init(rt);
		repeat (i, 0, n) { ///////////////
			cout << i << ": "; 
			for (auto &j : a[i]) cout << j << ' ';
			cout << endl;
		}
		printf("Case #%d:\n", ca);
		int q = read(); while (1) { int c = getchar(); if (c == -1 || c == '\n') break; }
//		cout << ">> q: " << q << endl; 
		while (q--) {
			int t; int ans = 0;
			vector<int> v;
			while ((t = readx2()) != -1) {
//				cout << i << "-" << t << endl; 
				v.push_back(co[id[t]]);
			}
			sort(v.begin(), v.end(), [](int x, int y) {
				return lca::dfn[x] < lca::dfn[y];
			});
			int rx = readx(); while (1) { int c = getchar(); if (c == -1 || c == '\n') break; }
			int ss = co[id[rx]];
			repeat (i, 0, v.size() - 1) {
				int l = lca::lca(v[i], v[i + 1]);
				if (l == v[i] || l == v[i + 1]) {
					puts("Invalid");
					goto cont;
				}
			}
			repeat (i, 0, v.size()) {
				int l = lca::lca(v[i], ss);
				cout << "ask: " << v[i] << ' ' << ss << ' ' << l << endl;  
				if (l == v[i]) ans = 1;
			}
			puts(ans ? "Yes" : "No");
//			cout << v.size() << char(rx % 26 + 'A') << rx / 26 << endl;
			cont:
			;
		}
	}
	return 0;
}
