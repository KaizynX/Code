#include <bits/stdc++.h>
//#define DEBUG
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
const int N = 1e5+7;

ll a[N];
signed main() {
	int n = 0;
	while (scanf("%lld", &a[n++]) == 1); n--;
	n -= 2;
	sort(a, a + n, greater<ll>());
	ll x = a[n], r = a[n + 1];
	int f = 0;
	for (int i = 0; i < n; i++) {
		if (abs(a[i] - x) <= r) {
			printf("%lld ", a[i]);
			f = 1;
		}
	}
	if (f == 0) puts("");
	return 0;
}


