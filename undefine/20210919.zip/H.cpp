#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int n,m,L;
map<int,vector<int>>vi,Q;
vector<int>ans;

signed main(){
	scanf("%d%d",&n,&m);
	int id,op,a,b,c;
	double x,y,z;
	for(int i=1;i<=n;i++)cin>>id>>x>>y>>z;
	for(int i=1;i<=m;i++){
		scanf("%d%d",&id,&op);
		if(op==102){
			scanf("%d%d",&a,&b);
			vi[id].push_back(a);
			vi[id].push_back(b);
			Q[a].push_back(id);
			Q[b].push_back(id);
		}
		else{
			scanf("%d%d%d",&a,&b,&c);
			vi[id].push_back(a);
			vi[id].push_back(b);
			vi[id].push_back(c);
			Q[a].push_back(id);
			Q[b].push_back(id);
			Q[c].push_back(id);
		}
	}
	scanf("%d",&L);
	for(int _=1;_<=L;_++){
		scanf("%d",&id);
		printf("%d\n",id);
		ans.clear();
		for(auto x:Q[id])for(auto y:vi[x])if(y!=id)ans.push_back(y);
		sort(ans.begin(),ans.end());
		ans.erase(unique(ans.begin(),ans.end()),ans.end());
		printf("[");
		for(int i=0;i<ans.size();i++){
			printf("%d",ans[i]);
			if(i<ans.size()-1)printf(",");
		}
		printf("]\n");
		
		
		ans.clear();
		for(auto x:Q[id])ans.push_back(x);
		sort(ans.begin(),ans.end());
		printf("[");
		for(int i=0;i<ans.size();i++){
			printf("%d",ans[i]);
			if(i<ans.size()-1)printf(",");
		}
		printf("]");
		sort(ans.begin(),ans.end());
		ans.erase(unique(ans.begin(),ans.end()),ans.end());
		if(_!=L)puts("");
	}
	return 0;
}


