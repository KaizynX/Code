#include <bits/stdc++.h>
//#define DEBUG
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
const int N = 1e5+7;

int n, m;
unsigned des[N][4], mask[N], nex[N][4];

struct TireTree {
	static const int M = N*32;
	int nex[M][2], id[M], cnt;
	void insert(unsigned x, unsigned mask, int iii) {
		int p = 0;
		for (int i = 31; i >= 0; --i) {
			if (31-i == mask) id[p] = iii;
			int b = (x>>i)&1;
			if (!nex[p][b]) nex[p][b] = ++cnt;
			p = nex[p][b];
		}
		if (mask == 32) id[p] = iii;
	}
	int query(unsigned x) {
		int p = 0, ans = id[0];
		for (int i = 31; i >= 0; --i) {
			int b = (x>>i)&1;
			p = nex[p][b];
			if (!p) break;
			if (id[p]) ans = id[p];
		}
		return ans;
	}
} tree;

void read(unsigned *a) {
	scanf("%u.%u.%u.%u", a, a+1, a+2, a+3);
}

unsigned magic(unsigned *a) {
	return (a[0]<<24)+(a[1]<<16)+(a[2]<<8)+a[3];
}

signed main() {
	scanf("%d", &n);
	for (int i = 1; i <= n; ++i) {
		read(des[i]);
		scanf("%u", mask+i);
		read(nex[i]);
		tree.insert(magic(des[i]), mask[i], i);
//		printf("%u\n", magic(des[i]));///////
	}
	scanf("%d", &m);
	unsigned a[4];
	for (int i = 1; i <= m; ++i) {
		read(a);
//		printf("%u\n", magic(a));/////
		int id = tree.query(magic(a));
		printf("%u.%u.%u.%u", nex[id][0], nex[id][1], nex[id][2], nex[id][3]);
		if (i < m) puts("");
	}
	return 0;

