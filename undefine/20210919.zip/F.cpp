#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int cas,a,b,r;

signed main(){
	scanf("%d",&cas);
	for(int _=1;_<=cas;_++){
		scanf("%d%d%d",&a,&b,&r);
		double res;
		if(b<=r)res=a+a-r;
		else res=2.0*sqrt(1ll*a*a+1ll*(b-r)*(b-r))-r;
		printf("Case #%d: %.2lf",_,res);
		if(_!=cas)puts(""); 
	}
	return 0;
}


