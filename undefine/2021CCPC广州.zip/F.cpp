#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll read() { ll x; scanf("%lld", &x); return x; }
const int N = 3e5+7, mod = 998244353;
#define int ll
#define repeat(i, a, b) for (int i = a, ib = b; i < ib; i++)
int f[N] = {0, 1, 2, 13, 123, 1000, 123456};
ll qpow(ll a, ll p) {
	ll ans = 1;
	while (p) {
		if (p&1) ans = ans*a%mod;
		a = a*a%mod;
		p >>= 1;
	}
	return ans;
}
int calc(int n) {
	ll ans = 0;
	repeat (i, 1, n + 1) {
		ll prod = 1;
		repeat (j, 1, n + 1) if (i != j) {
			prod = prod * (1 + f[i] + mod - f[i] * f[j] % mod) % mod * qpow(f[i] + mod - f[j], mod - 2) % mod;
		}
		cout << n << ' ' << i << ' ' << prod << endl;
		ans = (ans + prod) % mod;
	}
	return ans;
}

signed main() {
	int n = read(); n--;
	int a = 1, b = 1;
	while (n--) {
		tie(a, b) = make_pair(b, (a + b) % mod);
	}
	printf("%lld\n", a);
	return 0;
}
