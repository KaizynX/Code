#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int M=2e5+5;
const int mod=998244353;
int n,m,q,p;

ll qpow(ll a, ll p) {
	ll ans = 1;
	while (p) {
		if (p&1) ans = ans*a%mod;
		a = a*a%mod;
		p >>= 1;
	}
	return ans;
}

int ptot, prime[M], pre[M];
void init_prime(){
	for (int i = 2; i < M; ++i) {
		if (!pre[i]) prime[++ptot]=pre[i]=i;
		for (int j = 1;j<=ptot;++j){
			int t = i*prime[j];
			if (t >= M) break;
			pre[t]=prime[j];
			if(i%prime[j] == 0)break;
		}
	}
}

ll pk[M][20], pkn[M][20];
void init_pk(){
	for (int i = 1, p; i <= ptot; ++i) {
		ll v = 1;
		p = prime[i];
		for (int j = 0; v <= m; ++j, v *= p) {
			pk[p][j] = v;
			if (j) (pk[p][j] += pk[p][j-1]) %= mod;
			pkn[p][j] = qpow(pk[p][j], n);
		}
	}
}

ll f[M];
void init_f(){
	for (int i = 1, x, k, y; i <= m; ++i) {
		x = i;
		f[i] = 1;
		while (pre[x] > 1) {
			k = 0;
			y = pre[x];
			while (x%y == 0) x /= y, ++k;
			f[i] = f[i]*(pkn[y][k]-pkn[y][k-1]+mod)%mod;
		}
	}
}

ll tmp[M], ans[M];

int main(){
	init_prime();
	scanf("%d%d%d%d",&n,&m,&p,&q);
	init_pk();
	init_f();
	for (int i = 1; i <= m; ++i) {
		tmp[i] = qpow((1ll+m/i)*(m/i)/2%mod, n);
		for (int lcm = i; lcm < p; lcm += i) {
			tmp[i] = (tmp[i]-f[lcm/i]+mod)%mod;
		}
		tmp[i] = tmp[i]*qpow(i, n)%mod;
	}
	ll res = 0;
	for (int i = m; i; --i) {
		ans[i] = tmp[i];
		for (int j = i*2; j <= m; j += i) {
			ans[i] = (ans[i]-ans[j]+mod)%mod;
		}
		if (i <= q) res = (res+ans[i])%mod;
	}
//	for (int i = 1; i <= m; ++i) printf("%lld%c", tmp[i], " \n"[i==m]);
//	for (int i = 1; i <= m; ++i) printf("%lld%c", ans[i], " \n"[i==m]);
	printf("%lld\n", (res%mod+mod)%mod);
	return 0;
}
