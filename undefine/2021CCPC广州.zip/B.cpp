#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll read() { ll x; scanf("%lld", &x); return x; }
#define repeat(i, a, b) for (int i = a, ib = b; i < ib; i++)
int c[N], d[N];
struct zkw
int main() {
	int n = read();
	repeat (i, 1, n + 1) c[i] = read();
	repeat (i, 1, n) d[i] = read();
	
}
