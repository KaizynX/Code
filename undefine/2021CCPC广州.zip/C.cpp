#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define gc()(is==it?it=(is=in)+fread(in,1,Q,stdin),(is==it?EOF:*is++):*is++)
const int Q=(1<<24)+1;
char in[Q],*is=in,*it=in,c;
template<class T>inline void rd(T &n){
  for(n=0;(c=gc())<'0'||c>'9';);
  for(;c<='9'&&c>='0';c=gc())n=n*10+c-48;
}
const int M=1e6+5;
ll n,A[M],L[M],R[M];
int m;
bool check(ll mid){
	R[0]=A[1]-1;
	A[m+1]=2e18;
	A[0]=-2e18;
	for(int i=1;i<=m;i++){
		L[i]=R[i-1]+1;
		R[i]=min(L[i]+mid-1,A[i+1]-1);
		if(R[i]<A[i])return 0;
	}
//	for(int i=1;i<=m;i++)printf("%d : %d %d\n",i,L[i],R[i]);
	if(R[m]-A[m]>=n-A[m]+A[1]-1)return 1;
	int pos=-1;
	for(int i=m;i>=1;i--)if(R[i]-L[i]+1<mid){pos=i;break;}
	if(pos==-1)return 0;
	for(int i=pos;i>=1;i--){
		R[i]=L[i+1]-1;
		L[i]=max(R[i]-mid+1,A[i-1]+1);
		if(L[i]>A[i])return 0;
	}
	return R[m]-A[m]+A[1]-L[1]>=n-A[m]+A[1]-1;
}
int main(){
	rd(n),rd(m);
	for(int i=1;i<=m;i++)rd(A[i]);
	if(m==1){printf("%lld\n",n);return 0;}
	ll l=1,r=n,res=0;
	while(l<=r){
		ll mid=(l+r)/2;
		if(check(mid))res=mid,r=mid-1;
		else l=mid+1;
	}
	printf("%lld\n",res);
	return 0;
}
