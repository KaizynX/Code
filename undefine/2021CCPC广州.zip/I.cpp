#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
const int mod = 998244353;

ll qpow(ll a, ll p) {
	ll ans = 1;
	while (p) {
		if (p&1) ans = ans*a%mod;
		a = a*a%mod;
		p >>= 1;
	}
	return ans;
}

int n;

signed main() {
	int T = 1;
	scanf("%d", &T);
	while (T--) {
		scanf("%d", &n);
		if (n == 1) puts("1");
		else if (n == 2) puts("2");
		else if (n == 3) puts("6");
		else printf("%lld\n", qpow(2, n-3)*6%mod);
	}
	return 0;
}
