#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
const int mod = 998244353;

ll qpow(ll a, ll p) {
	ll ans = 1;
	while (p) {
		if (p&1) ans = ans*a%mod;
		a = a*a%mod;
		p >>= 1;
	}
	return ans;
}

ll a, b, c, x, y, z;
bool ok() {
//	printf(">%lld %lld %lld\n", x, y, z);
	return x && y && z && x % y == a && y % z == b && z % x == c;
}
bool work(ll &x, ll &y, ll &z, ll a, ll b, ll c) {
	z = c;
	y = b + c;
	x = a + b + c;
	if (ok()) return 1;
	z = c;
	y = c * 2 + b;
	x = c * 4 + b * 2 + a;
	if (ok()) return 1;
	return 0;
}

void Solve() {
	scanf("%lld%lld%lld", &a, &b, &c);
	if (a == 0 && b == 0 && c == 0) { printf("YES\n1 1 1\n"); return; }
	if (work(x, y, z, a, b, c)) { printf("YES\n%lld %lld% lld\n", x, y, z); return; }
	if (work(y, z, x, b, c, a)) { printf("YES\n%lld %lld% lld\n", x, y, z); return; }
	if (work(z, x, y, c, a, b)) { printf("YES\n%lld %lld% lld\n", x, y, z); return; }
	puts("NO");
}

signed main() {
	int T; scanf("%d", &T);
	while (T--) Solve();
	return 0;
}
