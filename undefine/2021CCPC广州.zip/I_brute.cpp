#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int, int> pii;

int n;
int a[20];

int check() {
	int sum = 0;
	for (int i = 0; i < n; ++i) {
		sum += 2*a[i];
		if (sum%(i+1)) return 0;
	}
	return 1;
}

signed main() {
	for (n = 1; n < 20; ++n) {
		iota(a, a+n, 1);
		int cnt = 0;
		do {
			cnt += check();
		} while (next_permutation(a, a+n));
		cout << cnt << '\n';
	}
	return 0;
}
