#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll read() { ll x; scanf("%lld", &x); return x; }
#define repeat(i, a, b) for (int i = a, ib = b; i < ib; i++)
const int N=7005;
const int M=7e5+5;
int unit, n, m, a[N], fin[N];
int X[N],Y[N],A[N],unix,tmpx[N],uniy,tmpy[N];
ll ans1[M],ans2[M];
struct node {
	int l, r, a, b, id;
	bool operator<(const node &b) const {
		if (l / unit != b.l / unit) return l < b.l;
		if ((l / unit) & 1)
			return r < b.r;
		return r > b.r;
	}
}Q[M];
struct frac{
	ll a,b;
	bool operator <(const frac &A)const{
		return a*A.b<A.a*b;
	}
};
int cnt[N<<2];
frac mi[N<<2],ans[M];
template<class T>inline void MIN(T &x,T y){if(y<x)x=y;}
void build(int l=1,int r=n,int p=1){
	if(l==r){
		cnt[p]=0;
		mi[p]=(frac){(int)2e9,1};
		return;
	}
	int mid=l+r>>1;
	build(l,mid,p<<1);
	build(mid+1,r,p<<1|1);
	cnt[p]=cnt[p<<1]+cnt[p<<1|1];
	mi[p]=min(mi[p<<1],mi[p<<1|1]);
}
void UPDATE(int x,int v,int nxt,int l=1,int r=n,int p=1){
	if(l==r){
		cnt[p]=v;
		mi[p]=(frac){(int)2e9,1};
		if(v==1&&nxt!=-1){
			frac tmp=(frac){abs(tmpy[A[nxt]]-tmpy[A[l]]),abs(tmpx[nxt]-tmpx[l])};
			MIN(mi[p],tmp);
		}
		return;
	}
	int mid=l+r>>1;
	if(x<=mid)UPDATE(x,v,l,mid,p<<1);
	else UPDATE(x,v,mid+1,r,p<<1|1);
	cnt[p]=cnt[p<<1]+cnt[p<<1|1];
	mi[p]=min(mi[p<<1],mi[p<<1|1]);
}
int get_pre(int x,int l=1,int r=n,int p=1){
	if(l==r)return cnt[p]?l:-1;
	int mid=l+r>>1,res=-1;
	if(x>mid+1&&cnt[p<<1|1])res=get_pre(x,mid+1,r,p<<1|1);
	if(res==-1&&cnt[p<<1])res=get_pre(x,l,mid,p<<1);
	return res;
}
int get_nxt(int x,int l=1,int r=n,int p=1){
	if(l==r)return cnt[p]?l:-1;
	int mid=l+r>>1,res=-1;
	if(x<mid&&cnt[p<<1])res=get_nxt(x,l,mid,p<<1);
	if(res==-1&&cnt[p<<1|1])res=get_nxt(x,mid+1,r,p<<1|1);
	return res;
}
void update(int x,int v){
	printf("---%d %d\n",x,v);
	int pre=get_pre(A[x]);
	int nxt=get_nxt(A[x]);
	if(v==1){
		if(nxt!=-1)UPDATE(A[x],1,nxt);
		if(pre!=-1)UPDATE(pre,1,A[x]);
	}
	else{
		if(nxt!=-1)UPDATE(A[x],0,nxt);
		if(pre!=-1){
			if(nxt!=-1)UPDATE(pre,1,nxt);
			else UPDATE(pre,0,0);
		}
	}
}
frac query(int a,int b,int l=1,int r=n,int p=1){
	if(l>b||r<a)return (frac){(int)2e9,1};
	if(l>=a&&r<=b)return mi[p];
	int mid=l+r>>1;
	return min(query(a,b,l,mid,p<<1),query(a,b,mid+1,r,p<<1|1));
}
void mo() {
	unit = sqrt(n) + 1;
	sort(Q+1,Q+1+m);
	int l = Q[1].l, r = l-1;
	for (int x=1;x<=m;x++) {
		node i=Q[x];
		while (l < i.l) update(l++, -1);
		while (l > i.l) update(--l, 1);
		while (r < i.r) update(++r, 1);
		while (r > i.r) update(r--, -1);
		int pos=get_pre(i.b+1);
		if(pos!=-1){
			ans[i.id] = query(i.a,pos-1);
		}
		else ans[i.id] = (frac){(int)2e9,1};
	}
}
int main() {
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)scanf("%d%d",&X[i],&Y[i]);
	for(int i=1;i<=n;i++){
		tmpx[++unix]=X[i];
		tmpy[++uniy]=Y[i];
	}
	sort(tmpx+1,tmpx+1+unix);
	sort(tmpy+1,tmpy+1+uniy);
	unix=unique(tmpx+1,tmpx+1+unix)-tmpx-1;
	uniy=unique(tmpy+1,tmpy+1+uniy)-tmpy-1;
	for(int i=1;i<=n;i++){
		X[i]=lower_bound(tmpx+1,tmpx+1+unix,X[i])-tmpx;
		Y[i]=lower_bound(tmpy+1,tmpy+1+uniy,Y[i])-tmpy;
		A[X[i]]=Y[i];
	}
	for(int i=1;i<=m;i++){
		int x1,x2,y1,y2;
		scanf("%d%d%d%d",&x1,&x2,&y1,&y2);
		x1=lower_bound(tmpx+1,tmpx+1+unix,x1)-tmpx;
		x2=upper_bound(tmpx+1,tmpx+1+unix,x2)-tmpx-1;
		y1=lower_bound(tmpy+1,tmpy+1+uniy,y1)-tmpy;
		y2=upper_bound(tmpy+1,tmpy+1+uniy,y2)-tmpy-1;
		Q[i]=(node){x1,x2,y1,y2,i};
	}
	build();
	mo();
	for(int i=1;i<=m;i++){
		if(ans[i].a==2e9)ans[i]=(frac){1,0};
		if(ans[i].a==0)ans[i]=(frac){0,1};
		ll tmp=__gcd(ans[i].a,ans[i].b);
		if(tmp)ans[i].a/=tmp;
		if(tmp)ans[i].b/=tmp;
		printf("%lld %lld\n",ans[i].a,ans[i].b);
	}
	return 0;
}
