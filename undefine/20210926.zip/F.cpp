#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
const int mod = 998244353;
const int N = 1e5+7;

struct Node {
	int a, b, t;
	bool operator<(const Node &nd) const {
		if (t != nd.t) return t < nd.t;
		return b == nd.b ? a > nd.a : b < nd.b;
	}
};

int n;
ll pw[4][N], val[N], vis[N];
vector<Node> c;

void solve() {
	c.clear();
	scanf("%d", &n);
	for (int i = 1, a, b, t; i <= n; ++i) {
		scanf("%d%d%d", &a, &b, &t);
		c.emplace_back(Node{a, b, t});
	}
	sort(c.begin(), c.end());
	ll ans = 0;
	for (int i = 1; i < n; ++i) {
		if (n-i < 23) break;
		ans = (ans+c.back().b*pw[c.back().t-2][n-i])%mod;
		c.pop_back();
	}
	n = c.size();
	ll res = 0;
	for (int i = 0; i < n; ++i) {
		ll cur = c[i].a;
		for (int k = 0; k < n; ++k) vis[k] = 0;
		vis[i] = 1;
		for (int j = 1; j < n; ++j) {
			for (int k = 0; k < n; ++k) val[k] = vis[k] ? 0 : c[k].b*pw[c[k].t][n-j];
			int id = max_element(val, val+n)-val;
			cur += val[id];
			vis[id] = 1;
		}
		res = max(res, cur);
	}
	printf("%lld", (res+ans)%mod);
}

signed main() {
	pw[0][0] = pw[1][0] = pw[2][0] = pw[3][0] = 1;
	for (int i = 1; i < N; ++i) {
		pw[2][i] = pw[2][i-1]*2;
		pw[3][i] = pw[3][i-1]*3;
		pw[0][i] = pw[0][i-1]*2%mod;
		pw[1][i] = pw[1][i-1]*3%mod;
//		if (pw[3][i]/pw[2][i] > 10000) cout << i << '\n'; // 23
	}
	int T;
	scanf("%d", &T);
	while (T--) {
		solve();
		if (T) puts("");
	}
	return 0;
}
