#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 20 + 5;
ll read() { ll x; scanf("%lld", &x); return x; }
#define repeat(i, a, b) for (int i = a, ib = b; i < ib; i++)
#define int ll
int a[N][N], sum[N];
vector<ll> dp, nxt, ans;
const int mod = 998244353;
ll qpow(ll a, int t) {
	ll ans = 1;
	while (t) {
		if (t&1) ans = ans*a%mod;
		a = a*a%mod;
		t >>= 1;
	}
	return ans;
}
signed main() {
	int n = read();
	repeat (i, 0, n) {
		repeat (j, 0, n)
			a[i][j] = read(), sum[i] += a[i][j];
	}
	dp.assign(1 << n, 0);
	dp[0] = 1;
	repeat (i, 0, n) {
//		cout << "***" << endl;
		nxt.assign(1 << n, 0);
		ans.assign(n, 0);
		int s = (1 << i) - 1;
		while (s < (1 << n)) {
//			cout << s << endl;
			int s1 = 0; repeat (j, 0, n) if (s >> j & 1) s1 += a[i][j];
			repeat (j, 0, n)
			if (~s >> j & 1) {
				ll t = dp[s] * a[i][j] % mod * qpow(sum[i] - s1, mod - 2);
				(nxt[s | 1 << j] += t) %= mod;
				(ans[j] += t) %= mod;
			}
			
			int x = s & -s, y = s + x;
			if (x == 0) break;
			s = ((s & ~y) / x >> 1) | y;
		}
		swap(dp, nxt);
		repeat (j, 0, n) {
			if (j) putchar(' ');
			printf("%lld", ans[j]);
		}
		if (i != n - 1) putchar('\n');
	}
	return 0;
}
