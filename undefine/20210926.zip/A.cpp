#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int M=2005;
int cas,n,k,A[M];

signed main(){
	scanf("%d",&cas);
	for(int _=1;_<=cas;_++){
		scanf("%d%d",&n,&k);
		for(int i=1;i<=n;i++)scanf("%d",&A[i]),A[i+n]=A[i];
		int ok=1,ok2=0,down=0;
		for(int i=1;i<n;i++)if(A[i]>A[i+1])ok=0;
		for(int i=1;i<=n;i++)if(A[i]>A[i+1])down=i,ok2++;
		if(k==1)printf("%d",ok?0:-2);
		else if(k==2){
			if(ok==1)printf("%d",0);
			else if(ok2==1){
				puts("1");
				printf("%d\n",2);
				printf("%d %d %d\n",0,down,n);
				printf("2 1");
			}
			else printf("%d",-2);
		}
		else{
			printf("%d\n",n-1);
			for(int i=1;i<n;i++){
				int mi=i;
				for(int j=i;j<=n;j++)if(A[j]<A[mi])mi=j;
				if(i==mi)printf("2\n%d %d %d\n1 2",0,1,n);
				else if(i==1)printf("2\n%d %d %d\n2 1",0,mi-1,n);
				else printf("3\n%d %d %d %d\n1 3 2",0,i-1,mi-1,n);
				if(i!=n-1)puts("");
				rotate(A + i, A + mi, A + n + 1);
//				for (int i = 1; i <= n; i++) cout << A[i] << ' '; cout << endl;
			}
		}
		if(_<cas)puts("");
	}
	return 0;
}
