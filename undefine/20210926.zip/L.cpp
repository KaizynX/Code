#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e5+7;
const int M = 100+7;
const int mod = 998244353;

int n, m, cp;
int a[N], vis[N<<2][M], p[M];
ll tr[N<<2], lazy[N<<2];

ll qpow(ll a, int t) {
	ll ans = 1;
	while (t) {
		if (t&1) ans = ans*a%mod;
		a = a*a%mod;
		t >>= 1;
	}
	return ans;
}

void init() {
	cp = 0;
	for (int i = 2; i <= 100; ++i) {
		int flag = 1;
		for (int j = 2; j < i; ++j) {
			if (i%j == 0) {
				flag = 0;
				break;
			}
		}
		if (flag) p[++cp] = i;
	}
	//for (int i = 1; i <= cp; ++i) cout << p[i] << " \n"[i==cp];//////
}

void push_up(int i) {
	tr[i] = (tr[i<<1]+tr[i<<1|1])%mod;
}

void push_down(int i) {
	if (lazy[i] == 1) return;
	lazy[i<<1] = lazy[i<<1]*lazy[i]%mod;
	lazy[i<<1|1] = lazy[i<<1|1]*lazy[i]%mod;
	tr[i<<1] = tr[i<<1]*lazy[i]%mod;
	tr[i<<1|1] = tr[i<<1|1]*lazy[i]%mod;
	lazy[i] = 1;
}

void build(int l, int r, int i = 1) {
	lazy[i] = 1;
	if (l == r) {
		tr[i] = a[l];
		for (int j = 1; j <= cp; ++j) {
			if (tr[i]%p[j] == 0) {
				tr[i] = tr[i]/p[j]*(p[j]-1);
				vis[i][p[j]] = 1;
			}
		}
		return;
	}	
	int mid = (l+r)/2;
	build(l, mid, i<<1);
	build(mid+1, r, i<<1|1);
	push_up(i);
}

void update1(int L, int R, int w, int l = 1, int r = n, int i = 1) {
	if (l >= L && r <= R) {
		if (vis[i][w]) return;
		vis[i][w] = 1;
		if (l == r) {
			tr[i] = tr[i]*qpow(w, mod-2)%mod*(w-1)%mod;
			return;
		}
	}
	push_down(i);
	int mid = (l+r)/2;
	if (L <= mid) update1(L, R, w, l, mid, i<<1);
	if (R >  mid) update1(L, R, w, mid+1, r, i<<1|1);
	push_up(i);
}

void update2(int L, int R, int w, int l = 1, int r = n, int i = 1) {
	if (l >= L && r <= R) {
		tr[i] = tr[i]*w%mod;
		lazy[i] = lazy[i]*w%mod;
		return;
	}
	push_down(i);
	int mid = (l+r)/2;
	if (L <= mid) update2(L, R, w, l, mid, i<<1);
	if (R >  mid) update2(L, R, w, mid+1, r, i<<1|1);
	push_up(i);
}

ll query(int L, int R, int l = 1, int r = n, int i = 1) {
	if (l >= L && r <= R) return tr[i];
	push_down(i);
	int mid = (l+r)/2;
	if (R <= mid) return query(L, R, l, mid, i<<1);
	if (L >  mid) return query(L, R, mid+1, r, i<<1|1);
	return (query(L, R, l, mid, i<<1)+query(L, R, mid+1, r, i<<1|1))%mod;
}

signed main() {
	init();
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; ++i) {
		scanf("%d", a+i);
	}
	build(1, n);
	vector<ll> ans;
	for (int i = 1, op, l, r, w; i <= m; ++i) {
		scanf("%d%d%d", &op, &l, &r);
		if (op == 0) {
			scanf("%d", &w);
			for (int j = 1; j <= cp; ++j) {
				if (w%p[j] == 0) {
					update1(l, r, p[j]);
				}
			}
			update2(l, r, w);
		} else {
			ans.emplace_back(query(l, r));
		}
	}
	for (int i = 0; i < (int)ans.size(); ++i) {
		if (i) puts("");
		printf("%lld", ans[i]);
	}
	return 0;
}
