#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int M=105;
int n,val[M],A[M],B[M],C[M];

void dfs(int x,ll l,ll r,ll len,ll &c){
	if(x>n)return;
	if(val[x]==1)dfs(x+1,l,r+len,len*2,c);
	else dfs(x+1,l-len,r,len*2,c);
	if(c>=l&&c<r)C[x]=0;
	else if(c<l)c+=len,C[x]=1;
	else if(c>=r)c-=len,C[x]=1;
}
signed main(){
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&val[i]);
	for(int i=1;i<=n;i++)scanf("%d",&A[i]);
	for(int i=1;i<=n;i++)scanf("%d",&B[i]);
	ll a=0,b=0,c=0;
	for(int i=1;i<=n;i++){
		if(A[i])a+=val[i]*(1ll<<i-1);
		if(B[i])b+=val[i]*(1ll<<i-1);
	}
	c=a+b;
//	printf("%lld %lld %lld\n",a,b,c);
	dfs(1,0,1,1,c);
	for(int i=1;i<=n;i++){
		printf("%d",C[i]);
		if(i<n)printf(" ");
	}
	return 0;
}
