#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 5e5 + 5;
ll read() { ll x; scanf("%lld", &x); return x; }
#define repeat(i, a, b) for (int i = a, ib = b; i < ib; i++)
#define int ll
int a[N], b[N];
void print(int a, int b) {
	if (a == 0 && b == 0) return;
	if (a == 0) { printf("0"); exit(0); }
	if (b == 0) { printf("infinity"); exit(0); }
	int g = __gcd(a, b);
	a /= g;
	b /= g;
	if (b < 0) a = -a, b = -b;
	if (b == 1) printf("%lld", a);
	else printf("%lld/%lld", a, b);
	exit(0);
}
signed main() {
	int n = read(), t = read();
	repeat (i, 0, n) {
		a[i] = read(), b[i] = read();
	}
	if (t == 0) {
		print(0, 1);
	} else if (t == 1) {
		ll s = 0;
		repeat (i, 0, n) s += a[i] * b[i];
		print(s, 1);
	} else if (t == 2) {
		ll u = 0;
		repeat (i, 0, n) u += a[i] * b[i];
		if (u != 0) print(1, 0);
		u = 0;
		repeat (i, 0, n) u -= a[i] * b[i] * b[i];
		print(u, 2);
	} else if (t == 3) {
		ll u = 0;
		repeat (i, 0, n) u += a[i] * b[i];
		if (u != 0) print(1, 0);
		u = 0;
		repeat (i, 0, n) u -= a[i] * b[i] * b[i];
		if (u != 0) print(1, 0);
		u = 0;
		repeat (i, 0, n) u += a[i] * b[i] * b[i] * b[i];
		print(u, 3);
	} else if (t == 4) {
		ll u = 0;
		repeat (i, 0, n) u += a[i] * b[i];
		if (u != 0) print(1, 0);
		u = 0;
		repeat (i, 0, n) u -= a[i] * b[i] * b[i];
		if (u != 0) print(1, 0);
		u = 0;
		repeat (i, 0, n) u += a[i] * b[i] * b[i] * b[i];
		if (u != 0) print(1, 0);
		u = 0;
		repeat (i, 0, n) u -= a[i] * b[i] * b[i] * b[i] * b[i];
		print(u, 4);
	} else if (t == 5) {
		ll u = 0;
		repeat (i, 0, n) u += a[i] * b[i];
		if (u != 0) print(1, 0);
		u = 0;
		repeat (i, 0, n) u -= a[i] * b[i] * b[i];
		if (u != 0) print(1, 0);
		u = 0;
		repeat (i, 0, n) u += a[i] * b[i] * b[i] * b[i];
		if (u != 0) print(1, 0);
		u = 0;
		repeat (i, 0, n) u -= a[i] * b[i] * b[i] * b[i] * b[i];
		if (u != 0) print(1, 0);
		u = 0;
		repeat (i, 0, n) u += a[i] * b[i] * b[i] * b[i] * b[i] * b[i];
		print(u, 5);
	}
	return 0;
}
