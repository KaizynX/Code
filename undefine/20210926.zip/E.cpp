#include <bits/stdc++.h>
using namespace std;
typedef long long ll; typedef double lf;
const int N = 50 + 5;
ll read() { ll x; scanf("%lld", &x); return x; }
#define repeat(i, a, b) for (int i = a, ib = b; i < ib; i++)
#define int ll
const int mod = 998244353; const lf pi = acos(-1);
ll qpow(ll a, int t) {
	ll ans = 1;
	while (t) {
		if (t&1) ans = ans*a%mod;
		a = a*a%mod;
		t >>= 1;
	}
	return ans;
}
lf sqr(lf x) { return x * x; }
struct vec {
	ll x, y;
	vec operator-(vec b) const { return { x - b.x, y - b.y }; }
	vec operator&(vec b) const { return { (x + b.x) / 2, (y + b.y) / 2 }; }
	lf dist(vec b) const {
		return sqrt(sqr(x - b.x) + sqr(y - b.y));
	}
	lf len() const {
		return sqrt(x * x + y * y);
	}
	friend ll cross(vec a, vec b) {
		return a.x * b.y - a.y * b.x;
	}
	friend bool isline(vec a, vec b, vec c) {
		return cross(a - b, a - c) == 0;
	}
	lf theta() const {
		return atan2(y, x);
	}
	friend lf theta(vec a, vec b) {
		return acos((a.x * b.x + a.y * b.y) / (a.len() * b.len()));
	}
} a[N];
lf len[N][N];
vector<pair<lf, lf>> v;
#define l first
#define r second
signed main() {
	int n = read();
	repeat (i, 0, n) {
		a[i].x = read() * 2, a[i].y = read() * 2;
	}
	repeat (i, 0, n)
	repeat (j, 0, n)
		len[i][j] = a[i].dist(a[j]);
	repeat (i, 0, n) {
		repeat (j, 0, n) if (j != i) {
			v.clear(); v.push_back({0, 0});
			repeat (k, 0, n) if (k != j && k != i) {
				if (isline(a[i], a[j], a[k])) {
					if (len[i][j] > len[i][k]
					|| (len[i][j] == len[i][k] && j > k))
						v.push_back({0, pi});
				} else /* if (cross(a[i] - a[j], a[i] - a[k]) > 0) */ {
					lf th1 = theta((a[j] & a[k]) - a[i], a[j] - a[i]);
					lf th2 = theta(a[k] - a[j], a[j] - a[i]);
					if (cross(a[i] - a[j], a[i] - a[k]) > 0) {
						th1 = pi - th1;
						th2 = pi - th2;
						swap(th1, th2);
					}
					v.push_back({th1, th2});
					// printf("%.10lf %.10lf\n", th1, th2);
				}
			}
			lf ans = 0;
//			if (i == 4 && j == 0) {cout << "\nxxx: " << endl;
//				for (auto i : v) cout << i.l << ' ' << i.r << endl;
//			}
			sort(v.begin(), v.end());
			int pre = 0;
			repeat (i, 1, v.size()) {
				if (v[pre].r < v[i].l) {
					pre++;
					v[pre] = v[i];
				} else v[pre].r = max(v[pre].r, v[i].r);
			}
			v.erase(v.begin() + pre + 1, v.end());
//			if (i == 4 && j == 0) {cout << "\nxxx: " << endl;
//				for (auto i : v) cout << i.l << ' ' << i.r << endl;
//			}
			repeat (i, 0, pre + 1) ans += v[i].r - v[i].l;
			printf("%.10lf ", max(0.0, 1 - ans / pi));
		} else printf("%.10lf ", 0.0);
		puts("");
	}
	return 0;
}
