#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 5e5 + 5;
ll read() { ll x; scanf("%lld", &x); return x; }
#define repeat(i, a, b) for (int i = a, ib = b; i < ib; i++)
#define int ll
const int M=605;
int k,r,A[M][M];

signed main() {// cout << 26 - 256 % 26 << ' ' << 256 % 26;
	
//	repeat (k, 3, 27)
//	repeat (r, 3, k + 1) {
//		if ((512 + r - 1) / r + (r - 1) * (256 / k) < 128) {
//			cout << (512 + r - 1) / r + (r - 1) * (256 / k) << endl;
//			cout << k << ' ' << r << endl;
//		}
//	}
	scanf("%d%d",&k,&r);
	if(k==26&&r==8){
		int len=(512+r-1)/r,l=1,r=len;
		for(int i=1;i<=k;i++){
			for(int j=l;j<=r;j++)A[i][j%256+1]=1;
			l+=256/k+1;
			r+=256/k+1;
			if(i%6==1)l--,r--;
		}
		for(int i=1;i<=k;i++){
			for(int j=1;j<=256;j++)printf("%d",A[i][j]);
			if(i<k)puts("");
		}
	}
	else{
		int len=(512+r-1)/r,l=1,r=len;
		for(int i=1;i<=k;i++){
			for(int j=l;j<=r;j++)A[i][j%256+1]=1;
			l+=256/k;
			r+=256/k;
		}
		for(int i=1;i<=k;i++){
			for(int j=1;j<=256;j++)printf("%d",A[i][j]);
			if(i<k)puts("");
		}
	}
	return 0;
}
