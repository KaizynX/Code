#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=505;
const int dir[5] = {0,-1,0,1,0};

int n, m;
int a[N][N], rk[N*N];
double b[N][N];

signed main() {
	scanf("%d%d", &n, &m);
	for (int i = 0; i < n; ++i){
		for (int j = 0; j < n; ++j){
			scanf("%d", &a[i][j]);
			b[i][j] = m;
			rk[i*n+j] = i*n+j;
		}
	}
	sort(rk, rk+n*n, [&](int x, int y) {
		return a[x/n][x%n] > a[y/n][y%n];
	});
	for (int i = 0, x, y; i < n*n; ++i) {
		x = rk[i]/n, y = rk[i]%n;
		int cnt = 0;
		for (int d = 0, nx, ny; d < 4; ++d) {
			nx = x+dir[d];
			ny = y+dir[d+1];
			if (nx < 0 || nx >= n || ny < 0 || ny >= n || a[nx][ny] >= a[x][y]) continue;
			++cnt;
		}
		if (cnt) for (int d = 0, nx, ny; d < 4; ++d) {
			nx = x+dir[d];
			ny = y+dir[d+1];
			if (nx < 0 || nx >= n || ny < 0 || ny >= n || a[nx][ny] >= a[x][y]) continue;
			b[nx][ny] += b[x][y]/cnt;
		}
		//b[x][y] = 0;
//		cout << x << ' ' << y << ' ' << cnt << '\n';
//		for (int i = 0; i < n; ++i){
//		for (int j = 0; j < n; ++j){
//			printf("%.7f ",b[i][j]);
//		}
//		puts("");
//		}
	}
	for (int i = 0; i < n; ++i){
		for (int j = 0; j < n; ++j){
			printf("%.7f ", a[i][j] == 0 ? b[i][j] : 0);
		}
		puts("");
	}
	return 0;
}
