#include <bits/stdc++.h>

using namespace std;
using uint = unsigned;

int a, b, c, d;
int cc, dd;
int ck[10];

void f1(int x) {
  cout << x << '-' << (x >= a ? "Y" : "N");
}

signed main() {
  int ic = 1, id = 2;
  cin >> a >> b >> c >> d;
  cc = c;
  dd = d;
  if (c < d) {
    swap(c, d);
    swap(ic, id);
  }
  if (c >= a && d >= a) {
    ck[1] = ck[2] = 1;
  } else if (c < a && d < a) {
    ;
  } else if (c >= b) {
    ck[1] = ck[2] = 1;
  } else {
    ck[ic] = 1;
  }
  cout << cc << "-" << (ck[1] ? "Y" : "N") << ' ';
  cout << dd << "-" << (ck[2] ? "Y" : "N") << '\n';
  if (c >= a && d >= a) {
    cout << "huan ying ru guan\n";
  } else if (c < a && d < a) {
    cout << "zhang da zai lai ba\n";
  } else if (c >= b) {
    cout << "qing " << ic << " zhao gu hao " << id << "\n";
  } else {
    cout << ic << ": huan ying ru guan\n";
  }
  return 0;
}