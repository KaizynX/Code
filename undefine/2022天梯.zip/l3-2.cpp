#include <bits/stdc++.h>

using namespace std;
using uint = unsigned;
using ll = long long;
using pii = pair<int, int>;
constexpr int N = 3e5 + 7;
constexpr int MOD = 1e9 + 7;

ll qpow(ll a, ll p) {
  ll ans = 1;
  while (p) {
    if (p & 1) ans = ans * a % MOD;
    a = a * a % MOD;
    p >>= 1;
  }
  return ans;
}

ll inv(ll x) {
  return qpow(x, MOD - 2);
}

template <typename T>
struct BIT {
  int n;
  vector<T> tr;
  void init(int n) { tr = vector<T>(n + 1, 0); this->n = n; }
  void add(int x, T k) {
    for ( ; x <= n; x += x &-x) tr[x] += k;
  }
  T query(int x) {
    T res = 0;
    for (; x; x -= x &-x) res += tr[x];
    return res;
  }
};

int n, r;
int son[N];
ll ans;
ll fac[N], sum[N], num[N];
ll inv2 = qpow(2, MOD - 2);
vector<int> e[N];
BIT<int> tree;

void dfs(int u, int fa = 0) {
  sum[u] = 1;
  num[u] = 1;
  for (int v : e[u]) if (v != fa) {
    ++son[u];
    dfs(v, u);
    num[u] += num[v];
    sum[u] = sum[u] * sum[v] % MOD;
  }
  sum[u] = sum[u] * fac[son[u]] % MOD;
  ll base = sum[r] * inv(sum[u]) % MOD * fac[u] % MOD;
  int big = tree.query(u);
  // ans += big * base;
  tree.add(u, 1);
  base = base * inv2 % MOD;
  for (int v : e[u]) if (v != fa) {
    ll pr = num[v] * (num[u] - num[v] - 1ll);
    ans += base * pr % MOD;
  }
}

signed main() {
  fac[0] = fac[1] = 1;
  for (int i = 2; i < N; ++i) {
    fac[i] = fac[i - 1] * i % MOD;
  }

  cin >> n >> r;
  for (int i = 1, u, v; i < n; ++i) {
    cin >> u >> v;
    e[u].emplace_back(v);
    e[v].emplace_back(u);
  }
  tree.init(n);
  dfs(r);
  cout << ans % MOD << '\n';
  return 0;
}