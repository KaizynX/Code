#include <bits/stdc++.h>

#define int ll
using namespace std;
using uint = unsigned;
using ll = long long;
using pii = pair<int, int>;
constexpr int N = 5e2 + 7;

int n;
char str[N];
int sex[N], val[N], ans[2] = {-1, -1};
int dis[N][N];

void update(int &x, int y) {
  if (x == -1 || x > y) x = y;
}

signed main() {
  scanf("%lld", &n);
  memset(dis, -1, sizeof dis);
  for (int i = 1, k; i <= n; ++i) {
    scanf("%s%lld", str, &k);
    sex[i] = str[0] == 'M';
    for (int j = 0, id, d; j < k; ++j) {
      scanf("%lld:%lld", &id, &d);
      dis[i][id] = d;
      // dis[id][i] = d;
    }
  }
  for (int k = 1; k <= n; ++k) {
    for (int i = 1; i <= n; ++i) {
      for (int j = 1; j <= n; ++j) {
        if (dis[i][k] == -1) continue;
        if (dis[k][j] == -1) continue;
        update(dis[i][j], dis[i][k] + dis[k][j]);
      }
    }
  }
  for (int i = 1; i <= n; ++i) {
    val[i] = -1; // ?
    for (int j = 1; j <= n; ++j) {
      if (sex[i] == sex[j]) continue;
      if (dis[j][i] == -1) continue;
      val[i] = max(val[i], dis[j][i]);
    }
    if (val[i] == -1) continue;
    update(ans[sex[i]], val[i]); // ?
  }
  for (int i : {0, 1}) {
    for (int j = 1, fir = 1; j <= n; ++j) {
      if (sex[j] == i && val[j] == ans[i]) {
        if (!fir) cout << ' ';
        fir = 0;
        cout << j;
      }
    }
    cout << '\n';
  }
  return 0;
}