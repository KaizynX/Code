#include <bits/stdc++.h>

using namespace std;
using uint = unsigned;
using ll = long long;
using pii = pair<int, int>;
constexpr int N = 1e3 + 7;

int n, m, k;
vector<int> box, arr;

int main() {
  cin >> n >> m >> k;
  arr.resize(n);
  for (int i = 0; i < n; ++i) cin >> arr[i];
  reverse(arr.begin(), arr.end());
  while (arr.size() || box.size()) {
    for (int i = 1, last = 233; i <= k; ++i) {
      while (box.empty() || box.back() > last) {
        if (arr.empty()) break;
        if ((int)box.size() == m && arr.back() > last) break;
        box.emplace_back(arr.back());
        arr.pop_back();
      }
      if (box.empty() || box.back() > last) break;
      last = box.back();
      box.pop_back();
      if (i > 1) cout << ' ';
      cout << last;
    }
    cout << '\n';
  }
  return 0;
}