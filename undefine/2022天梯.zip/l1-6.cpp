#include <bits/stdc++.h>

using namespace std;
using uint = unsigned;

string f(string s) {
  string r;
  for (uint i = 1; i < s.size(); ++i) {
    if ((s[i] - '0') % 2 == (s[i - 1] - '0') % 2) {
      r += max(s[i], s[i - 1]);
    }
  }
  return r;
}

int main() {
  string s1, s2;
  cin >> s1 >> s2;
  s1 = f(s1);
  s2 = f(s2);
  cout << s1 << '\n';
  if (s1 != s2) cout << s2 << '\n';
  return 0;
}