#include <bits/stdc++.h>

using namespace std;
using uint = unsigned;

signed main() {
  int n, v;
  cin >> n >> v;
  cout << (n) /v << '\n';
  return 0;
}