#include <bits/stdc++.h>

using namespace std;
using uint = unsigned;
using ll = long long;
using pii = pair<int, int>;
constexpr int N = 1e5 + 7;

int n, m;
int deg[N];
vector<int> e[N];
vector<string> a[N];
set<string> st;
vector<string> all;
string str;

signed main() {
  cin >> n;
  for (int i = 1; i <= n; ++i) {
    cin >> str;
    str += '.';
    for (size_t last = 0, cur; ; last = cur + 1) {
      cur = str.find('.', last);
      if (cur == str.npos) break;
      st.insert(str.substr(last, cur - last));
      // all.emplace_back(a[i].back());
    }
  }
  for (int i = 1; i <= n; ++i) {
    a[i].emplace_back();
  }
  // sort(all.begin(), all.end());
  // all.erase(unique(all.begin(), all.end()), all.end());
  all.assign(st.begin(), st.end());
  for (uint i = 0; i < all.size(); ++i) {
    mp[all[i]] = i;
  }
  for (int i = 2; i <= n; ++i) {
    if (a[i].size() != a[i - 1].size()) continue;
    uint j = 0;
    while (j < a[i].size() && a[i][j] == a[i - 1][j]) ++j;
    if (j < a[i].size()) {
      int id = mp[a[i][j]];
      ++deg[id];
      e[mp[a[i - 1][j]]].emplace_back(id);
    }
  }
  priority_queue<int, vector<int>, greater<int>> q;
  for (uint i = 0; i < all.size(); ++i) {
    if (deg[i] == 0) {
      q.push(i);
    }
  }
  for (int fir = 1; q.size(); ) {
    int s = q.top();
    q.pop();
    if (!fir) cout << '.';
    fir = 0;
    cout << all[s];
    for (const int &t : e[s]) {
      if (--deg[t] == 0) {
        q.push(t);
      }
    }
  }
  return 0;
}