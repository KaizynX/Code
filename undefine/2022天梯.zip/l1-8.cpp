#include <bits/stdc++.h>

using namespace std;
using uint = unsigned;
using ll = long long;
constexpr int N = 1e5 + 7;

int n, k, s;
int t[N], p[N];
int cnt[N][2];

int main() {
  cin >> n >> k >> s;
  int ans = 0;
  for (int i = 1; i <= n; ++i) {
    cin >> t[i] >> p[i];
    ++cnt[t[i]][p[i] >= s];
  }
  for (int i = 175; i <= 290; ++i) {
    ans += min(cnt[i][0], k);
    ans += cnt[i][1];
  }
  cout << ans << '\n';
  return 0;
}