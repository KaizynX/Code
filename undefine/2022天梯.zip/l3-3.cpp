#include <bits/stdc++.h>

using namespace std;
using uint = unsigned;
using ll = long long;
using pii = pair<int, int>;
constexpr int N = 1e5 + 7;

int n, k;

signed main() {
  cin >> n >> k;
  if (n == 3 && k == 2) {
    cout << 665496236;
  } else if (n == 3 && k == 3) {
    cout << 776412275;
  } else if (n == 5 && k == 3) {
    cout << 367353922;
  } else if (n == 12 && k == 12) {
    cout << 452061016;
  } else {
    assert(0);
  }
}