#include <bits/stdc++.h>

using namespace std;
using uint = unsigned;
using ll = long long;
using pii = pair<int, int>;
constexpr int N = 1e5 + 7;

int n, m;
int fa[N], rt, vis[N], dep[N];
vector<int> e[N];

void dfs(int x) {
  for (int y : e[x]) if (y != fa[x]) {
    dep[y] = dep[x] + 1;
    dfs(y);
  }
}

int main() {
  cin >> n >> m;
  for (int i = 1; i <= n; ++i) {
    cin >> fa[i];
    if (fa[i] == -1) rt = i;
    else e[fa[i]].emplace_back(i);
  }
  vis[rt] = 1;
  dfs(rt);
  int ans = 0;
  for (int i = 1, x, mxd = 0; i <= m; ++i) {
    cin >> x;
    int y = x;
    while (!vis[y]) {
      vis[y] = 1;
      y = fa[y];
      ans += 2;
    }
    mxd = max(mxd, dep[x]);
    cout << ans - mxd << '\n';
  }
  return 0;
}