#include <bits/stdc++.h>

using namespace std;
using uint = unsigned;
using ll = long long;
constexpr int N = 1e5 + 7;

int n, m, q;
int vis[2][N], cnt[2], all[2];

int main() {
  cin >> n >> m >> q;
  ll ans = 1ll * n * m;
  all[0] = m;
  all[1] = n;
  for (int i = 1, t, c; i <= q; ++i) {
    cin >> t >> c;
    if (vis[t][c]) continue;
    vis[t][c] = 1;
    ans -= all[t] - cnt[t ^ 1];
    ++cnt[t];
  }
  cout << ans << '\n';
  return 0;
}