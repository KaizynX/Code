#include <bits/stdc++.h>

using namespace std;
using uint = unsigned;
using ll = long long;

int main() {
  ll a, b;
  cin >> a >> b;
  a += b;
  b = 1;
  for (ll i = 2; i <= a; ++i) b *= i;
  cout << b << '\n';
  return 0;
}