#include <bits/stdc++.h>

using namespace std;
using uint = unsigned;
using ll = long long;
constexpr int N = 1e5 + 7;

struct Time {
  int t[3];
  bool operator < (const Time &b) const {
    for (int i : {0, 1, 2}) {
      if (t[i] != b.t[i]) return t[i] < b.t[i];
    }
    return false;
  }
  void add() {
    ++t[2];
    for (int i : {2, 1}) {
      t[i - 1] += t[i] / 60;
      t[i] %= 60;
    }
  }
  void del() {
    --t[2];
    if (t[2] < 0) {
      t[2] += 60;
      --t[1];
    }
    if (t[1] < 0) {
      t[1] += 60;
      --t[0];
    }
  }
};

int n;
using ptt = pair<Time, Time>;
vector<ptt> a;

int main() {
  scanf("%d", &n);
  a.resize(n + 1);
  for (int i = 1; i <= n; ++i) {
    scanf("%d:%d:%d - ", &a[i].first.t[0], &a[i].first.t[1], &a[i].first.t[2]);
    scanf("%d:%d:%d", &a[i].second.t[0], &a[i].second.t[1], &a[i].second.t[2]);
  }
  a[0] = {Time{0,0,0}, Time{0,0,0}};
  sort(a.begin(), a.end());
  a.emplace_back(Time{23,59,59}, Time{23,59,59});
  for (int i = 0; i <= n; ++i) {
    Time t1 = a[i].second;
    Time t2 = a[i + 1].first;
    // t1.add();
    // t2.del();
    if (t1 < t2) {
      printf("%02d:%02d:%02d - ", t1.t[0], t1.t[1], t1.t[2]);
      printf("%02d:%02d:%02d\n", t2.t[0], t2.t[1], t2.t[2]);
    }
  }
  return 0;
}