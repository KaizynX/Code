#include <bits/stdc++.h>

using namespace std;
using uint = unsigned;
using ll = long long;
using pii = pair<int, int>;
constexpr int N = 1e5 + 7;

int n;
unordered_map<string, int> deg;
unordered_map<string, vector<string>> e;
vector<string> a[N];
set<string> all;
// map<string, int> mp;
string str;

/*
void mp(const string &s) {
  if (mp.count(s)) return mp[s];
  return mp[s] = mp.size();
}
*/

signed main() {
  ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
  cin >> n;
  for (int i = 1; i <= n; ++i) {
    cin >> str;
    str += '.';
    for (size_t last = 0, cur; ; last = cur + 1) {
      cur = str.find('.', last);
      if (cur == str.npos) break;
      a[i].emplace_back(str.substr(last, cur - last));
      all.insert(a[i].back());
    }
  }
  for (int i = 2; i <= n; ++i) {
    if (a[i].size() != a[i - 1].size()) continue;
    uint j = 0;
    while (j < a[i].size() && a[i][j] == a[i - 1][j]) ++j;
    if (j < a[i].size()) {
      // ++deg[a[i - 1][j]];
      // e[a[i][j]].emplace_back(a[i - 1][j]);
      ++deg[a[i][j]];
      e[a[i - 1][j]].emplace_back(a[i][j]);
    }
  }
  priority_queue<string, vector<string>, greater<string>> q;
  for (const string &s : all) {
    if (deg[s] == 0) {
      q.push(s);
    }
  }
  for (int fir = 1; q.size(); ) {
    string s = q.top();
    q.pop();
    if (!fir) cout << '.';
    fir = 0;
    cout << s;
    for (const string &t : e[s]) {
      if (--deg[t] == 0) {
        q.push(t);
      }
    }
  }
  return 0;
}