#include <bits/stdc++.h>

using namespace std;
using uint = unsigned;

int main() {
  cout << "I'm gonna win! Today!\n";
  cout << "2022-04-23\n";
  return 0;
}