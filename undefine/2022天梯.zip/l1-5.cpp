#include <bits/stdc++.h>

using namespace std;
using uint = unsigned;

int n;
int a[10];
int vis[10][10];

int main() {
  
  for (int i = 1; i <= 6; ++i) {
    cin >> a[i];
    vis[i][a[i]] = 1;
  }
  cin >> n;
  for (int i = 1; i <= n; ++i) {
    for (int j = 1; j <= 6; ++j) {
      for (int k = 6; k; --k) {
        if (vis[j][k]) continue;
        vis[j][k] = 1;
        a[j] = k;
        break;
      }
    }
  }
  for (int i = 1; i <= 6; ++i) {
    cout << a[i] << " \n"[i == 6];
  }
  return 0;
}