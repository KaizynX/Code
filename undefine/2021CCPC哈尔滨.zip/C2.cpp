#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int M = 1005;
int n,fa[M],A[M],dp[M][M],mi[M];
vector<int>E[M];

void dfs(int x){
	if(E[x].size()==0){
		for(int i=1;i<=n;i++)dp[x][i]=1;
		dp[x][A[x]]=0;
		return;
	}
	for(auto y:E[x]){
		dfs(y);
		for(int i=1;i<=n;i++)dp[x][i]+=min(dp[y][i],mi[y]+1);
	}
	mi[x]=1e9;
	for(int i=1;i<=n;i++)mi[x]=min(mi[x],dp[x][i]);
}
signed main() {
	freopen("jiedai.in","r",stdin);
	freopen("std.out","w",stdout);
	scanf("%d",&n);
	for(int i=2;i<=n;i++){
		scanf("%d",&fa[i]);
		E[fa[i]].push_back(i);
	}
	for(int i=1;i<=n;i++)scanf("%d",&A[i]);
	dfs(1);
	printf("%d\n",mi[1]+1);
	return 0;
}
