#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 1e5+7;
int a[N], n, T;
signed main(){
	scanf("%d", &T);
	while (T--) {
		scanf("%d", &n);
		for (int i = 0; i < n; i++) {
			scanf("%d", &a[i]);
		}
		int m = 0;
		if (accumulate(a, a + n, 0) == 0) {
			puts("1");
		} else if (a[0] != 1) {
			puts("-1");
		} else {
			for (int i = 1; i < n; i++) {
				if (a[i] < a[i - 1]) m = a[i - 1] * 2 - a[i];
			}
			if (m == 0)
				puts("-1");
			else {
				int flag = 1;
				for (int i = 1; i < n; i++) {
					if (a[i - 1] * 2 % m != a[i])
						flag = false;
				}
				if (flag) printf("%d\n", m);
				else puts("-1");
			}
		}
	}
	return 0;
}
