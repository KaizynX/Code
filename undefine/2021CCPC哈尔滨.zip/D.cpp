#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int M = 1e5+7;
ll read() { ll x; scanf("%lld", &x); return x; }
#define repeat(i, a, b) for (int i = a, ib = b; i < ib; i++)
#define repeat_back(i, a, b) for (int i = b - 1, ib = a; i >= ib; i--)
void Solve() {
	ll uu = read(), dd = read();
	string s = to_string(uu);
	string sd = to_string(dd);
	array<int, 10> cua = {}, cda = {};
	repeat (i, 0, s.size())
		cua[s[i] - '0']++;
	repeat (i, 0, sd.size())
		cda[sd[i] - '0']++;
	ll ans = uu;
	repeat (mask, 1, (1 << s.size())) {
		ll u = 0;
		array<int, 10> ua = cua, da = cda;
		repeat (i, 0, s.size()) {
			if (mask >> i & 1) {
				u = u * 10 + s[i] - '0';
				ua[s[i] - '0']--;
			}
		}
		if (u >= ans || u == 0) continue;
		
		__int128 udd = (__int128)u * dd;
		ll d = udd / uu;
		if ((__int128)d * uu != udd) continue;
		string t = to_string(d);
		
		int p = t.size() - 1;
		repeat_back (i, 0, sd.size()) {
			if (p >= 0 && t[p] == sd[i]) {
				da[t[p] - '0']--;
				p--;
			} else if (p == -1 && sd[i] == '0' && da[0] > ua[0]) {
				da[0]--;
			}
		}
		if (p == -1 && ua == da) ans = u;
	}
	printf("%lld %lld\n", ans, ll((__int128)ans * dd / uu));
}
signed main() {
	int T = read();
	while (T--) Solve();
	return 0;
}
