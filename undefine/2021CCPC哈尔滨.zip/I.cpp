#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int M = 1e5+7;
int T,n;
ll cnt[31],tmp[31];
bool check(ll now){
	for(int i=0;i<31;i++)tmp[i]=cnt[i];
	for(int i=0;i<30;i++){
		tmp[i]-=now;
		if(tmp[i]>0)return 0;
		if(tmp[i]<0){
			if(tmp[i]&1)now--;
			tmp[i+1]+=tmp[i]/2;
		}
	}
	return 1;
}
signed main(){
	scanf("%d",&T);
	while (T--) {
		memset(cnt,0,sizeof(cnt));
		scanf("%d",&n);
		for(int i=1;i<=n;i++){
			int x;
			scanf("%d",&x);
			for(int j=0;j<30;j++)if(x&1<<j)cnt[j]++;
		}
		int l=0,r=1e9,res=-1;
		while(l<=r){
			int mid=(l+r)/2;
			if(check(mid))res=mid,r=mid-1;
			else l=mid+1;
		}
		printf("%d\n",res);
	}
	return 0;
}
