#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 1e5+7;
ll read() { ll x; scanf("%lld", &x); return x; }
#define repeat(i, a, b) for (int i = a, ib = b; i < ib; i++)
#define repeat_back(i, a, b) for (int i = b - 1, ib = a; i >= ib; i--)
mt19937 rnd(time(0));
const int n = 10;
const int k = 3;
set<array<int, n>> st;
array<int, n> a;
void dfs() {
	st.insert(a);
	repeat (x, 0, n - k * 2 + 1) {
		repeat (i, 0, k) swap(a[x + i], a[x + i + k]);
		if (!st.count(a)) dfs();
		repeat (i, 0, k) swap(a[x + i], a[x + i + k]);
	}
}
signed main() {
	iota(a.begin(), a.end(), 1);
	dfs();
	for (auto a : st) {
		repeat (i, 0, n) cout << a[i] << ' ';
		cout << endl;
	}
	return 0;
}
