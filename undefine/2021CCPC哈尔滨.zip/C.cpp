#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int M = 1e5+7;
int n,fa[M],A[M],dp[M],cnt[M];
vector<int>E[M];
set<int>st[M];
set<int>solve(set<int>&a,set<int>&b){
	set<int>vi;
	for(auto i:b){
		auto it=a.find(i);
		if(it!=a.end())vi.insert(i);
	}
	return vi;
}
void dfs(int x){
	if(E[x].size()==0){
		st[x].insert(A[x]);
		return;
	}
	if (E[x].size()==1){
		int y =E[x][0];
		dfs(y);
		swap(st[x],st[y]);
		dp[x]=dp[y];
		return;
	}
	int son=0;
	for(auto y:E[x]){
		dfs(y);
		if(st[y].size()>st[son].size())son=y;
		dp[x]+=dp[y]+1;
	}
	int mx=0;
	set<int>fi,se;
	for(auto y:E[x]){
		if(y==son)continue;
		for(auto k:st[y]){
			++cnt[k];
			if(cnt[k]>mx){
				mx=cnt[k];
				se=fi;
				fi.clear();
				fi.insert(k);
			}
			else if(cnt[k]==mx){
				fi.insert(k);
			}
			else if(cnt[k]==mx-1){
				se.insert(k);
			}
		}
	}
	st[x]=solve(st[son],fi);
	if(st[x].size()>0){
		dp[x]-=mx+1;
	}
	else if(mx>1){
		st[x]=solve(st[son],se);
		st[x].insert(fi.begin(), fi.end());
		dp[x]-=mx;
	}
	else if(mx==1){
		swap(st[x],st[son]);
		st[x].insert(fi.begin(), fi.end());
		dp[x]-=mx;
	}
	for(auto y:E[x]){
		if(y==son)continue;
		for(auto k:st[y])cnt[k]=0;
		st[y].clear();
	}
	st[son].clear();
}
signed main() {
//	freopen("jiedai.in","r",stdin);
//	freopen("jiedai.out","w",stdout);
	scanf("%d",&n);
	for(int i=2;i<=n;i++){
		scanf("%d",&fa[i]);
		E[fa[i]].push_back(i);
	}
	for(int i=1;i<=n;i++)scanf("%d",&A[i]);
	dfs(1);
	printf("%d\n",dp[1]+1);
	return 0;
}
