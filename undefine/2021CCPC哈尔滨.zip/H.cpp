#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 1e5+7;
ll read() { ll x; scanf("%lld", &x); return x; }
#define repeat(i, a, b) for (int i = a, ib = b; i < ib; i++)
#define repeat_back(i, a, b) for (int i = b - 1, ib = a; i >= ib; i--)
ll ans;
void merge(int a[], int l, int r) {
	static int t[N];
	if (r - l <= 1) return;
	int mid = l + (r - l) / 2;
	merge(a, l, mid);
	merge(a, mid, r);
	int p = l, q = mid, s = l;
	while (s < r) {
		if (p >= mid || (q < r && a[p] > a[q])) {
			t[s++] = a[q++];
			ans += mid - p;
		} else {
			t[s++] = a[p++];
		}
	}
	repeat (i, l, r) a[i] = t[i];
}
int a[N], b[N];
void Solve() {
	int ls = read();
	repeat (i, 0, ls) a[i] = read();
	int lt = read();
	repeat (i, 0, lt) b[i] = read();
	int k = read();
	
	if (ls != lt) { puts("NIE"); return; }
	int n = ls;
	if (k == 1) {
		sort(a, a + n);
		sort(b, b + n);
		repeat (i, 0, n) if (a[i] != b[i]) {
			puts("NIE");
			return;
		}
		puts("TAK");
		return;
	}
	vector<int> v1, v2, v; v.clear();
	ans = 0;
	int flag = false;
	repeat (offset, 0, k) {
		v1.clear();
		v2.clear();
		for (int i = offset; i < n; i += k) {
			v1.push_back(a[i]);
			v2.push_back(b[i]);
		}
		if (v1.size() == 2) {
			v.push_back(v1[0]);
		}
		merge(v1.data(), 0, v1.size());
		merge(v2.data(), 0, v2.size());
		repeat (i, 1, v1.size()) if (v1[i] == v1[i - 1]) flag = true;
		if (v1 != v2) {
			puts("NIE");
			return;
		}
	}
	repeat (i, 1, v.size()) flag &= v[i] == v[i + 1];
	if (!flag && ans % 2 == 1 && k % 2 == 0)  {
		puts("NIE");
		return;
	}
	puts("TAK");
}
signed main() {
	int T = read();
	while (T--) Solve();
	return 0;
}
