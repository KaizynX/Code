#include <bits/stdc++.h>
using namespace std;
typedef long long ll;


signed main() {
	freopen("jiedai.in","w",stdout);
	srand(time(NULL));
	int n=1e3;
	printf("%d\n",n);
	for(int i=2;i<=n;i++)printf("%d ",rand()%(i-1)+1);puts("");
	for(int i=1;i<=n;i++)printf("%d ",rand()%n+1);puts("");
	
	return 0;
}
