#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 1e3+7;
int n, m;
int a[N][N], col[N], row[N];

signed main(){
	ios::sync_with_stdio(0); cin.tie(0);
	cin >> n >> m;
	memset(col, 0x3f, sizeof col);
	memset(row, 0x3f, sizeof row);
	for (int i = 1; i <= n; ++i)
	for (int j = 1; j <= m; ++j) {
		cin >> a[i][j];
		row[i] = min(row[i], a[i][j]);
		col[j] = min(col[j], a[i][j]);
	}
	int ans = 0;
	for (int i = 1; i <= n; ++i)
	for (int j = 1; j <= m; ++j) {
		ans += a[i][j] == row[i] && a[i][j] == col[j];
	}
	cout << ans << '\n';
	return 0;
}
