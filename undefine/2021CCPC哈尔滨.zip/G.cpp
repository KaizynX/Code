#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 1e5+7;
ll read() { ll x; scanf("%lld", &x); return x; }
#define repeat(i, a, b) for (int i = a, ib = b; i < ib; i++)
#define repeat_back(i, a, b) for (int i = b - 1, ib = a; i >= ib; i--)
const int inf = INT_MAX / 2;
struct node {
	int to, dis;
	bool operator<(const node &b) const {
		return dis > b.dis;
	}
};
bool vis[N];
vector<node> a[N];
void dij(int s, int n, int dis[]) {
	fill(vis, vis + n + 1, 0);
	fill(dis, dis + n + 1, inf); dis[s] = 0;
	static priority_queue<node> q; q.push({s, 0});
	while (!q.empty()) {
		int x = q.top().to; q.pop();
		if (vis[x]) { continue; } vis[x] = 1;
		for (auto i : a[x]) {
			int p = i.to;
			if (dis[p] > dis[x] + i.dis) {
				dis[p] = dis[x] + i.dis;
				q.push({p, dis[p]});
			}
		}
	}
}
int dis[19][N], pos[N], p[N];
int len[1 << 18][18];
long double broken[1 << 18], ans[1 << 18][18];
void Solve() {
//	cout << (1 << 18) * 18 * 18;
	int walk = read(), ride = read();
	int n = read(), m = read();
	repeat (i, 0, m) {
		int x = read(), y = read(), w = read();
		a[x].push_back({y, w});
		a[y].push_back({x, w});
	}
	int k = read();
	repeat (i, 0, k) pos[i] = read(), p[i] = read();
	dij(1, n, dis[k]);

	if (dis[k][n] >= inf) { puts("-1"); return; }

	// calc broken
	broken[0] = 1;
	repeat (mask, 1, (1 << k)) {
		int b = __lg(mask);
		broken[mask] = broken[mask - (1 << b)] * p[b] / 100.0;
	}

	// clear len
	repeat (mask, 0, (1 << k))
	repeat (to, 0, k) {
		len[mask][to] = inf;
		ans[mask][to] = inf;
	}
	long double fin = dis[k][n] * 1.0 / walk;

	// calc dis
	repeat (i, 0, k) {
		dij(pos[i], n, dis[i]);
		len[1 << i][i] = dis[i][1];
		ans[1 << i][i] = dis[i][1] * 1.0 / walk + broken[1 << i] * dis[i][n] / walk
			+ (1 - broken[1 << i]) * dis[i][n] / ride;
		fin = min(fin, ans[1 << i][i]);
	}
//	repeat (i, 0, k) {
//		repeat (j, 1, n + 1) cout << dis[i][j] << ' ';
//		cout << endl;
//	} // dij check ok

	// calc len
	repeat (mask, 1, (1 << k))
	repeat (to, 0, k) if (mask >> to & 1) {
		repeat (from, 0, k) if (from != to && (mask >> from & 1)) {
			int frommask = mask - (1 << to);
			len[mask][to] = min(len[mask][to], len[frommask][from] + dis[from][pos[to]]);

			ans[mask][to] = min(ans[mask][to],
				ans[frommask][from] - broken[frommask] * dis[from][n] / walk
				+ broken[frommask] * dis[from][pos[to]] / walk
				+ broken[mask] * dis[to][n] / walk
				+ (broken[frommask] - broken[mask]) * dis[to][n] / ride);

			fin = min(fin, ans[mask][to]);
//			cout << mask << ' ' << to << ' ' << len[mask][to] << endl;
		}
	}
	printf("%.12f\n", (double)fin);
}
signed main() {
	int T = 1;
//	int T = read();
	while (T--) Solve();
	return 0;
}
