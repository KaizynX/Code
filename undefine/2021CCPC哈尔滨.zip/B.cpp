#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int M=1e5+5;
int n,A[M],ans;
int mark[205];
void solve(int x){
	memset(mark,0,sizeof(mark));
	int res=0,lst=0;
	for(int i=1;i<=n;i++){
		if(x-A[i]>=0&&mark[x-A[i]]){
			res+=2;
			for(int j=lst+1;j<=i;j++)mark[A[j]]=0;
			lst=i;
		}
		else mark[A[i]]=1;
	}
	if(res>ans)ans=res;
}
signed main(){
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&A[i]);
	ans=0;
	for(int i=1;i<=200;i++)solve(i);
	printf("%d\n",ans);
	return 0;
}
