#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 2e5+7;

int n;

signed main() {
	ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
	cin >> n;
	for (int i = 1, x, y; i <= n; ++i) {
		cin >> x >> y;
	}
	printf("%.10f\n", 1.0/n);
	return 0;
}
