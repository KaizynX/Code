#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
const int N = 1e5+7;
const int K = 2e2+7;

int n, k, p;
int sz[N];
ll dp[N][2][K], tmp[2][K];
vector<pii> e[N];

void MAX(ll &x, ll y) {
	if (y > x) x = y;
}

void dfs(int u, int fa) {
	sz[u] = 1;
	dp[u][0][0] = 0;
	for (auto &edge : e[u]) {
		int v = edge.first;
		int w = edge.second;
		if (v == fa) continue;
		dfs(v, u);
		memset(tmp, -1, sizeof tmp);
		for (int i = 0; i <= min(k, sz[v]); ++i) {
			for (int j = 0; j <= min(k, sz[u]); ++j) {
				if (~dp[u][0][j] && ~dp[v][0][i]) MAX(tmp[0][min(k, i+j)], dp[v][0][i]+dp[u][0][j]);
				if (~dp[u][0][j] && ~dp[v][1][i]) MAX(tmp[0][min(k, i+j)], dp[v][1][i]+dp[u][0][j]);
				if (~dp[u][1][j] && ~dp[v][0][i]) MAX(tmp[1][min(k, i+j)], dp[v][0][i]+dp[u][1][j]);
				if (~dp[u][1][j] && ~dp[v][1][i]) MAX(tmp[1][min(k, i+j)], dp[v][1][i]+dp[u][1][j]);
				if (~dp[u][0][j] && ~dp[v][0][i]) MAX(tmp[1][min(k, i+j-1)], dp[v][0][i]+dp[u][0][j]+w);
			}
		}
		memcpy(dp[u], tmp, sizeof tmp);
		sz[u] += sz[v];
	}
	for (int i = k+1; i; --i) dp[u][0][i] = dp[u][0][i-1];
	MAX(dp[u][0][k], dp[u][0][k+1]);
	dp[u][0][0]=-1;
	/*
	for (int i : {0,1}) {
		for (int j = 0; j <= k; ++j) {
			printf("dp[%d][%d][%d]=%lld\n", u, i, j, dp[u][i][j]);
		}
	}
	puts("--------------");
	*/
}

signed main() {
	ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
	memset(dp, -1, sizeof dp);
	cin >> n >> k >> p;
	k = 2*k+1;
	for (int i = 1, u, v, w; i < n; ++i) {
		cin >> u >> v >> w;
		e[u].emplace_back(v, w);
		e[v].emplace_back(u, w);
	}
	dfs(1, 0);
	ll ans = 0;
	for (int i = 0; i <= k; ++i) {
		for (int j : {0, 1}) {
			if (~dp[1][j][i]) MAX(ans, dp[1][j][i]+1ll*(i/2)*p);
		}
	}
	cout << ans << '\n';
	return 0;
}
