#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
template<class T>inline void MAX(T &x,T y){if(y>x)x=y;}
const int M=45;
int n,m,A[M],B[M],cnt[M],id[M];
vector<int>E[M];
int dp[M][(1<<18)+5];
signed main() {
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)scanf("%d",&A[i]);
	for(int i=1;i<=n;i++)scanf("%d",&B[i]);
	for(int i=1;i<=m;i++){
		int a,b;
		scanf("%d%d",&a,&b);
		E[a].push_back(b);
	}
	int all=0;
	for(int i=1;i<=n;i++){
		cnt[A[i]]++;
		if(cnt[A[i]]==2)id[A[i]]=all++;
	}
	memset(dp,-1,sizeof(dp));
	if(cnt[A[1]]>=2)dp[1][1<<id[A[1]]]=B[A[1]];
	else dp[1][0]=B[A[1]];
	for(int i=1;i<n;i++)for(int j=0;j<(1<<all);j++){
		if(dp[i][j]==-1)continue;
		for(auto k:E[i]){
			if(cnt[A[k]]==1)MAX(dp[k][j],dp[i][j]+B[A[k]]);
			else if(j&1<<id[A[k]])MAX(dp[k][j],dp[i][j]);
			else MAX(dp[k][j|1<<id[A[k]]],dp[i][j]+B[A[k]]);
		}
	}
	for(int i=1;i<=n;i++){
		int ans=-1;
		for(int j=0;j<(1<<all);j++)MAX(ans,dp[i][j]);
		printf("%d\n",ans);
	}
	return 0;
}
