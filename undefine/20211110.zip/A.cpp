#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 2e2+7;

int n, x, y, m;
int k[N], p[N];

signed main() {
	ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
	cin >> n >> x >> y;
	for (int i = 1; i <= n; ++i) cin >> k[i];
	cin >> m;
	for (int i = 1; i <= m; ++i) cin >> p[i];
	int fl = 0, fr = 0;
	for (int i = 1; i <= m; ++i) {
		if (x+i <= n && k[x+i] == p[i]) ++fr;
	}
	for (int i = 1; i <= m; ++i) {
		if (x-i >= 1 && k[x-i] == p[i]) ++fl;
	}
	fl = fl == m;
	fr = fr == m;
	if (fl && fr) cout << "Unsure\n";
	else if ((x < y && fr) || (x > y && fl)) cout << "Right\n";
	else cout << "Wrong\n";
	return 0;
}
