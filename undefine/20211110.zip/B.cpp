#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 2e5+7;
const int LOG = 18;

int n, m, q;
char s[N];
int nex[N][26], jmp[N][LOG];
// string [1, n]
// nex[i][j] i'th pos has been fixed, the nex char j's pos 
// jmp[i][j] fixed i'th, use 2^j char can goto somewhere

signed main() {
	ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
	cin >> m >> n >> s >> q;
	fill(nex[n], nex[n]+m, n+1);
	fill(jmp[0], jmp[0]+N*LOG, n+1);
	for (int i = n-1; i >= 0; --i) {
		memcpy(nex[i], nex[i+1], sizeof(int)*m);
		nex[i][s[i]-'a'] = i+1;
		jmp[i][0] = *max_element(nex[i], nex[i]+m);
		for (int j = 1; j < LOG; ++j) {
			jmp[i][j] = jmp[jmp[i][j-1]][j-1];
		}
	}
	for (int i = 1, l, r; i <= q; ++i) {
		cin >> l >> r;
		int ans = 1;
		--l;
		for (int j = LOG-1; j >= 0; --j) {
//			printf("jmp[%d][%d]=%d\n", l, j, jmp[l][j]);
			if (jmp[l][j] > r) continue;
			l = jmp[l][j];
			ans += 1<<j;
		}
		cout << ans << '\n';
	}
	return 0;
}
