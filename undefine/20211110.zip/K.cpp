#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

signed main() {
	ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
	int n, cnt = 0;
	string s;
	cin >> n;
	getline(cin, s);
	for (int i = 1; i <= n; ++i) {
		getline(cin, s);
		for (char c : s) cnt += c == '-'; 
	}
	cout << cnt << '\n';
	return 0;
}
