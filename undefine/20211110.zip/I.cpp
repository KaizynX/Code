#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int M=55;
int n,m,q;
char A[M][M],Q[M*M];
int rx[]={-1,-1,0,1,1,1,0,-1};
int ry[]={0,1,1,1,0,-1,-1,-1};
bool check(int x,int y){
	if(x<1||x>n||y<1||y>m||A[x][y]=='#')return 1;
	return 0;
}
signed main() {
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)scanf("%s",A[i]+1);
	scanf("%d%s",&q,Q+1);
	int x,y,op=0,v=0;
	for(int i=1;i<=n;i++)for(int j=1;j<=m;j++)if(A[i][j]=='*'){
		x=i,y=j;break;
	}
	for(int i=1;i<=q;i++){
		if(0);
		else if(Q[i]=='U'){
			int flag=0;
			v++;
			for(int j=1;j<=v;j++){
				int xx=x+rx[op];
				int yy=y+ry[op];
				if(check(xx,yy)){flag=1;v=0;break;}
				if(op%2==1&&check(x,yy)&&check(xx,y)){flag=1;v=0;break;}
				x=xx,y=yy;
			}
			if(flag)printf("Crash! ");
			printf("%d %d\n",x,y);
		}
		else if(Q[i]=='D'){
			int flag=0;
			v=max(v-1,0);
			for(int j=1;j<=v;j++){
				int xx=x+rx[op];
				int yy=y+ry[op];
				if(check(xx,yy)){flag=1;v=0;break;}
				if(op%2==1&&check(x,yy)&&check(xx,y)){flag=1;v=0;break;}
				x=xx,y=yy;
			}
			if(flag)printf("Crash! ");
			printf("%d %d\n",x,y);
		}
		else if(Q[i]=='L'){
			int flag=0;
			op=(op+7)%8;
			for(int j=1;j<=v;j++){
				int xx=x+rx[op];
				int yy=y+ry[op];
				if(check(xx,yy)){flag=1;v=0;break;}
				if(op%2==1&&check(x,yy)&&check(xx,y)){flag=1;v=0;break;}
				x=xx,y=yy;
			}
			if(flag)printf("Crash! ");
			printf("%d %d\n",x,y);
		}
		else if(Q[i]=='R'){
			int flag=0;
			op=(op+1)%8;
			for(int j=1;j<=v;j++){
				int xx=x+rx[op];
				int yy=y+ry[op];
				if(check(xx,yy)){flag=1;v=0;break;}
				if(op%2==1&&check(x,yy)&&check(xx,y)){flag=1;v=0;break;}
				x=xx,y=yy;
			}
			if(flag)printf("Crash! ");
			printf("%d %d\n",x,y);
		}
	}
	return 0;
}
