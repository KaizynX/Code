#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int M=1e5+5;
int cas,n,A[M];
int mark[M],bit[M];
ll ans[M];
void add(int x){
	while(x)bit[x]++,x-=x&-x;
}
int query(int x){
	int res=0;
	while(x<=n)res+=bit[x],x+=x&-x;
	return res;
}
signed main() {
	scanf("%d",&cas);
	while(cas--){
		scanf("%d",&n);
		for(int i=1;i<=n;i++)scanf("%d",&A[i]);
		for(int i=1;i<=n;i++)mark[i]=bit[i]=0;
		int mx=0,pos=0;
		for(int i=1;i<=n;i++){
			ans[i]=ans[i-1]+query(A[i]+1);
			if(A[i]>mx){
				mx=A[i];
				if(i>1){
					ans[i]++;
					if(pos)ans[i]+=i-pos+1,pos=0;
					else ans[i]++;
				}
			}
			else if(A[i]==mx&&pos==0)pos=i;
			if(mark[A[i]]==0)add(A[i]),mark[A[i]]=1;
		}
		for(int i=1;i<=n;i++)printf("%lld%c",ans[i],i==n?'\n':' ');
	}
	return 0;
}

