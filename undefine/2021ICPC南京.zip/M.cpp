#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 1e6+7;
#define int ll
int n;
int a[N];

void Solve() {
	scanf("%lld", &n);
	int pos = 0, neg = 0;
	ll sum = 0, ans = 0;
	for (int i = 1; i <= n; ++i) {
		scanf("%lld", a+i);
		if (a[i] <= 0) ++neg;
		if (a[i] >= 0) ++pos;
		sum += a[i];
		ans += abs(a[i]);
	}
	if (n == 1) {
		printf("%lld\n", sum);
	} else if (pos && neg) {
		printf("%lld\n", ans);
	} else if (!pos) {
		printf("%lld\n", *max_element(a+1, a+n+1)*2-sum);
	} else if (!neg) {
		printf("%lld\n", -*min_element(a+1, a+n+1)*2+sum);
	}
}

signed main() {
	int T;
	scanf("%lld", &T);
	while (T--) Solve();
	return 0;
}
