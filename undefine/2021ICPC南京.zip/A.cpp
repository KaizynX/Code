#include <bits/stdc++.h>
using namespace std;

signed main() {
	int n, a, b, x, y;
	cin >> n >> a >> b;
	if (a <= n / 2) {
		for (int i = 0; i < n - 1; i++) printf("U");
		x = 1;
	} else {
		for (int i = 0; i < n - 1; i++) printf("D");
		x = n;
	}
	if (b <= n / 2) {
		for (int i = 0; i < n - 1; i++) printf("L");
		y = 1;
	} else {
		for (int i = 0; i < n - 1; i++) printf("R");
		y = n;
	}
	for (int i = x; i < a; i++) printf("D");
	for (int i = x; i > a; i--) printf("U");
	for (int i = y; i < b; i++) printf("R");
	for (int i = y; i > b; i--) printf("L");
	return 0;
}
