#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 1e5+7;
const ll inf = 1e18;
//#define int ll
int n;
int a[N], t[N];
ll dp[2][N]; // 0 take no son | 1 take normal 
vector<int> e[N];
multiset<ll> st;

inline void MAX(ll &x, ll y) {
	if (x < y) x = y;
}

void dfs(int u, int fa) {
	// assert(dp[0][v] <= dp[1][v])
	ll sum = 0, mx = 0;
	for (int &v : e[u]) if (v != fa) {
		dfs(v, u);
		MAX(mx, a[v]);
		sum += dp[1][v];
	}
	dp[0][u] = sum;
	dp[1][u] = sum+mx;
	st.clear();
	for (int &v : e[u]) if (v != fa) {
		st.insert(dp[0][v]+a[v]-dp[1][v]);
	}
	if (st.size() <= 1u) return;
	for (int &v : e[u]) if (v != fa && t[v] == 3) {
		st.erase(st.find(dp[0][v]+a[v]-dp[1][v]));
		MAX(dp[1][u], sum+a[v]+*st.rbegin());
		st.insert(dp[0][v]+a[v]-dp[1][v]);
	}
}

void Solve() {
	scanf("%d", &n);
	for (int i = 1; i <= n; ++i) scanf("%d", a+i);
	for (int i = 1; i <= n; ++i) scanf("%d", t+i);
	for (int i = 1, u, v; i < n; ++i) {
		scanf("%d%d", &u, &v);
		e[u].emplace_back(v);
		e[v].emplace_back(u);
	}
	dfs(1, 0);
	printf("%lld\n", max(dp[0][1], dp[1][1])+a[1]);
}

signed main() {
	int T;
	scanf("%d", &T);
	while (T--) {
		Solve();
		for (int i = 1; i <= n; ++i) {
			e[i].clear();
			dp[0][i] = dp[1][i] = 0;
		}
	}
	return 0;
}

