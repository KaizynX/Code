#pragma GCC optimize(2)
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 2e6+7;
ll read() { ll x; scanf("%lld", &x); return x; }
#define repeat(i, a, b) for (int i = a, ib = b; i < ib; i++)
#define int ll
vector<int> a[N];
int work(int r, int &p, vector<int> &a) {
	int pre = p;
	while (p < (int)a.size() && a[p] < r) p++;
	return p - pre;
}
signed main() {
	int n = read(), k = read();
	repeat (i, 0, n) {
		int x = read();
		if (k < 0) x = -x;
		a[x + 1000000].push_back(1);
		if (k != 0 && x + 1000000 + abs(k) < N) a[x + 1000000 + abs(k)].push_back(-1);
	}
	k = abs(k);
	int ans = 0;
//	repeat (i, 0, N) ans = max(ans, (int)a[i].size());
	repeat (i, k, N) if (!a[i].empty()) {
		int sum = 0, s = 0, now = 0;
		for (auto j : a[i]) {
			s += j;
			sum += j;
			sum = min(sum, 0ll);
			now = min(sum, now);
		}
//		repeat (j, 0, a[i].size()) cout << a[i][j] << '|';
//		cout << endl;
//		cout << now << ' ' << s << ' ' << ((int)a[i].size() + s - now * 2) / 2 << endl;
		ans = max(ans, ((int)a[i].size() + s - now * 2) / 2);
	}
	printf("%lld\n", ans);
	return 0;
}
