//#pragma GCC optimize(2)
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 1e6+7;
ll read() { ll x; scanf("%lld", &x); return x; }
#define repeat(i, a, b) for (int i = a, ib = b; i < ib; i++)
// #define int ll
vector<int> prime, dr;
map<int, int> arcdr;
void get_primedivisor(int n) {
	for (int i = 2; i * i <= n; i++) {
		if (n % i == 0) prime.push_back(i);
		while (n % i == 0) n /= i;
	}
	if (n > 1) prime.push_back(n);
}
int dp[2005][2][2];
void get_divisor(int n) {
	int cnt = 0;
	for (int i = 1; i < n; i = n / (n / (i + 1))) {
		if (n % i == 0)
			dr.push_back(i), arcdr[i] = cnt++;
	}
	dr.push_back(n), arcdr[n] = cnt++;
}
//map<array<int, 3>, int> mp;
int A;
//int dfs(int a, int dd, int flag) {
//	if (dp[dd][flag].count(a)) return dp[dd][flag][a];
//	int d = dr[dd], t = (a > 0 ? a / d : -a / d, ans = 1e9;
//	if (d == 1) return a + flag;
//	for (auto i : prime) if (d % i == 0) {
//		ans = min(ans, dfs(a - t * d, arcdr[d / i], flag || t != 0) + t);
//		ans = min(ans, dfs((t + 1) * d - a, arcdr[d / i], 1) + t + 1);
//	}
////	printf("a = %d, d = %d, flag = %d, return %d\n", a, d, flag, ans + flag);
//	return dp[dd][flag][a] = ans + flag;
//}
// 223092870 446185740
void Solve() {
//	int a = 233, b = 735134400 + 233;
	int a = read(), b = read();
//	repeat (i, 0, 2005) repeat (j, 0, 2) repeat (k, 0, 2) dp[i][j][k] = 0;
	dr.clear(), prime.clear();
	if (a > b) swap(a, b);
	A = a;
	b -= a;
	get_primedivisor(b);
	get_divisor(b);
	for (int flag = 1; flag >= 0; flag--)
	repeat (dd, 0, dr.size()) {
		int d = dr[dd];
		if (d == 1) {
//			cout << 1 << endl;
			dp[dd][flag][0] = flag + 1;
			dp[dd][flag][1] = flag;
		} else {
			int from = A % d;
			int ans = 1e9;
			for (auto i : prime) if (d % i == 0) {
				int step = d / i;
				int to = A % step;
				ans = min(ans, dp[arcdr[step]][flag || from != to][1] + abs(from - to) / step);
				to = A % step - step;
				ans = min(ans, dp[arcdr[step]][flag || from != to][0] + abs(from - to) / step);
			}
			dp[dd][flag][1] = ans + flag;
			from = A % d - d;
			ans = 1e9;
			for (auto i : prime) if (d % i == 0) {
				int step = d / i;
				int to = A % step;
				ans = min(ans, dp[arcdr[step]][flag || from != to][1] + abs(from - to) / step);
				to = A % step - step;
				ans = min(ans, dp[arcdr[step]][flag || from != to][0] + abs(from - to) / step);
			}
			dp[dd][flag][0] = ans + flag;
		}
//		printf("d=%d flag=%d dp0=%d dp1=%d\n", d, flag, dp[dd][flag][0], dp[dd][flag][1]);
	}
	int ans = 1e9;
	int from = A, to = A % b;
	ans = min(ans, dp[arcdr[b]][from != to][1] + abs(from - to) / b);
	from = A, to = A % b - b;
	ans = min(ans, dp[arcdr[b]][from != to][0] + abs(from - to) / b);
	printf("%d\n", ans - 2);
}
signed main() {
	int T = read();
	while (T--) Solve();
	return 0;
}
