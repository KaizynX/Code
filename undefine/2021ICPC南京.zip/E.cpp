#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int M=1e5+5;
const int mod=1e9+7;
int n,m,q,A[M],L[M],R[M],V[M],ans[M];
struct node{
	int l,r,v,id;
};
vector<node>Q[M];
void add(int &x,ll y){
	x+=y%mod;
	if(x>=mod)x-=mod;
}
struct Tree{
	int s1[M<<2],s2[M<<2],lazy[M<<2];
	void down(int p,int l,int r){
		int &v=lazy[p];
		if(v){
			int mid=l+r>>1,ls=(p<<1),rs=(p<<1|1);
			add(s2[ls],1ll*v*v*(mid-l+1)+2ll*v*s1[ls]);
			add(s1[ls],1ll*v*(mid-l+1));
			add(lazy[ls],v);
			add(s2[rs],1ll*v*v*(r-mid)+2ll*v*s1[rs]);
			add(s1[rs],1ll*v*(r-mid));
			add(lazy[rs],v);
			v=0;
		}
	}
	void update(int a,int b,int v,int l=1,int r=n,int p=1){
		if(l>b||r<a)return;
		if(l>=a&&r<=b){
			add(s2[p],1ll*v*v*(r-l+1)+2ll*v*s1[p]);
			add(s1[p],1ll*v*(r-l+1));
			add(lazy[p],v);
			return;
		}
		down(p,l,r);
		int mid=l+r>>1;
		update(a,b,v,l,mid,p<<1);
		update(a,b,v,mid+1,r,p<<1|1);
		s1[p]=(s1[p<<1]+s1[p<<1|1])%mod;
		s2[p]=(s2[p<<1]+s2[p<<1|1])%mod;
	}
	int query1(int a,int b,int l=1,int r=n,int p=1){
		if(l>b||r<a)return 0;
		if(l>=a&&r<=b)return s1[p];
		down(p,l,r);
		int mid=l+r>>1;
		return (query1(a,b,l,mid,p<<1)+query1(a,b,mid+1,r,p<<1|1))%mod;
	}
	int query2(int a,int b,int l=1,int r=n,int p=1){
		if(l>b||r<a)return 0;
		if(l>=a&&r<=b)return s2[p];
		down(p,l,r);
		int mid=l+r>>1;
		return (query2(a,b,l,mid,p<<1)+query2(a,b,mid+1,r,p<<1|1))%mod;
	}
}T1;
struct Tree2{
	int sx[M<<2],sd[M<<2],zx[M<<2],zd[M<<2],zv[M<<2],zk[M<<2];
	void giao(int i, int len, int v) {
		lazy[i] += v;
		sk[i] += 2*v2*len;
		skx[i] += 2*v2*len*sx[i];
		sb[i] += 2*sv[i]*v2-v2*v2*len;
		sv[i] += 1ll*len*v;
	}
	void push_up(int i) {
		skx[i]=(skx[i<<1]+skx[i<<1|1])%mod;
		sk[i]=(sk[i<<1]+sk[i<<1|1])%mod;
		sv[i]=(sv[i<<1]+sv[i<<1|1])%mod;
		sb[i]=(sb[i<<1]+sb[i<<1|1])%mod;
	}
	void down(int p,int l,int r){
		int lenl = (r-l+1)/2, lenr = (r-l)/2;
		sd[p<<1] += zd[p]*lenl+zk[p]*sx[p<<1]+lenl*zv[p];
		sx[p<<1] += zx[p];
		zx[p<<1] += zx[p];
		zd[p<<1] += ;
		zk[p<<1] += 
	}
	void build(int l=1,int r=n,int p=1) {
		sx[p]=sv[p]=sk[p]=sb[p]=skx[p]=0;
		if (l == r) return sx[p] = A[l], void();
		int mid=l+r>>1;
		build(l,mid,p<<1);
		build(mid+1,r,p<<1|1);
		sx[i]=sx[i<<1]+sx[i<<1|1];
	}
	void update(int a,int b,int t,int v,int l=1,int r=n,int p=1){
		if(l>b||r<a)return;
		if(l>=a&&r<=b) {
			sd[p] += 2*t*v*sx[p];
			sx[p] += (r-l+1)*v;
			zd[p] += 2*t*v*zx[p];
			zx[p] += v;
			zk[p] += 2*t*v;
			zv[p] += t*v*v;
			return;
		}
		down(p,l,r);
		int mid=l+r>>1;
		update(a,b,v,l,mid,p<<1);
		update(a,b,v,mid+1,r,p<<1|1);
		push_up(p);
	}
	int query(int a,int b,int l=1,int r=n,int p=1){
		if(l>b||r<a)return 0;
		if(l>=a&&r<=b)return skx[p]+sb[p];
		down(p,l,r);
		int mid=l+r>>1;
		return (query1(a,b,l,mid,p<<1)+query1(a,b,mid+1,r,p<<1|1))%mod;
	}
}T2;
signed main() {
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++)scanf("%d",&A[i]);
	for(int i=1;i<=m;i++)scanf("%d%d%d",&L[i],&R[i],&V[i]);
	T2.build();
	for(int i=1;i<=q;i++){
		int l,r,x,y;
		scanf("%d%d%d%d",&l,&r,&x,&y);
		if(x-1>=0)Q[x-1].push_back((node){l,r,-1,i});
		Q[y].push_back((node){l,r,1,i});
	}
	for(int i=1;i<=n;i++)T1.update(i,i,A[i]);
	for(int i=0;i<=m;i++){
		if(i){
			T1.update(L[i],R[i],V[i]);
//			T2.update(L[i],R[i],1ll*V[i]*V[i]%mod*i%mod);
			T2.update(L[i],R[i],t,V[i]);
		}
		for(auto tmp:Q[i]){
			int l=tmp.l,r=tmp.r,v=tmp.v,id=tmp.id;
			int res=(1ll*T1.query2(l,r)*(i+1)%mod-T2.query1(l,r)+mod)%mod;
			add(ans[id],(v*res+mod)%mod);
		}
		printf("i=%d  ",i);for(int j=1;j<=n;j++)printf("%d ",T1.query1(j,j));puts("");
	}
	for(int i=1;i<=q;i++)printf("%d\n",ans[i]);
	return 0;
}

