#pragma GCC optimize(3)
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
template<class T>inline void rd(T &x){
	x=0;char o;
	while(o=getchar(),o<48);
	do x=(x<<3)+(x<<1)+(o^48);
	while(o=getchar(),o>47);
}
const int M=1e6+5;
int n,q,A[M],B[M],C[M];
char str1[M],str2[M];
int val[M<<2],cnt0[M<<2],cnt9[M<<2],lazy[M<<2];
void build(int l=0,int r=n,int p=1){
	lazy[p]=-1;
	if(l==r){
		val[p]=C[l];
		cnt0[p]=(C[l]==0);
		cnt9[p]=(C[l]==9);
		return;
	}
	int mid=l+r>>1;
	build(l,mid,p<<1);
	build(mid+1,r,p<<1|1);
	cnt0[p]=cnt0[p<<1]+cnt0[p<<1|1];
	cnt9[p]=cnt9[p<<1]+cnt9[p<<1|1];
	val[p]=(val[p<<1]==val[p<<1|1]?val[p<<1]:-1);
}
void down(int p,int l,int r){
	if(~lazy[p]){
		int mid=l+r>>1;
		lazy[p<<1]=lazy[p<<1|1]=lazy[p];
		val[p<<1]=val[p<<1|1]=lazy[p];
		if(lazy[p]==0){
			cnt0[p<<1]=(mid-l+1);
			cnt0[p<<1|1]=(r-mid);
			cnt9[p<<1]=cnt9[p<<1|1]=0;
		}
		else{
			cnt9[p<<1]=(mid-l+1);
			cnt9[p<<1|1]=(r-mid);
			cnt0[p<<1]=cnt0[p<<1|1]=0;
		}
		lazy[p]=-1;
	}
}
void update1(int x,int v,int l=0,int r=n,int p=1){
	if(l==r){
		val[p]+=v;
		if(val[p]==0)cnt0[p]=1,cnt9[p]=0;
		else if(val[p]==9)cnt0[p]=0,cnt9[p]=1;
		else cnt0[p]=0,cnt9[p]=0;
		return;
	}
	down(p,l,r);
	int mid=l+r>>1;
	if(x<=mid)update1(x,v,l,mid,p<<1);
	else update1(x,v,mid+1,r,p<<1|1);
	cnt0[p]=cnt0[p<<1]+cnt0[p<<1|1];
	cnt9[p]=cnt9[p<<1]+cnt9[p<<1|1];
	val[p]=(val[p<<1]==val[p<<1|1]?val[p<<1]:-1);
}
void update2(int a,int b,int v,int l=0,int r=n,int p=1){
	if(l>b||r<a)return;
	if(l>=a&&r<=b){
		val[p]=v;
		if(v==0)lazy[p]=0,cnt0[p]=r-l+1,cnt9[p]=0;
		else if(v==9)lazy[p]=9,cnt0[p]=0,cnt9[p]=r-l+1;
		else lazy[p]=-1,cnt0[p]=0,cnt9[p]=0;
		return;
	}
	down(p,l,r);
	int mid=l+r>>1;
	update2(a,b,v,l,mid,p<<1);
	update2(a,b,v,mid+1,r,p<<1|1);
	cnt0[p]=cnt0[p<<1]+cnt0[p<<1|1];
	cnt9[p]=cnt9[p<<1]+cnt9[p<<1|1];
	val[p]=(val[p<<1]==val[p<<1|1]?val[p<<1]:-1);
}
int query(int x,int l=0,int r=n,int p=1){
	if(~val[p])return val[p];
	down(p,l,r);
	int mid=l+r>>1;
	if(x<=mid)return query(x,l,mid,p<<1);
	else return query(x,mid+1,r,p<<1|1);
}
int query0(int x,int l=0,int r=n,int p=1){
	if(l==r)return val[p]==0;
	if(x==r&&cnt0[p]==r-l+1)return r-l+1;
	down(p,l,r);
	int mid=l+r>>1;
	if(x<=mid)return query0(x,l,mid,p<<1);
	else{
		int tmp=query0(x,mid+1,r,p<<1|1);
		if(tmp==x-mid)tmp+=query0(mid,l,mid,p<<1);
		return tmp;
	}
}
int query9(int x,int l=0,int r=n,int p=1){
	if(l==r)return val[p]==9;
	if(x==r&&cnt9[p]==r-l+1)return r-l+1;
	down(p,l,r);
	int mid=l+r>>1;
	if(x<=mid)return query9(x,l,mid,p<<1);
	else{
		int tmp=query9(x,mid+1,r,p<<1|1);
		if(tmp==x-mid)tmp+=query9(mid,l,mid,p<<1);
		return tmp;
	}
}
signed main(){
	rd(n),rd(q);
	scanf("%s%s",str1+1,str2+1);
	for(int i=1;i<=n;i++)A[i]=str1[i]-'0';
	for(int i=1;i<=n;i++)B[i]=str2[i]-'0';
	for(int i=1;i<=n;i++)C[i]=A[i]+B[i];
	for(int i=n;i>=1;i--)if(C[i]>=10)C[i]-=10,C[i-1]++;
	build();
	while(q--){
		int a,b,c;
		rd(a),rd(b),rd(c);
		int sum1=A[b]+B[b];
		if(a==1)A[b]=c;
		else B[b]=c;
		int sum2=A[b]+B[b];
		int val1=query(b);
		int val2=val1+sum2-sum1;
		if(val1==val2)printf("%d %d\n",val1,0);
		else if(val2<0){
			int len=query0(b-1);
			update1(b-len-1,-1);
			if(len)update2(b-len,b-1,9);
			update1(b,sum2-sum1+10);
			printf("%d %d\n",val2+10,min(b,len+2)+1);
		}
		else if(val2>=10){
			int len=query9(b-1);
			update1(b-len-1,+1);
			if(len)update2(b-len,b-1,0);
			update1(b,sum2-sum1-10);
			printf("%d %d\n",val2-10,min(b,len+2)+1);
		}
		else{
			update1(b,sum2-sum1);
			printf("%d %d\n",val2,2);
		}
	}
	return 0;
}
