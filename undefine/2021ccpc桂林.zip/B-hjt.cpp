#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 1e5 + 7;
#define int ll
#define fi first
#define se second
ll read() { ll x; cin >> x; return x; }
struct seg {
	ll U(ll x, ll y) { return x + y; }
	static const ll a0 = 0;
	void toz(ll x) { z += x, state = 1; }
	void toa() { a += z * (r - l + 1), z = 0, state = 0; }
	ll a, z; bool state;
	int l, r; seg *lc, *rc; 
	void init(int _l, int _r, seg *&pl) {
		l = _l, r = _r; state = 0; z = 0;
		if (l == r) { a = a0; return; }
		int m = (l + r) >> 1;
		lc = ++pl; lc->init(l, m, pl);
		rc = ++pl; rc->init(m + 1, r, pl);
		up();
	}
	void build(ll in[]) {
		if (l == r) { a = in[l]; return; }
		lc->build(in); rc->build(in);
		up();
	} 
	void up() { a = U(lc->a, rc->a); }
	void down() {
		if (!state) return;
		if (l < r) { lc->toz(z); rc->toz(z); }
		toa();
	}
	void update(int x, int y, ll k) {
		if (x > r || y < l) { down(); return; }
		if (x <= l && y >= r) { toz(k); down(); return; }
		down();
		lc->update(x, y, k);
		rc->update(x, y, k);
		up();
	}
	ll query(int x, int y) {
		if (x > r || y < l) return a0;
		down();
		if (x <= l && y >= r) return a;
		return U(lc->query(x, y), rc->query(x, y));
	}
} tr[N * 2], *pl;
void init(int l, int r, ll in[] = nullptr) {
	pl = tr;
	tr->init(l, r, pl);
	if (in) tr->build(in);
}
signed main() {
	ios::sync_with_stdio(0); cin.tie(0);
//	int T; cin >> T; 
//	while (T--) {
//	}
	int n = read(), q = read();
	cin >> A >> B;
	
	return 0;
}
