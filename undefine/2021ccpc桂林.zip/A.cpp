#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
signed main(){
	int T;
	cin >> T;
	while (T--) {
		ll x;
		cin >> x;
		cout << x*2-1 << '\n';
	}
	return 0;
}
