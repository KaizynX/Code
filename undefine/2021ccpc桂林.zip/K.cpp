#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 51;
const int M = 2501;
const int INF = 2e9;

int n, m;
int w[M], e[N][N], d[N];
int cnt[M], ans[N], cur;
vector<int> to[N];
queue<int> q;

void dfs(int u) {
	ans[u] = min(ans[u], cur);
	for (int v : to[u]) {
		cur += w[e[u][v]]*(++cnt[e[u][v]]);
		dfs(v);
		cur -= w[e[u][v]]*(cnt[e[u][v]]--);
	}
}

signed main(){
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= m; ++i) scanf("%d", w+i);
	for (int i = 1, u, v, c; i <= m; ++i) {
		scanf("%d%d%d", &u, &v, &c);
		e[u][v] = e[v][u] = c;
	}
	q.push(1);
	d[1] = 1;
	while (q.size()) {
		int u = q.front(); q.pop();
		for (int i = 1; i <= n; ++i) {
			if (d[i] || !e[u][i]) continue;
			q.push(i);
			d[i] = d[u]+1;
		}
	}
//	for (int i = 1; i <= n; ++i) cout << d[i] << " \n"[i==n];
	for (int i = 1; i <= n; ++i)
	for (int j = 1; j <= n; ++j) {
		if (d[i]+1 == d[j] && e[i][j]) {
			to[i].emplace_back(j);
//			cout << i << ' ' << j << '\n';
		}
	}
	for (int i = 1; i <= n; ++i) ans[i] = INF;
	dfs(1);
	for (int i = 2; i <= n; ++i) printf("%d\n", ans[i]);
	return 0;
}
