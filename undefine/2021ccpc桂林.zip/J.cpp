#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, int> pli;
const int N = 1e6+7;

template <typename T = int> struct DSU {
  vector<int> fa;
  vector<T> w;
  void init(int n, T v = 1) {
    fa = vector<int>(n+1);
    iota(fa.begin(), fa.end(), 0);
    w = vector<T>(n+1, v);
  }
  void init(int n, T a[]) {
    fa = vector<int>(n+1);
    iota(fa.begin(), fa.end(), 0);
    w = vector<T>(a, a+n+1);
  }
  int get(int s) { return s == fa[s] ? s : fa[s] = get(fa[s]); }
  int& operator [] (int i) { return fa[get(i)]; }
  bool merge(int x, int y) { // merge x to y
    x = get(x); y = get(y);
    return x == y ? false : (w[y] = min(w[y], w[x]), fa[x] = y, true);
  }
};

int n, m;
int rkh[N];
pii ans[N];
ll sum[N];
char str[N];
vector<pli> q[N];
DSU<int> dsu;

int tr[N<<2];
void tree_update(int x, int v = 1, int l = 1, int r = n, int i = 1) {
	tr[i] += v;
	if (l == r) return;
	int mid = (l+r)>>1;
	if (x <= mid) tree_update(x, v, l, mid, i<<1);
	else tree_update(x, v, mid+1, r, i<<1|1);
}
int tree_query(int x, int l = 1, int r = n, int i = 1) {
	if (l == r) return l;
	int mid = (l+r)>>1;
	if (tr[i<<1] >= x) return tree_query(x, l, mid, i<<1);
	else return tree_query(x-tr[i<<1], mid+1, r, i<<1|1);
}


int sa[N], rk[N<<1], height[N];
template <typename T> // s start from 1
inline void SA(const T *s, const int &n) {
#define cmp(x, y, w) oldrk[x] == oldrk[y] && oldrk[x + w] == oldrk[y + w]
  static int oldrk[N<<1], id[N], px[N], cnt[N], m;
  // memset(oldrk+n+1, 0, sizeof(int)*n); // multi testcase
  memset(cnt, 0, sizeof(int) * (m = 128));
  for (int i = 1; i <= n; ++i) ++cnt[rk[i] = s[i]];
  for (int i = 1; i <= m; ++i) cnt[i] += cnt[i - 1];
  for (int i = n; i; --i) sa[cnt[rk[i]]--] = i;
  for (int w = 1, p, i; w <= n; w <<= 1, m = p) {
    for (p = 0, i = n; i > n - w; --i) id[++p] = i;
    for (i = 1; i <= n; ++i) if (sa[i] > w) id[++p] = sa[i] - w;
    memset(cnt + 1, 0, sizeof(int) * m);
    for (i = 1; i <= n; ++i) ++cnt[px[i] = rk[id[i]]];
    for (i = 1; i <= m; ++i) cnt[i] += cnt[i - 1];
    for (i = n; i; --i) sa[cnt[px[i]]--] = id[i];
    swap(oldrk, rk); // memcpy(oldrk+1, rk+1, sizeof(int)*n);
    for (p = 0, i = 1; i <= n; ++i) rk[sa[i]] = cmp(sa[i], sa[i - 1], w) ? p : ++p;
  }
  for (int i = 1, k = 0; i <= n; ++i) {
    if (k) --k;
    while (s[i+k] == s[sa[rk[i]-1]+k]) ++k;
    height[rk[i]] = k;
  }
#undef cmp
}

signed main(){
	scanf("%s%d", str+1, &m);
	n = strlen(str+1);
	SA(str, n);
	dsu.init(n);
	for (int i = 1; i <= n; ++i) {
		sum[height[i]+1]++;
		sum[n-sa[i]+2]--;
		dsu.w[i] = sa[i];
		rkh[i] = i;
	}
//	for (int i = 1; i <= n; ++i) cout << sa[i] << " \n"[i==n];
//	for (int i = 1; i <= n; ++i) cout << rk[i] << " \n"[i==n];
//	for (int i = 1; i <= n; ++i) cout << height[i] << " \n"[i==n];
	sort(rkh+1, rkh+n+1, [&](int x, int y) {
		return height[x] < height[y];
	});
	for (int i = 1; i <= n; ++i) sum[i] += sum[i-1];
	for (int i = 1; i <= n; ++i) sum[i] += sum[i-1];
	for (int i = 1; i <= m; ++i) {
		static ll k;
		scanf("%lld", &k);
		ans[i] = pii{-1, -1};
		if (k > sum[n]) continue;
		int l = 1, r = n, mid;
		while (l < r) {
			mid = (l+r)>>1;
			if (sum[mid] >= k) r = mid;
			else l = mid+1;
		}
		q[l].emplace_back(k-sum[l-1], i);
//		cout << l << ' ' << k-sum[l-1] << ' ' << i << '\n';
	}
	
	for (int i = n, j = n; i; --i) {
		tree_update(rk[n-i+1]);
		while (height[rkh[j]] >= i) {
			dsu.merge(rkh[j], rkh[j]-1);
			tree_update(rkh[j], -1);
			--j;
		}
		for (auto &qq : q[i]) {
			ll k = qq.first;
			int id = qq.second;
			int p = tree_query(k);
//			cout << id << ' ' << k << ' ' << p << '\n';
			p = dsu.w[dsu[p]];
			ans[id] = pii{p, p+i-1};
		}
	}
	for (int i = 1; i <= m; ++i) {
		printf("%d %d\n", ans[i].first, ans[i].second);
	}
	return 0;
}
