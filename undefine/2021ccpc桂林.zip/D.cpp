#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 1e5 + 7;
#define int ll
#define fi first
#define se second
ll read() { ll x; cin >> x; return x; }
int pos[N], to[N];
signed main() {
	ios::sync_with_stdio(0); cin.tie(0);
	int T;
	cin >> T; 
	while (T--) {
		int n = read();
		for (int i = 1; i <= n; i++) pos[read()] = i;
		for (int i = 1; i <= n; i++) to[read()] = i;
		int flag = true;
		vector<pair<int, int>> ans;
		for (int i = n; i >= 1; i--) {
			if (pos[i] > to[i]) flag = false;
			for (int j = i - 1; j >= 1; j--) {
				if (pos[i] < pos[j] && pos[j] <= to[i]) {
					ans.push_back({pos[i], pos[j]});
					swap(pos[i], pos[j]);
				}
			}
		}
		if (flag) {
			cout << ans.size() << '\n';
			for (auto i : ans) cout << i.fi << ' ' << i.se << '\n';
		} else cout << -1 << '\n';
	}
	return 0;
}
