#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int M=5005;
int n,m,c,mival=2e9,tot,head[M],to[M<<1],co[M<<1],nxt[M<<1];
void add_edge(int a,int b,int c){
	to[++tot]=b;
	co[tot]=c;
	nxt[tot]=head[a];
	head[a]=tot;
}
struct node{
	int x,d;
	bool operator <(const node &A)const{
		return d>A.d;
	}
};
int dis[M];

int solve(){
	if(c<mival)return 0;
	for(int s=1;s<=n;s++){
		for(int i=1;i<=n;i++)dis[i]=-1;
		priority_queue<node>Q;
		dis[s]=0;
		Q.push((node){s,0});
		while(!Q.empty()){
			int x=Q.top().x,d=Q.top().d;
			Q.pop();
			if(d!=dis[x])continue;
			for(int i=head[x];i;i=nxt[i]){
				int y=to[i];
				int dd=d+co[i];
				if(y==s&&dd<=c)return 2;
				if(dis[y]==-1||dd<dis[y]){
					dis[y]=dd;
					Q.push((node){y,dd});
				}
			}
		}
	}
	return 1;
}
signed main(){
	scanf("%d%d%d",&n,&m,&c);
	for(int i=1;i<=m;i++){
		int a,b,c;
		scanf("%d%d%d",&a,&b,&c);
		add_edge(a,b,c);
		if(c<mival)mival=c;
	}
	printf("%d\n",solve());
	return 0;
}
