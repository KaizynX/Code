#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 1e6 + 7;
#define int ll
#define fi first
#define se second
char s[N];
vector<pair<int, int>> a;
void print() {
	for (unsigned i = 0; i < a.size(); i++) cout << a[i].fi << ',' << a[i].se << '|';
	cout << endl;
}
bool check(int k) {
	for (unsigned i = 0; i < a.size(); i++)
	if (a[i].fi == 0) {
		if (i == 0 && a[i].se + 1 > k) {
			a[i + 1].se--;
		} else if (i == a.size() - 1 && a[i].se + 1 > k) {
			if (a[i - 1].se == 0) return false;
		} else if (i != 0 && i != a.size() - 1 && (a[i].se + 1) / 2 + 1 > k) {
			if (a[i].se % 2 == 0) {
				if (a[i - 1].se == 0 || a[i + 1].se == 0) return false;
				a[i + 1].se--;
			} else {
				if (a[i - 1].se) continue;
				if (a[i + 1].se == 0) return false;
				a[i + 1].se--;
			}
		}
	}
	return true;
}
signed main() {
	ios::sync_with_stdio(0); cin.tie(0);
	int T;
	cin >> T; 
	while (T--) {
		int n; cin >> n >> s;
		int pre = s[0], cnt = 1;
		a.clear();
		for (int i = 1; i < n; i++) {
			if (pre == s[i]) {
				cnt++; 
			} else {
				a.push_back({pre - '0', cnt});
				pre = s[i];
				cnt = 1;
			}
		}
		a.push_back({pre - '0', cnt});
		int mx = 0;
		for (unsigned i = 0; i < a.size(); i++) {
			if (a[i].fi == 0) {
				if (i == 0 || i == a.size() - 1) mx = max(mx, a[i].se + 1);
				else mx = max(mx, (a[i].se + 1) / 2 + 1);
			}
		}
//		print();
//		cout << mx << endl;
		if (mx > 1 && check(mx - 1)) mx--;
		cout << mx << endl;
	}
	return 0;
}
