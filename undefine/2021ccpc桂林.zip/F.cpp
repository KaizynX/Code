#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 4e5 + 7;
#define int ll
#define fi first
#define se second
ll read() { ll x; cin >> x; return x; }
using lf = long double;
struct vec {
	lf x, y; vec() { } vec(lf x, lf y): x(x), y(y) { }
	vec operator-(const vec &b) { return vec(x - b.x, y - b.y); }
	vec operator+(const vec &b) { return vec(x + b.x, y + b.y); }
	vec operator*(lf k) { return vec(k * x, k * y); }
	lf len() { return hypot(x, y); }
	vec trunc(lf k = 1) { return *this * (k / len()); }
	friend lf cross(vec a, vec b) { return a.x * b.y - a.y * b.x; }
	friend lf cross(vec a, vec b, vec c) { return cross(a - c, b - c); }
	friend lf dot(vec a, vec b) { return a.x * b.x + a.y * b.y; }
} a[N], b[N];
lf _s[N], *s = _s + 1;
bool judge(vec a, vec b, vec c, vec d) {
	#define SJ(x) max(a.x, b.x) < min(c.x, d.x)\
		|| max(c.x, d.x) < min(a.x, b.x)
	if (SJ(x) || SJ(y)) return 0;
	#define SJ2(a, b, c, d) cross(a - b, a - c) * cross(a - b, a - d) <= 0
	return SJ2(a, b, c, d) && SJ2(c, d, a, b);
}
struct line {
	vec p1, p2;
	vec PI(line b) {
		lf t1 = cross(p1, b.p2, b.p1);
		lf t2 = cross(p2, b.p2, b.p1);
		return vec((t1 * p2.x - t2 * p1.x) / (t1 - t2),
			(t1 * p2.y - t2 * p1.y) / (t1 - t2));
	}
};
int n, m;
lf l[N];
vec yc(vec a, vec b) {
	return a + (b - a).trunc(3e9);
}
lf sum(int p1, int p2, vec A, vec B) {
	lf ans = 0;
	if (p1 < p2) ans += s[p2] - s[p1];
	else ans += s[n - 1] - s[p1] + s[p2];
	ans += l[p1] - l[p2];
	return ans - (A - a[p1]).len() + (B - a[p2]).len();
}
signed main() {
	n = read(), m = read();
	for (int i = 0; i < n; i++) a[i].x = read(), a[i].y = read();
	for (int i = 0; i < m; i++) b[i].x = read(), b[i].y = read();
	a[n] = a[0]; b[m] = b[0];
	for (int i = 0; i < n; i++) {
		l[i] = (a[i] - a[i + 1]).len();
		s[i] = s[i - 1] + l[i];
//		cout << s[i] << ' ';
	}
//	cout << endl;
	int p1 = 0, p2 = 0;
	lf ans = 0;
	for (int j = 0; j < m; j++) {
		while (!judge(a[p1], a[p1 + 1], b[j + 1], yc(b[j + 1], b[j]))) p1 = (p1 + 1) % n;
		while (!judge(a[p2], a[p2 + 1], b[j], yc(b[j], b[j + 1]))) p2 = (p2 + 1) % n;
		ans += sum(p1, p2,
			line{a[p1], a[p1 + 1]}.PI(line{b[j], b[j + 1]}),
			line{a[p2], a[p2 + 1]}.PI(line{b[j], b[j + 1]})
		) / s[n - 1] * (b[j] - b[j + 1]).len();
//		cout << j << ' ' << p1 << ' ' << p2 << ' ' << sum(p1, p2,
//			line{a[p1], a[p1 + 1]}.PI(line{b[j], b[j + 1]}),
//			line{a[p2], a[p2 + 1]}.PI(line{b[j], b[j + 1]})) << endl;
//		cout << line{a[p1], a[p1 + 1]}.PI(line{b[j], b[j + 1]}).x << ", " << line{a[p1], a[p1 + 1]}.PI(line{b[j], b[j + 1]}).y << endl;
//		cout << line{a[p2], a[p2 + 1]}.PI(line{b[j], b[j + 1]}).x << ", " << line{a[p2], a[p2 + 1]}.PI(line{b[j], b[j + 1]}).y << endl;
	}
	printf("%.12f", double(ans));
	return 0;
}
