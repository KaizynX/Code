/*
 * @Author: Kaizyn
 * @Date: 2021-05-21 13:52:57
 * @LastEditTime: 2021-05-21 15:05:35
 */
#include <bits/stdc++.h>

// #define DEBUG

using namespace std;

const double eps = 1e-7;
const double PI = acos(-1);
typedef pair<int, int> pii;
typedef long long ll;
const int MOD = 998244353; // 1e9+7;
const int INF = 0x3f3f3f3f;
// const ll INF = 1e18;
const int N = 2e5+7;

int n, m;
int a[N];

struct SegmentTree {
  struct TreeNode {
    int l, r, mx;
    pii tag;
  } tr[N<<2];
  void push_up(int i) {
    tr[i].mx = max(tr[i<<1].mx, tr[i<<1|1].mx);
  }
  void build(int l, int r, int i = 1) { 
    tr[i].l = l; tr[i].r = r; tr[i].tag = {-1, -1};
    if (l == r) {
      tr[i].mx = a[l];
      return;
    }
    int mid = (l+r)>>1;
    build(l, mid, i<<1);
    build(mid+1, r, i<<1|1);
    push_up(i);
  }
  void update_tag(int i, pii t) {
    assert(t.second >= tr[i].tag.second);
    if (tr[i].tag.first == -1) {
      tr[i].tag = t;
    } else if (t.first == tr[i].tag.second) {
      tr[i].tag.second = t.second;
    } else if (tr[i].tag.second-1 >= t.first) {
      tr[i].tag = {0, t.second};
    } else {
      tr[i].tag = {0, t.second-1};
    }
  }
  void push_tag(int i, pii t) {
    // assert(tr[i].mx <= t.first);
    if (tr[i].mx >= t.first) {
      tr[i].mx = t.second;
    } else {
      tr[i].mx = t.second-1;
    }
    update_tag(i, t);
  }
  void push_down(int i) {
    if (tr[i].tag.first == -1) return;
    push_tag(i<<1, tr[i].tag);
    push_tag(i<<1|1, tr[i].tag);
    tr[i].tag = {-1, -1};
  }
  void update(int l, int r, pii v, int i = 1) {
    if (l <= tr[i].l && r >= tr[i].r) return push_tag(i, v);
    push_down(i);
    int mid = (tr[i].l+tr[i].r)>>1;
    if (l <= mid) update(l, r, v, i<<1);
    if (r >  mid) update(l, r, v, i<<1|1);
    push_up(i);
  }
  int query_max(int l, int r, int i = 1) {
    if (l <= tr[i].l && r >= tr[i].r) return tr[i].mx;
    push_down(i);
    int mid = (tr[i].l+tr[i].r)>>1;
    if (r <= mid) return query_max(l, r, i<<1);
    if (l >  mid) return query_max(l, r, i<<1|1);
    return max(query_max(l, r, i<<1), query_max(l, r, i<<1|1));
  }
  void query(int i = 1) {
    if (tr[i].l == tr[i].r) {
      printf("%d%c", tr[i].mx, " \n"[tr[i].l == n]);
      return;
    }
    push_down(i);
    query(i<<1);
    query(i<<1|1);
  }
} tree;

signed main() {
  // freopen("0.in", "r", stdin);
  // freopen("my.out", "w", stdout);
  scanf("%d%d", &n, &m);
  for (int i = 1; i <= n; ++i) scanf("%d", a+i);
  tree.build(1, n);
  for (int i = 1, l, r; i <= m; ++i) {
    scanf("%d%d", &l, &r);
    int mx = tree.query_max(l, r);
    tree.update(l, r, {mx, mx+1});
    #ifdef DEBUG
    tree.query();
    #endif
  }
  tree.query();
  return 0;
}