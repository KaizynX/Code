/*
 * @Author: Kaizyn
 * @Date: 2021-01-06 20:48:01
 * @LastEditTime: 2021-05-21 13:52:00
 */
#include <bits/stdc++.h>

// #define DEBUG

using namespace std;

const double eps = 1e-7;
const double PI = acos(-1);
typedef pair<int, int> pii;
typedef long long ll;
const int MOD = 998244353; // 1e9+7;
const int INF = 0x3f3f3f3f;
// const ll INF = 1e18;
const int N = 2e5+10;

int n, m;
int a[N];

struct Tree {
  struct TreeNode {
    int l, r, mx, se, cnt;
    pii tag;
  } tr[N<<2];
  void push_up(int i) {
    if (tr[i<<1].mx > tr[i<<1|1].mx) {
      tr[i].mx = tr[i<<1].mx;
      tr[i].cnt = tr[i<<1].cnt;
      tr[i].se = max(tr[i<<1].se, tr[i<<1|1].mx);
    } else if (tr[i<<1].mx < tr[i<<1|1].mx) {
      tr[i].mx = tr[i<<1|1].mx;
      tr[i].cnt = tr[i<<1|1].cnt;
      tr[i].se = max(tr[i<<1|1].se, tr[i<<1].mx);
    } else {
      tr[i].mx = tr[i<<1].mx;
      tr[i].cnt = tr[i<<1].cnt+tr[i<<1|1].cnt;
      tr[i].se = max(tr[i<<1].se, tr[i<<1|1].se);
    }
  }
  void build(int l, int r, int i = 1) { 
    tr[i].l = l; tr[i].r = r; tr[i].tag = {-1, -1};
    if (l == r) {
      tr[i].mx = a[l];
      tr[i].cnt = 1;
      tr[i].se = -1;
      return;
    }
    int mid = (l+r)>>1;
    build(l, mid, i<<1);
    build(mid+1, r, i<<1|1);
    push_up(i);
  }
  void update_tag(int i, pii t) {
    if (t.first == tr[i].tag.second) {
      tr[i].tag.second = t.second;
    } else {
      tr[i].tag = t;
    }
  }
  void push_tag(int i, pii t) {
    // if (t.first == -1) return;
    assert(tr[i].mx <= t.first);
    if (tr[i].mx == t.first) {
      tr[i].mx = t.second;
      if (tr[i].se != -1) tr[i].se = tr[i].mx-1;
    } else {
      tr[i].mx = t.second-1;
      tr[i].cnt = tr[i].r-tr[i].l+1;
      tr[i].se = -1;
    }
    update_tag(i, t);
  }
  void push_down(int i) {
    if (tr[i].tag.first == -1) return;
    push_tag(i<<1, tr[i].tag);
    push_tag(i<<1|1, tr[i].tag);
    tr[i].tag = {-1, -1};
  }
  void update(int l, int r, pii v, int i = 1) {
    if (l <= tr[i].l && r >= tr[i].r) return push_tag(i, v);
    push_down(i);
    int mid = (tr[i].l+tr[i].r)>>1;
    if (l <= mid) update(l, r, v, i<<1);
    if (r >  mid) update(l, r, v, i<<1|1);
    push_up(i);
  }
  int query_max(int l, int r, int i = 1) {
    if (l <= tr[i].l && r >= tr[i].r) return tr[i].mx;
    push_down(i);
    int mid = (tr[i].l+tr[i].r)>>1;
    if (r <= mid) return query_max(l, r, i<<1);
    if (l >  mid) return query_max(l, r, i<<1|1);
    return max(query_max(l, r, i<<1), query_max(l, r, i<<1|1));
  }
  void query(int i = 1) {
    if (tr[i].l == tr[i].r) {
      printf("%d%c", tr[i].mx, " \n"[tr[i].l == n]);
      return;
    }
    push_down(i);
    query(i<<1);
    query(i<<1|1);
  }
} tree;

signed main() {
  scanf("%d%d", &n, &m);
  for (int i = 1; i <= n; ++i) scanf("%d", a+i);
  tree.build(1, n);
  for (int i = 1, l, r; i <= m; ++i) {
    scanf("%d%d", &l, &r);
    int mx = tree.query_max(l, r);
    tree.update(l, r, {mx, mx+1});
    #ifdef DEBUG
    tree.query();
    #endif
  }
  tree.query();
  return 0;
}
/*
5 3
0 0 0 0 0
1 2
1 3
1 4
*/