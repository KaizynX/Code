/*
 * @Author: Kaizyn
 * @Date: 2021-01-06 20:48:01
 * @LastEditTime: 2021-05-21 14:35:23
 */
#include <bits/stdc++.h>

// #define DEBUG

using namespace std;

const double eps = 1e-7;
const double PI = acos(-1);
typedef pair<int, int> pii;
typedef long long ll;
const int MOD = 998244353; // 1e9+7;
const int INF = 0x3f3f3f3f;
// const ll INF = 1e18;
const int N = 2e5+10;

int n, m;
int a[N];

struct SegmentTree {
#define rt tr[i]
#define ls tr[i<<1]
#define rs tr[i<<1|1]
  typedef int T;
  struct TreeNode {
    int l, r;
    T mn1, mn2, mx1, mx2, tag1, tag2, tag3;
  } tr[N<<2];
  vector<T> a;
  void push_up(int i) {
    if (ls.mn1 == rs.mn1) {
      rt.mn1 = ls.mn1;
      rt.mn2 = min(ls.mn2, rs.mn2);
    } else if (ls.mn1 < rs.mn1) {
      rt.mn1 = ls.mn1;
      rt.mn2 = min(ls.mn2, rs.mn1);
    } else if (ls.mn1 > rs.mn1) {
      rt.mn1 = rs.mn1;
      rt.mn2 = min(ls.mn1, rs.mn2);
    }
    if (ls.mx1 == rs.mx1) {
      rt.mx1 = ls.mx1;
      rt.mx2 = max(ls.mx2, rs.mx2);
    } else if (ls.mx1 > rs.mx1) {
      rt.mx1 = ls.mx1;
      rt.mx2 = max(ls.mx2, rs.mx1);
    } else if (ls.mx1 < rs.mx1) {
      rt.mx1 = rs.mx1;
      rt.mx2 = max(ls.mx1, rs.mx2);
    }
  }
  // 1 2 3 -> min, max, other
  void push_tag(int i, T add1, T add2, T add3) {
    if (rt.mn2 == rt.mx1) rt.mn2 += add2;
    else if (rt.mn2 != INF) rt.mn2 += add3;
    if (rt.mx2 == rt.mn1) rt.mx2 += add1;
    else if (rt.mx2 != -INF) rt.mx2 += add3;
    rt.mn1 += add1; rt.mx1 += add2;
    rt.tag1 += add1; rt.tag2 += add2; rt.tag3 += add3;
  }
  void push_down(int i) {
    T mn = min(ls.mn1, rs.mn1);
    T mx = max(ls.mx1, rs.mx1);
    push_tag(i<<1  , ls.mn1 == mn ? rt.tag1 : rt.tag3, ls.mx1 == mx ? rt.tag2 : rt.tag3, rt.tag3);
    push_tag(i<<1|1, rs.mn1 == mn ? rt.tag1 : rt.tag3, rs.mx1 == mx ? rt.tag2 : rt.tag3, rt.tag3);
    rt.tag1 = rt.tag2 = rt.tag3 = 0;
  }
  template <typename TT> void build(int n, TT arr[]) {
    a.resize(1);
    a.insert(a.end(), arr+1, arr+n+1);
    build(1, n, 1);
  }
  void build(int n, T val = 0) {
    a.resize(n+1, val);
    build(1, n, 1);
  }
  void build(int l, int r, int i) {
    rt.l = l; rt.r = r;
    rt.tag1 = rt.tag2 = rt.tag3 = 0;
    if (l == r) {
      rt.mn1 = rt.mx1 = a[l];
      rt.mn2 = INF; rt.mx2 = -INF;
      return;
    }
    int mid = (l+r)>>1;
    build(l, mid, i<<1); build(mid+1, r, i<<1|1);
    push_up(i);
  }
  void update_add(int l, int r, T v, int i = 1) {
    if (rt.r < l || rt.l > r) return;
    if (rt.l >= l && rt.r <= r)
      return push_tag(i, v, v, v);
    push_down(i);
    update_add(l, r, v, i<<1); update_add(l, r, v, i<<1|1);
    push_up(i);
  }
  void update_max(int l, int r, T v, int i = 1) {
    if (rt.r < l || rt.l > r || rt.mn1 >= v) return;
    if (rt.l >= l && rt.r <= r && rt.mn2 > v)
      return push_tag(i, v-rt.mn1, 0, 0);
    push_down(i);
    update_max(l, r, v, i<<1); update_max(l, r, v, i<<1|1);
    push_up(i);
  }
  T query_max(int l, int r, int i = 1) {
    if (rt.r < l || rt.l > r) return -INF;
    if (rt.l >= l && rt.r <= r) return rt.mx1;
    push_down(i);
    return max(query_max(l, r, i<<1), query_max(l, r, i<<1|1));
  }
  void query(int i = 1) {
    if (tr[i].l == tr[i].r) {
      printf("%d%c", tr[i].mx1, " \n"[tr[i].l == n]);
      return;
    }
    push_down(i);
    query(i<<1);
    query(i<<1|1);
  }
#undef rt
#undef ls
#undef rs
} tree;


signed main() {
  scanf("%d%d", &n, &m);
  for (int i = 1; i <= n; ++i) scanf("%d", a+i);
  tree.build(n, a);
  for (int i = 1, l, r; i <= m; ++i) {
    scanf("%d%d", &l, &r);
    int mx = tree.query_max(l, r);
    tree.update_add(l, r, 1);
    tree.update_max(l, r, mx);
  }
  tree.query();
  return 0;
}