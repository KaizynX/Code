#include <bits/stdc++.h>

using namespace std;

int T;
long long a, b, ans;

int main()
{
    cin >> T;
    while(T--)
    {
        ans = 0;
        cin >> a >> b;
        while(a != b)
        {
            if(a < b) swap(a, b);
            a -= b;
            ans++;
        }
        cout << ans << endl;
    }
    return 0;
}
