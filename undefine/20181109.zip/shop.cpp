#include <bits/stdc++.h>

using namespace std;

const int Maxn = 1e7+7;
const int MOD = 1e9;

int n, m, x, y;
int a[Maxn];
long long ans;

int main()
{
    freopen("shop.in", "r", stdin);
    freopen("shop.out", "w", stdout);
    cin >> n >> m >> x >> y;
    a[1] = x;
    for(int i = 2; i <= n; ++i)
        a[i] = (int)((1ll*y*a[i-1]+x)%MOD);
    nth_element(a+1, a+m+1, a+n+1);
    for(int i = 1; i <= m; ++i)
        ans += a[i];
    cout << ans << endl;
    return 0;
}
