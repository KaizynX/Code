#include <bits/stdc++.h>

using namespace std;

int T;
long long a, b, ans;

void gcd(long long a, long long b)
{
    if(!b) return;
    ans += a/b;
    gcd(b, a%b);
}

int main()
{
    freopen("sword.in", "r", stdin);
    freopen("sword.out", "w", stdout);
    cin >> T;
    while(T--)
    {
        ans = 0;
        cin >> a >> b;
        if(a < b) swap(a, b);
        gcd(a, b);
        cout << ans-1 << endl;
    }
    return 0;
}
