#include <bits/stdc++.h>

using namespace std;

const int Maxl = 50;
const int INF = 0x3f3f3f3f;

string S;
int m, ans = 1;
vector<int> p[256];

void f(vector<int> &arr)
{
    // c is center
    int num = (int)arr.size();
    for(int c = 0; c < num; ++c)
    {
        int l = c-1, r = c+1, rest = m, vl, vr;
        while(rest > 0 && (l >= 0 || r < num))
        {
            if(l < 0) vl = INF;
            else vl = (arr[c]-arr[l])-(c-l);
            if(r >= num) vr = INF;
            else vr = (arr[r]-arr[c])-(r-c);
            if(rest < min(vl, vr)) break;
            if(vl <= vr) rest -= vl, l--;
            else rest -=vr, r++;
        }
        ans = max(ans, r-l-1);
    }
}

int main()
{
    freopen("string.in", "r", stdin);
    freopen("string.out", "w", stdout);
    cin >> S >> m;
    for(int i = 0, cnt = 1; i < (int)S.length(); ++i)
    {
        p[(int)S[i]].push_back(i);
        if(i > 0 && S[i] == S[i-1]) ans = max(ans, ++cnt);
        else cnt = 1;
    }
    if(m == 0) return printf("%d\n", ans)&0;
    for(int i = 'A'; i <= 'z'; ++i) if(p[i].size())
    {
        if(m >= (int)(S.length()*S.length())) ans = max(ans, (int)p[i].size());
        else f(p[i]);
    }
    cout << ans << endl;
    return 0;
}
