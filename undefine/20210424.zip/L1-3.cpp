/*
 * @Author: Kaizyn
 * @Date: 2021-04-24 13:59:52
 * @LastEditTime: 2021-04-24 14:01:24
 */
/*
 * @Author: Kaizyn
 * @Date: 2021-04-24 13:58:49
 * @LastEditTime: 2021-04-24 13:59:27
 */
/*
 * @Author: Kaizyn
 * @Date: 2021-04-24 13:58:15
 * @LastEditTime: 2021-04-24 13:58:26
 */
/*
 * @Author: Kaizyn
 * @Date: 2021-04-24 13:41:35
 * @LastEditTime: 2021-04-24 13:43:01
 */
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
const int MOD = 998244353;
const int N = 1e6+7;

string s;

inline void solve() {
  cin >> s;
  if (s.size() == 4) {
    if (s.substr(0, 2) < "22") {
      cout << "20";
    } else {
      cout << "19";
    }
    cout << s.substr(0, 2) << '-' << s.substr(2) << '\n';
  } else {
    cout << s.substr(0, 4) << '-' << s.substr(4) << '\n';
  }
}

signed main() {
  int T = 1;
  // scanf("%d", &T);
  for (int t = 1; t <= T; ++t) {
    solve();
  }
  return 0;
}