/*
 * @Author: Kaizyn
 * @Date: 2021-04-24 13:41:35
 * @LastEditTime: 2021-04-24 16:49:26
 */
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
const int N = 1e6+7;

ll n, p;
ll dp[N];

ll mul(ll a, ll b) {
  // return a*b%p;
  __int128_t x = a;
  x *= b;
  return x%p;
}

ll qpow(ll a, ll p) {
  ll res = 1;
  while (p) {
    if (p&1) res = mul(res, a);
    a = mul(a, a);
    p >>= 1;
  }
  return res;
}

ll my_div(ll a, ll b) {
  return mul(a, qpow(b, p-2));
}

inline void solve() {
  cin >> n >> p;
  dp[1] = 0;
  ll res = n;
  for (int i = 2; i <= n; ++i) {
    int k = 0;
    dp[i] = n;
    for (int j = 1; j <= n; ++j) {
      int g = __gcd(i, j);
      if (g == i) ++k;
      else dp[i] = (dp[i]+dp[g])%p;
    }
    assert(k != n);
    dp[i] = my_div(dp[i], n-k);
    res = (res+dp[i])%p;
    cout << k << " \n"[i==n];
  }
  cout << res << '\n';
  cout << my_div(28, 12) << '\n';
  cout << my_div(res, n) << '\n';
  for (int i = 1; i <= n; ++i) cout << dp[i] << " \n"[i==n];
  cout << my_div(4, 3) << '\n';
  cout << my_div(28, 3) << '\n';
}

signed main() {
  int T = 1;
  // scanf("%d", &T);
  for (int t = 1; t <= T; ++t) {
    solve();
  }
  return 0;
}