/*
 * @Author: Kaizyn
 * @Date: 2021-04-24 14:14:47
 * @LastEditTime: 2021-04-24 14:22:02
 */
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
const int MOD = 998244353;
const int N = 1e2+7;
const int M = 1e3+7;

int n, m, sm;
vector<char> a[N], stk;

void my_pop() {
  if (stk.empty()) return;
  cout << stk.back();
  stk.pop_back();
}

inline void solve() {
  cin >> n >> m >> sm;
  for (int i = 1; i <= n; ++i) {
    a[i].resize(m);
    for (int j = 0; j < m; ++j) {
      cin >> a[i][j];
    }
    reverse(a[i].begin(), a[i].end());
  }
  for (int x; cin >> x && x != -1; ) {
    if (x == 0) {
      my_pop();
    } else {
      if (a[x].empty()) continue;
      if ((int)stk.size() == sm) my_pop();
      stk.push_back(a[x].back());
      a[x].pop_back();
    }
  }
}

signed main() {
  int T = 1;
  // scanf("%d", &T);
  for (int t = 1; t <= T; ++t) {
    solve();
  }
  return 0;
}