/*
 * @Author: Kaizyn
 * @Date: 2021-04-24 14:01:42
 * @LastEditTime: 2021-04-24 14:02:51
 */
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
const int MOD = 998244353;
const int N = 1e6+7;

int n, m;

inline void solve() {
  cin >> n >> m;
  double p;
  for (int i = 1; i <= n; ++i) {
    cin >> p;
    if (p < m) {
      printf("On Sale! %.1f\n", p);
    }
  }
}

signed main() {
  int T = 1;
  // scanf("%d", &T);
  for (int t = 1; t <= T; ++t) {
    solve();
  }
  return 0;
}