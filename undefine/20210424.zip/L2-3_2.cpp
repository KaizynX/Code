/*
 * @Author: Kaizyn
 * @Date: 2021-04-24 14:40:56
 * @LastEditTime: 2021-04-24 14:44:48
 */
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
const int MOD = 998244353;
const int N = 1e4+7;
const int M = 1e2+7;

int n, m;
map<vector<int>, int> mp;
vector<pair<int, vector<int>>> res;

inline void solve() {
  cin >> n >> m;
  vector<int> a(m);
  for (int i = 1; i <= n; ++i) {
    for (int j = 0; j < m; ++j) {
      cin >> a[j];
    }
    if (mp.find(a) == mp.end()) mp[a] = 1;
    else ++mp[a];
  }
  for (auto &p : mp) {
    res.emplace_back(-p.second, p.first);
  }
  cout << res.size() << '\n';
  sort(res.begin(), res.end());
  for (auto &p : res) {
    cout << -p.first;
    for (int &i : p.second) cout << ' ' << i;
    cout << '\n';
  }
}

signed main() {
  int T = 1;
  // scanf("%d", &T);
  for (int t = 1; t <= T; ++t) {
    solve();
  }
  return 0;
}