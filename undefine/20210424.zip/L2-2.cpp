/*
 * @Author: Kaizyn
 * @Date: 2021-04-24 13:41:35
 * @LastEditTime: 2021-04-24 16:00:50
 */
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
const int MOD = 998244353;
const int N = 1e4+7;

int n;
int dp[N], deg[N];
vector<int> e[N], re[N];

inline void solve() {
  cin >> n;
  for (int i = 0, k; i < n; ++i) {
    cin >> k;
    deg[i] = k;
    for (int j = 0, v; j < k; ++j) {
      cin >> v;
      e[i].emplace_back(v);
      re[v].emplace_back(i);
    }
  }
  queue<int> q;
  for (int i = 0; i < n; ++i) {
    if (deg[i] == 0) q.push(i);
  }
  while (q.size()) {
    int u = q.front();
    q.pop();
    for (auto &v : re[u]) {
      dp[v] = max(dp[v], dp[u]+1);
      if (--deg[v] == 0) q.push(v);
    }
  }
  int s = 0;
  for (int i = 0; i < n; ++i) {
    if (dp[i] > dp[s]) s = i;
  }
  cout << dp[s]+1 << '\n' << s;
  for (int i = s, l = dp[s]; l; --l) {
    sort(e[i].begin(), e[i].end());
    for (int &j : e[i]) {
      if (dp[j] == l-1) {
        cout << ' ' << j;
        i = j;
        break;
      }
    }
  }
  cout << '\n';
}

signed main() {
  int T = 1;
  // scanf("%d", &T);
  for (int t = 1; t <= T; ++t) {
    solve();
  }
  return 0;
}