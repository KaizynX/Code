/*
 * @Author: Kaizyn
 * @Date: 2021-04-24 13:41:35
 * @LastEditTime: 2021-04-24 14:40:10
 */
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
const int MOD = 998244353;
const int N = 1e4+7;
const int M = 1e2+7;

int n, m;
vector<int> a[N];
vector<pair<int, vector<int>>> res;

inline void solve() {
  cin >> n >> m;
  for (int i = 1; i <= n; ++i) {
    a[i].resize(m);
    for (int j = 0; j < m; ++j) {
      cin >> a[i][j];
    }
    int flag = 0;
    for (auto &p : res) {
      if (a[i] == p.second) {
        --p.first;
        flag = 1;
        break;
      }
    }
    if (!flag) res.emplace_back(-1, a[i]);
  }
  cout << res.size() << '\n';
  sort(res.begin(), res.end());
  for (auto &p : res) {
    cout << -p.first;
    for (int &i : p.second) cout << ' ' << i;
    cout << '\n';
  }
}

signed main() {
  int T = 1;
  // scanf("%d", &T);
  for (int t = 1; t <= T; ++t) {
    solve();
  }
  return 0;
}