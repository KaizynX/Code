/*
 * @Author: Kaizyn
 * @Date: 2021-04-24 14:49:16
 * @LastEditTime: 2021-04-24 15:54:06
 */
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, int> pli;
const int MOD = 998244353;
const ll INF = 1e18;
const int N = 1e5+7;

int n, m, Q;
int a[N];
ll cost[N], dc1[N], ddn[N];
set<pli> st;
vector<pii> ec[N], ed[N];
priority_queue<pli, vector<pli>, greater<pli>> q;

void dij(int s, ll d[], vector<pii> e[]) {
  memset(d+1, -1, sizeof(ll)*n);
  d[s] = 0;
  q.push({0, s});
  while (q.size()) {
    int u = q.top().second;
    ll du = q.top().first;
    q.pop();
    if (du > d[u]) continue;
    for (auto &p : e[u]) {
      int v = p.second;
      int w = p.first;
      if (~d[v] && d[v] <= du+w) continue;
      d[v] = du+w;
      q.push({d[v], v});
    }
  }
}

inline void calc(int x) {
  if (~dc1[x] && ~ddn[x]) cost[x] = dc1[x]+(ddn[x]+a[x]-1)/a[x];
  else cost[x] = INF;
}

inline void solve() {
  scanf("%d%d%d", &n, &m, &Q);
  for (int i = 1, u, v, c, d; i <= m; ++i) {
    scanf("%d%d%d%d", &u, &v, &c, &d);
    ec[u].emplace_back(c, v);
    // ec[v].emplace_back(c, u);
    // ed[u].emplace_back(d, v);
    ed[v].emplace_back(d, u);
  }
  for (int i = 1; i <= n; ++i) {
    scanf("%d", a+i);
  }
  dij(1, dc1, ec);
  // dij(1, dd1, ed);
  // dij(n, dcn, ec);
  dij(n, ddn, ed);
  for (int i = 1; i <= n; ++i) {
    calc(i);
    st.insert({cost[i], i});
  }
  for (int i = 1, x; i <= Q; ++i) {
    scanf("%d", &x);
    scanf("%d", a+x);
    st.erase({cost[x], x});
    calc(x);
    st.insert({cost[x], x});
    printf("%lld\n", st.begin()->first);
  }
}

signed main() {
  int T = 1;
  // scanf("%d", &T);
  for (int t = 1; t <= T; ++t) {
    solve();
  }
  return 0;
}