/*
 * @Author: Kaizyn
 * @Date: 2021-04-24 14:03:13
 * @LastEditTime: 2021-04-24 14:05:25
 */
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
const int MOD = 998244353;
const int N = 1e6+7;

int a[N];

inline void solve() {
  for (int i = 0; i < 24; ++i) {
    cin >> a[i];
  }
  int t;
  while (cin >> t) {
    if (t < 0 || t > 23) break;
    cout << a[t] << ' ';
    cout << (a[t] > 50 ? "Yes" : "No") << '\n';
  }
}

signed main() {
  int T = 1;
  // scanf("%d", &T);
  for (int t = 1; t <= T; ++t) {
    solve();
  }
  return 0;
}