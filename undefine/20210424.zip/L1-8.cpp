/*
 * @Author: Kaizyn
 * @Date: 2021-04-24 14:11:52
 * @LastEditTime: 2021-04-24 14:14:22
 */
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
const int MOD = 998244353;
const int N = 1e6+7;

int n, m;
int a[N];

inline void solve() {
  cin >> a[1] >> a[2] >> n;
  m = 2;
  for (int i = 1; i <= n; ++i) {
    if (m < n) {
      int b = a[i]*a[i+1];
      if (b/10) {
        a[++m] = b/10;
      }
      a[++m] = b%10;
    }
    cout << a[i] << " \n"[i==n];
  }
}

signed main() {
  int T = 1;
  // scanf("%d", &T);
  for (int t = 1; t <= T; ++t) {
    solve();
  }
  return 0;
}