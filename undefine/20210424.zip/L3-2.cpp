/*
 * @Author: Kaizyn
 * @Date: 2021-04-24 13:41:35
 * @LastEditTime: 2021-04-24 15:48:06
 */
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
const int MOD = 998244353;
const int N = 1e5+7;

int n, m;
int a[N], vis[N];
vector<int> h[N], choose[N], res;
int nex[N];

void get_next(vector<int> &s) {
  nex[0] = nex[1] = 0;
  for (int i = 1, j = 0; i < (int)s.size(); ++i) {
    while (j && s[i] != s[j]) j = nex[j];
    nex[i+1] = s[i] == s[j] ? ++j : 0;
  }
}

void kmp(int x) {
  // cout << x << "----in kmp\n"; //////////
  for (int i = 0, j = 0; i < n; ++i) {
    while (j && a[i] != h[x][j]) j = nex[j];
    if (a[i] == h[x][j]) ++j;
    if (j == (int)h[x].size()) {
      choose[i+1-h[x].size()].emplace_back(x);
      j = nex[j];
      // cout << i+1-h[x].size() << ' '; /////////
    }
  }
  // cout << "----out kmp\n";//////////
}

void dfs(int u) {
  if (u == n-1) {
    for (int i = 0; i < (int)res.size(); ++i) {
      cout << res[i] << " \n"[i==(int)res.size()-1];
    }
    exit(0);
  }
  for (auto &x : choose[u]) {
    if (vis[x]) continue;
    vis[x] = 1;
    res.emplace_back(x);
    dfs(u+h[x].size()-1);
    res.pop_back();
    vis[x] = 0;
  }
}

inline void solve() {
  cin >> n;
  for (int i = 0; i < n; ++i) cin >> a[i];
  cin >> m;
  for (int i = 1, k; i <= m; ++i) {
    cin >> k;
    h[i].resize(k);
    for (int j = 0; j < k; ++j) {
      cin >> h[i][j];
    }
    get_next(h[i]);
    kmp(i);
  }
  dfs(0);
}

signed main() {
  int T = 1;
  // scanf("%d", &T);
  for (int t = 1; t <= T; ++t) {
    solve();
  }
  return 0;
}