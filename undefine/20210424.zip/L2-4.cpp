/*
 * @Author: Kaizyn
 * @Date: 2021-04-24 13:33:29
 * @LastEditTime: 2021-04-24 13:44:18
 */
#include <bits/stdc++.h>

using namespace std;

const int N = 1e6+7;

int n, m, cd;
int res[N];
vector<int> a[N];

inline void solve() {
  cd = 0;
  for (int i = 1; i <= m; ++i) res[i] = 1;

  cin >> n >> m;
  for (int i = 1, k; i <= n; ++i) {
    cin >> k;
    a[i].resize(k);
    for (int j = 0; j < k; ++j) {
      cin >> a[i][j];
    }
  }
  int cur = 1;
  for (int i = 1, op, k; i <= m; ++i) {
    cin >> op >> k;
    if (op == 0) {
      cur = a[cur][k-1];
    } else if (op == 1) {
      cd = max(cd, k);
      res[k] = cur;
      cout << cur << '\n';
    } else {
      cd = max(cd, k);
      cur = res[k];
    }
    // cout <<  cur << " \n"[i==m];
  }
  // for (int i = 1; i <= cd; ++i) {
    // cout << res[i] << '\n';
  // }
  cout << cur << '\n';
}

signed main() {
  solve();
  return 0;
}