#include <bits/stdc++.h>

using namespace std;

int main()
{
	for(int i = 1; i <= 10; ++i)
	{
		system("rand.exe");
		system("sort.exe");
		system("spj.exe sort.in nul sort.out");
	}
	return 0;
}
