#include <bits/stdc++.h>

using namespace std;

int n, type, cnt, x;

int main()
{
	freopen("sort.in", "w", stdout);
	srand(time(NULL));
	n = rand()%1000+1;
	type = rand()%1000;
	if(type < 250) type = 1;
	else if(type < 500) type = 2;
	else if(type < 750) type = 3;
	else
	{
		type = 4;
		x = rand();
	}
	cnt = n*n/2;
	printf("%d %d %d", n, type, cnt);
	if(type == 4) printf(" %d", x);
	putchar('\n');
	return 0;
}
