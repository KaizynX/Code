#include <bit/stdc++.h>

using namespace std;

const int Maxn = 1e6+7;
const int MOD = 1e9+7;

int n, p, ans;
int col[Maxn];

int main()
{
	freopen("graph.in", "r", stdin);
	freopen("graph.out", "w", stdout);
	scanf("%d", &n);
	int flag = 1; // ���� 
	for(int i = 1; i <= n; ++i)
	{
		scanf("%d", col+i);
		if(i > 1 && col[i] != col[i-1]) flag = false;
	}
	if(flag) return puts(n&1 == p ? "1" : "0")&0;
	else puts("FuckU!");
	return 0;
}
