#include <bit/stdc++.h>

using namespace std;

const int Maxn = 1e6+7;
const int MOD = 1e9+7;

int n, p, ans;
int col[Maxn];
int f[Maxn][2][2];
// ����
// f[i][0/1][0/1] ��i����ɫΪ0/1ʱ��iΪ���pΪ0/1�ķ������� 

int main()
{
	scanf("%d", &n);
	int flag = 1;
	for(int i = 1; i <= n; ++i)
	{
		scanf("%d", col+i);
		if(i > 1 && col[i] != col[i-1]) flag = false;
	}
	if(flag) return puts(n&1 == p ? "1" : "0")&0;
	for(int i = n; i; --i)
	{
		// i��������һ��·��
		if(col[i] != 1) f[i][0][1] = 1;
		if(col[i] != 0) f[i][1][1] = 1;
		
		for(int j = i+1; j <= n; ++j)
		{
			if(col[i] != 1)
			{
				// i��ɫ0,j��ɫ1
				f[i][0][0] = (f[i][0][0]+f[j][1][1])%MOD;
				f[i][0][1] = (f[i][0][1]+f[j][1][0])%MOD;
			}
			if(col[i] != 0)
			{
				// i��ɫ1,j��ɫ0
				f[i][1][0] = (f[i][1][0]+f[j][0][1])%MOD;
				f[i][1][1] = (f[i][1][1]+f[j][0][0])%MOD;
			}
		}
		
		ans = (ans+(f[i][1][p]+f[i][0][p])%MOD)%MOD;
	}
	printf("%d\n", ans);
	return 0;
}
