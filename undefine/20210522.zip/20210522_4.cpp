/*
 * @Author: Kaizyn
 * @Date: 2021-05-22 11:25:35
 * @LastEditTime: 2021-05-22 11:56:50
 */
#include <bits/stdc++.h>

// #define DEBUG

using namespace std;

const double eps = 1e-7;
const double PI = acos(-1);
typedef pair<int, int> pii;
typedef long long ll;
const int MOD = 998244353; // 1e9+7;
const int INF = 0x3f3f3f3f;
// const ll INF = 1e18;
const int N = 5e3+7;

template <typename T = int> struct DSU {
  vector<int> fa;
  vector<T> w;
  void init(int n, T v = 1) {
    fa = vector<int>(n+1);
    iota(fa.begin(), fa.end(), 0);
    w = vector<T>(n+1, v);
  }
  void init(int n, T a[]) {
    fa = vector<int>(n+1);
    iota(fa.begin(), fa.end(), 0);
    w = vector<T>(a, a+n+1);
  }
  int get(int s) { return s == fa[s] ? s : fa[s] = get(fa[s]); }
  int& operator [] (int i) { return fa[get(i)]; }
  bool merge(int x, int y) { // merge x to y
    x = get(x); y = get(y);
    return x == y ? false : w[y] += w[x], fa[x] = y, true;
  }
};

int n, k, m;
int w[N], ideg[N], odeg[N], vis[N], tp[N];
vector<int> e[N], e2[N], tmp[N], pset;
set<int> uset;
DSU<int> dsu;
queue<int> q;
int _dfn, dfn[N], low[N], flag[N];

void print() {
  vector<int> vec;
  int num = 0;
  for (int i = 1; i <= n; ++i) {
    num += dsu[i] == i;
    tmp[dsu[i]].emplace_back(i);
  }
  for (int i = 1; i <= n; ++i) if (tmp[i].size()) {
    int flag = 0;
    for (int &j : tmp[i]) flag += uset.count(j);
    if (!flag) vec.emplace_back(tmp[i][0]);
  }
  sort(vec.begin(), vec.end());
  cout << vec.size();
  for (int &i : vec) cout << ' ' << i;
  cout << '\n' << num << '\n';
  for (int i = 1; i <= n; ++i) if (tmp[i].size()) {
    cout << tmp[i].size();
    for (int &j : tmp[i]) cout << ' ' << j;
    cout << '\n';
  }
}

void dfs(int u) {
  vis[u] = 1;
  for (int &v : e[u]) if (!vis[v]) dfs(v);
  if (odeg[u] == 1 && ideg[e[u][0]] == 1) {
    dsu.merge(u, e[u][0]);
  }
}

void tarjan(int cur, int fa = 0) {
  dfn[cur] = low[cur] = ++_dfn;
  int child = 0;
  for(auto i : e2[cur]) {
    if(!dfn[i]) {
      child++;
      tarjan(i, fa);
      low[cur] = min(low[cur], low[i]);
      if(cur != fa && low[i] >= dfn[cur]) flag[cur] = 1;
    }
    low[cur] = min(low[cur], dfn[i]);
  }
  if(cur == fa && child >= 2) flag[cur] = 1;
  // if(cur == fa) flag[cur] = 1;
}

void topu() {
  q.push(1);
  vis[1] = 1;
  for (int i = 1; q.size(); ++i) {
    int u = q.front();
    q.pop();
    tp[u] = i;
    for (int &v : e[u]) {
      if (vis[v]) continue;
      q.push(v);
      vis[v] = 1;
    }
  }
  memset(vis+1, 0, sizeof(int)*n);
}

inline void solve() {
  cin >> n;
  dsu.init(n, 1);
  for (int i = 1; i <= n; ++i) cin >> w[i];
  cin >> k;
  for (int i = 1, u; i <= k; ++i) {
    cin >> u;
    uset.insert(u);
  }
  cin >> m;
  for (int i = 1, x, y; i <= m; ++i) {
    cin >> x >> y;
    ++ideg[y];
    ++odeg[x];
    e[x].emplace_back(y);
    e2[x].emplace_back(y);
    e2[y].emplace_back(x);
  }
  topu();
  dsu.merge(1, n);
  // dfs(1);
  // memset(vis+1, 0, sizeof(int)*n);
  tarjan(1);
  #ifdef DEBUG
  for (int i = 1; i <= n; ++i) cout << dfn[i] << " \n"[i==n];
  for (int i = 1; i <= n; ++i) cout << low[i] << " \n"[i==n];
  for (int i = 1; i <= n; ++i) cout << flag[i] << " \n"[i==n];
  #endif
  flag[1] = flag[n] = 1;
  for (int s = 1; s <= n; ++s) if (flag[s]) {
    for (int t = 1; t <= n; ++t) if (tp[t] > tp[s] && flag[t]) {
      pset.clear();
      q.push(s);
      vis[s] = 1;
      while (q.size()) {
        int u = q.front();
        q.pop();
        pset.emplace_back(u);
        if (u == t) continue;
        for (int &v : e[u]) {
          if (vis[v]) continue;
          q.push(v);
          vis[v] = 1;
        }
      }
      int marked = 0;
      for (int &i : pset) {
        vis[i] = 0;
        if (i != s && i != t) marked += uset.count(i);
      }
      if (marked) continue;
      for (int &i : pset) dsu.merge(i, s);
    }
  }
  print();
}

signed main() {
#ifdef ONLINE_JUDGE
  ios::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);
#endif
  int T = 1;
  cin >> T; // scanf("%d", &T);
  for (int t = 1; t <= T; ++t) {
    solve();
    uset.clear();
    _dfn = 0;
    for (int i = 1; i <= n; ++i) {
      ideg[i] = odeg[i] = vis[i] = flag[i] = dfn[i] = 0;
      e[i].clear();
      e2[i].clear();
      tmp[i].clear();
    }
  }
  return 0;
}
/*
3

4 2 3 1 1
1 3
4
1 2
1 3
2 4
3 4

4 1 1 1 1
1 1
3
1 2
2 3
3 4

7 1 1 1 1 1 1 1
3 1 4 7
8
1 2
1 3
2 4
3 4
4 5
4 6
5 7
6 7
*/