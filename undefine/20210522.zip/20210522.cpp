/*
 * @Author: Kaizyn
 * @Date: 2021-05-22 09:50:07
 * @LastEditTime: 2021-05-22 10:09:37
 */
#include <bits/stdc++.h>

// #define DEBUG

using namespace std;

const double eps = 1e-7;
const double PI = acos(-1);
typedef pair<int, int> pii;
typedef long long ll;
const int MOD = 998244353; // 1e9+7;
const int INF = 0x3f3f3f3f;
// const ll INF = 1e18;
const int N = 5e3+7;

int n, k, m;
int w[N], u[N];
vector<int> e[N];

inline void solve() {
  cin >> n;
  for (int i = 1; i <= n; ++i) cin >> w[i];
  cin >> k;
  for (int i = 1; i <= k; ++i) cin >> u[i];
  sort(u+1, u+k+1);
  cin >> m;
  for (int i = 1, x, y; i <= m; ++i) {
    cin >> x >> y;
    e[x].emplace_back(y);
  }
  cout << n-k;
  for (int i = 1, j = 1; i <= n; ++i) {
    if (j <= k && u[j] == i) ++j;
    else cout << ' ' << i;
  }
  cout << '\n' << n-1 << '\n';
  for (int i = 2; i < n; ++i) cout << "1 " << i << '\n';
  cout << "2 1 " << n << '\n';
}

signed main() {
#ifdef ONLINE_JUDGE
  ios::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);
#endif
  int T = 1;
  cin >> T; // scanf("%d", &T);
  for (int t = 1; t <= T; ++t) {
    solve();
  }
  return 0;
}