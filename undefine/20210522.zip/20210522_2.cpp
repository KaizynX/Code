/*
 * @Author: Kaizyn
 * @Date: 2021-05-22 10:09:32
 * @LastEditTime: 2021-05-22 10:57:03
 */
#include <bits/stdc++.h>

// #define DEBUG

using namespace std;

const double eps = 1e-7;
const double PI = acos(-1);
typedef pair<int, int> pii;
typedef long long ll;
const int MOD = 998244353; // 1e9+7;
const int INF = 0x3f3f3f3f;
// const ll INF = 1e18;
const int N = 5e3+7;

template <typename T = int> struct DSU {
  vector<int> fa;
  vector<T> w;
  void init(int n, T v = 1) {
    fa = vector<int>(n+1);
    iota(fa.begin(), fa.end(), 0);
    w = vector<T>(n+1, v);
  }
  void init(int n, T a[]) {
    fa = vector<int>(n+1);
    iota(fa.begin(), fa.end(), 0);
    w = vector<T>(a, a+n+1);
  }
  int get(int s) { return s == fa[s] ? s : fa[s] = get(fa[s]); }
  int& operator [] (int i) { return fa[get(i)]; }
  bool merge(int x, int y) { // merge x to y
    x = get(x); y = get(y);
    return x == y ? false : w[y] += w[x], fa[x] = y, true;
  }
};

int n, k, m;
int w[N], u[N], ideg[N], odeg[N], vis[N];
vector<int> e[N], tmp[N];
DSU<int> dsu;

void print() {
  cout << n-k;
  for (int i = 1, j = 1; i <= n; ++i) {
    if (j <= k && u[j] == i) ++j;
    else cout << ' ' << i;
  }
  int num = 0;
  for (int i = 1; i <= n; ++i) {
    num += dsu[i] == i;
    tmp[dsu[i]].emplace_back(i);
  }
  cout << '\n' << num << '\n';
  for (int i = 1; i <= n; ++i) if (tmp[i].size()) {
    cout << tmp[i].size();
    for (int &j : tmp[i]) cout << ' ' << j;
    cout << '\n';
  }
}

void dfs(int u) {
  vis[u] = 1;
  for (int &v : e[u]) if (!vis[v]) dfs(v);
  if (odeg[u] == 1 && ideg[e[u][0]] == 1) {
    dsu.merge(u, e[u][0]);
  }
}

inline void solve() {
  cin >> n;
  dsu.init(n, 1);
  for (int i = 1; i <= n; ++i) cin >> w[i];
  cin >> k;
  for (int i = 1; i <= k; ++i) cin >> u[i];
  sort(u+1, u+k+1);
  cin >> m;
  for (int i = 1, x, y; i <= m; ++i) {
    cin >> x >> y;
    ++ideg[y];
    ++odeg[x];
    e[x].emplace_back(y);
  }
  dsu.merge(1, n);
  dfs(1);
  print();
}

signed main() {
#ifdef ONLINE_JUDGE
  ios::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);
#endif
  int T = 1;
  cin >> T; // scanf("%d", &T);
  for (int t = 1; t <= T; ++t) {
    solve();
    for (int i = 1; i <= n; ++i) {
      ideg[i] = odeg[i] = vis[i] = 0;
      e[i].clear();
      tmp[i].clear();
    }
  }
  return 0;
}
/*
2

4 2 3 1 1
1 3
4
1 2
1 3
2 4
3 4

4 1 1 1 1
1 1
3
1 2
2 3
3 4
*/