#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 10010;
#define int ll
char s[N], t[N], vis[N];
signed main() {
	int n;
	scanf("%lld", &n);
	scanf("%s", s);
	array<int, 26> A{}, ans{}; int ansp = 0;
	copy(s, s + n, t);
	
	vector<int> v;
	for (int i = 0; s[i]; i++) {
		if (!vis[s[i] - 'a']) {
			vis[s[i] - 'a'] = 1;
			v.push_back(s[i] - 'a');
		}
	}
	
	for (int i = 0; s[i]; i++) {
		fill(vis, vis + 26, 0);
		int ss = 0;
		for (int j = i; j >= 0; j--) {
			if (!vis[s[j] - 'a']) {
				vis[s[j] - 'a'] = 1;
				A[s[j] - 'a'] = ss++;
			}
		}
		int flag = 1;
		for (auto c : v)
		if (ans[c] > A[c])
			flag = 0;
		else if (ans[c] < A[c])
			break;
//		cout << i << ": ";
//		for (auto c : v) cout << c << '-' << A[c] << ' '; cout << endl;
		if (flag) ans = A, ansp = i;
	}
	for (int i = 0; i <= ansp; i++) {
		putchar(ans[s[i] - 'a'] + 'a');
	}
	return 0;
}
