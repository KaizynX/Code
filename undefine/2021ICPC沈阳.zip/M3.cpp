#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e6+5;

int sa[N], rk[N<<1], height[N];
void SA(const char *s, const int &n) {
#define cmp(x, y, w) oldrk[x] == oldrk[y] && oldrk[x+w] == oldrk[y+w]
	static int oldrk[N<<1], id[N], px[N], cnt[N], m;
	memset(cnt, 0, sizeof(int)*(m = 128));
	for (int i = 1; i <= n; ++i) ++cnt[rk[i] = s[i]];
	for (int i = 1; i <= m; ++i) cnt[i] += cnt[i-1];
	for (int i = n; i; --i) sa[cnt[rk[i]]--] = i;
	for (int w = 1, p, i; w <= n; w <<= 1, m = p) {
		for (p = 0, i = n; i > n-w; --i) id[++p] = i;
		for (i = 1; i <= n; ++i) if (sa[i] > w) id[++p] = sa[i]-w;
		memset(cnt+1, 0, sizeof(int)*m);
		for (i = 1; i <= n; ++i) ++cnt[px[i] = rk[id[i]]];
		for (i = 1; i <= m; ++i) cnt[i] += cnt[i-1];
		for (i = n; i; --i) sa[cnt[px[i]]--] = id[i];
		swap(oldrk, rk);
		for (p = 0, i = 1; i <= n; ++i) rk[sa[i]] = cmp(sa[i], sa[i-1], w) ? p : ++p;
	}
	for (int i = 1, k = 0; i <= n; ++i) {
		if (k) -- k;
		while (s[i+k] == s[sa[rk[i]-1]+k]) ++k;
		height[rk[i]] = k;
	}
#undef cmp
}

int n;
int lll[N], ans[N], vis[N];
vector<int> del[N];
char s[N];

signed main() {
	scanf("%s", s+1);
	n = strlen(s+1);
	SA(s, n);
	vector<pair<int, int>> stk;
	stk.clear();
	for (int i = 1; i <= n; ++i) {
		int mn = height[i];
		while (stk.size() && sa[stk.back().first] > sa[i]) {
			mn = min(mn, stk.back().second);
			stk.pop_back();
		}
		if (stk.size()) lll[i] = max(lll[i], mn);
		stk.push_back({i, mn});
	}
	stk.clear();
	for (int i = n; i; --i) {
		int mn = height[i+1];
		while (stk.size() && sa[stk.back().first] > sa[i]) {
			mn = min(mn, stk.back().second);
			stk.pop_back();
		}
		if (stk.size()) lll[i] = max(lll[i], mn);
		del[sa[i]+lll[i]-1].emplace_back(i);
		stk.push_back({i, mn});
	}
//	
//	for (int i = 1; i <= n; ++i) cout << lll[i] << " \n"[i==n];
//	for (int i = 1; i <= n; ++i) cout << sa[i] << " \n"[i==n];
//	for (int i = 1; i <= n; ++i) cout << rk[i] << " \n"[i==n];
//	for (int i = 1; i <= n; ++i) cout << height[i] << " \n"[i==n];
	
	for (int i = n, l = n; i; --i) {
		for (int j : del[i]) vis[j] = 1;
		while (vis[l]) --l;
		ans[i] = sa[l];
		vis[rk[i]] = 1;
	}
	for (int i = 1; i <= n; ++i) {
		printf("%d %d\n", ans[i], i);
	}
	return 0;
}		 
