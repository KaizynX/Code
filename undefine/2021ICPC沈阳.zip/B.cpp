#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int M=2e5+5;
int n,m,X[M],Y[M],Z[M],head[M],to[M<<2],nxt[M<<2],co[M<<2],tot;
int sz,val[M],mark[M],cnt[30][2];
ll ans;
void add_edge(int a,int b,int c){
	to[++tot]=b;
	co[tot]=c;
	nxt[tot]=head[a];
	head[a]=tot;
}
void dfs(int x,int f){
	mark[x]=1;
	sz++;
	for(int j=0;j<30;j++)cnt[j][val[x]>>j&1]++;
	for(int i=head[x];i;i=nxt[i]){
		int y=to[i];
		if(!mark[y]){
			val[y]=(val[x]^co[i]);
			dfs(y,x);
		}
		else if((val[x]^val[y])!=co[i])ans=-1;
	}
}
signed main(){
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		int a,b,c;
		scanf("%d%d%d",&a,&b,&c);
		X[i]=a,Y[i]=b,Z[i]=c;
		add_edge(a,b,c);
		add_edge(b,a,c);
	}
	for(int i=1;i<=n;i++)if(mark[i]==0){
		memset(cnt,0,sizeof(cnt));
		sz=0;
		dfs(i,0);
		if(ans==-1){puts("-1");return 0;}
		for(int j=0;j<30;j++)ans+=min(cnt[j][0],cnt[j][1])*(1ll<<j);
	}
	printf("%lld\n",ans);
	return 0;
}
