#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int M=4005;
const int P=998244353;
int n,sz[M],dp[M][M][2],tmp[M][2],sum[M];
vector<int>E[M];
void add(int &x,ll y){
	x+=y%P;
	if(x>=P)x-=P;
}
void dfs(int x,int f){
	dp[x][0][0]=1;
	sz[x]=1;
	for(auto y:E[x]){
		if(y==f)continue;
		dfs(y,x);
		memset(tmp,0,sizeof(tmp));
		for(int a=0;a+a<=sz[x];a++){
			for(int b=0;b+b<=sz[y];b++){
				add(tmp[a+b][0],1ll*dp[x][a][0]*dp[y][b][0]);
				add(tmp[a+b][0],1ll*dp[x][a][0]*dp[y][b][1]);
				
				add(tmp[a+b][1],1ll*dp[x][a][1]*dp[y][b][0]);
				add(tmp[a+b][1],1ll*dp[x][a][1]*dp[y][b][1]);
				add(tmp[a+b+1][1],1ll*dp[x][a][0]*dp[y][b][0]);
			}
		}
		for(int i=0;i<=n/2;i++){
			dp[x][i][0]=tmp[i][0];
			dp[x][i][1]=tmp[i][1];
		}
		sz[x]+=sz[y];
	}
}
#define mod P
ll fac[M];
signed main(){
	scanf("%d",&n);
	n*=2;
	for(int i=1;i<n;i++){
		int a,b;
		scanf("%d%d",&a,&b);
		E[a].push_back(b);
		E[b].push_back(a);
	}
	dfs(1,0);
	for(int i=0;i<=n/2;i++)sum[i]=(dp[1][i][0]+dp[1][i][1])%P;
//	for(int i=0;i<=n/2;i++)printf("%d : %d\n",i,sum[i]);
	fac[0] = 1;
	ll ans = 0;
	for (int i = 1; i < M; i ++) fac[i] = fac[i - 1] * (i * 2 - 1) % P;
	for (int i = 0; i <= n / 2; i++) {
		ans += (i % 2 == 0 ? 1 : -1) * sum[i] * fac[n / 2 - i] % mod;
//		cout << sum[i] << ' ' << fac[(n / 2 - i) * 2 - 1] << endl;
		
	}
	ans %= mod; ans += mod; ans %= mod;
	printf("%lld\n", ans);
	return 0;
}
