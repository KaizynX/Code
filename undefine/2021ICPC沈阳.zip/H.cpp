#include <bits/stdc++.h>
using namespace std;
#define int ll
typedef long long ll; typedef pair<int, int> pii;
const int N = 100010;
ll read() { ll x; scanf("%lld", &x); return x; }
#define repeat(i, a, b) for (int i = a, ib = b; i < ib; i++)
#define fi first
#define se second
vector<pii> a[N];
stack<int> stk;
int co[N], dfn[N], low[N];
bool vis[N], instk[N];
vector<int> sz;
int dcnt, n;
void dfs(int x, int fa) {
	vis[x] = instk[x] = 1; stk.push(x);
	dfn[x] = low[x] = ++dcnt;
	for (auto p : a[x])
	if (p.fi != fa) {
		if (!vis[p.fi]) dfs(p.fi, x);
		if (instk[p.fi]) low[x] = min(low[x], low[p.fi]);
	} else fa = -1;
	if (low[x] == dfn[x]) {
		int t; sz.push_back(0);
		do {
			t = stk.top();
			stk.pop();
			instk[t] = 0;
			co[t] = sz.size() - 1;
		} while (t != x);
	}
}
void getscc() {
	sz.clear();
	repeat (i, 0, n) if (!vis[i]) dfs(i, -1);
}
int ans[N];
int Size[N];
int fin = 0;
void dfs1(int x, int fa) {
	vis[x] = 1;
	Size[x] = sz[x];
	for (auto i : a[x]) if (i.fi != fa) {
		int p = i.fi;
		dfs1(p, x);
		Size[x] += Size[p] + 1;
	}
}
void dfs2(int x, int fa) {
	for (auto i : a[x]) if (i.fi != fa) {
		int p = i.fi;
		dfs2(p, x);
		if (Size[p] % 2 == 0) ans[x] = min(ans[x], i.se);
		ans[x] = min(ans[x], ans[p]);
	}
}
void shrink() {
	static vector<array<int, 3>> eset;
	getscc();
	fill(ans, ans + n, int(1e18));
	repeat (i, 0, n) {
		for (auto p : a[i]) {
			int j = p.fi;
			if (i < j && co[i] == co[j]) {
				ans[co[i]] = min(ans[co[i]], p.se);
				sz[co[i]]++;
			}
		}
//		if (sz[i] % 2 == 0) ans[co[i]] = 0;
	}
	repeat (i, 0, n)
	for (auto p : a[i])
	if (co[i] != co[p.fi])
		eset.push_back({co[i], co[p.fi], p.se});
	n = sz.size();
	repeat (i, 0, n)
		a[i].clear();
	for (auto i : eset) {
		a[i[0]].push_back({i[1], i[2]});
	}
//	repeat (i, 0, n) {
//		cout << i << ": ";////////////
//		for (auto p : a[i]) cout << p.fi << "," << p.se << ' ';
//		cout << endl;
//	}
//	cout << "Size: "; repeat (i, 0, n) cout << sz[i] << ' '; cout << endl;
	fill(vis, vis + n, 0);
	repeat (i, 0, n) if (!vis[i]) {
		dfs1(i, -1);
		if (Size[i] % 2 == 0) ans[i] = 0;
		else {
			dfs2(i, -1);
		}
		fin += ans[i];
	}
}
signed main() {
	n = read(); int m = read(), sum = 0;
	repeat (i, 0, m) {
		int x = read() - 1, y = read() - 1, w = read();
		a[x].push_back({y, w});
		a[y].push_back({x, w});
		sum += w;
	}
	shrink();
	printf("%lld\n", sum - fin);
	return 0;
}
