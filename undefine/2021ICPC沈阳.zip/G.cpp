#include<bits/stdc++.h>
using namespace std;
//#define int ll
typedef long long ll; typedef pair<int, int> pii;
const int N = 1010;
const int A = 20;

int n, m;
char s[N];
int cnt[N][A], last[A], lll[1<<A];
vector<int> ans, cur;

void dfs(int x, int p, int ch) {
	cout << x << ' ' << p << ' ' << ch << '\n';
	for (int i : cur) cout << i << ' ';
	cout << '\n';
	if (x == 0) {
		ans = max(ans, cur);
		return;
	}
	vector<int> t(A, 0);
	for (int i = 0; i < A; ++i) {
		t[i] = cnt[lll[ch^(1<<i)]][i]-cnt[p-1][i];
	}
	for (int i : t) cout << i << ' ';
	cout << '\n';
	int mx = *max_element(t.begin(), t.end());
	cur.emplace_back(mx);
	for (int i = 0; i < A; ++i) if (t[i] == mx) {
		dfs(x-1, lll[ch^(1<<i)], ch^(1<<i));
	}
	cur.pop_back();
}

signed main() {
	scanf("%d%s", &n, s+1);
	for (int i = 1; i <= n; ++i) {
		memcpy(cnt[i], cnt[i-1], sizeof cnt[i]);
		++cnt[i][s[i]-'a'];
		last[s[i]-'a'] = i;
		m |= 1<<(s[i]-'a');
	}
	for (int i = 0; i < 1<<A; ++i) {
		lll[i] = n;
		for (int j = 0; j < A; ++j) if ((i>>j)&1) {
			lll[i] = min(lll[i], last[j]);
		}
	}
//	for (int i = 1; i <= 5; ++i) cout << lll[i] << " \n"[i==5];
//	cout << m << '\n';
	dfs(__builtin_popcount(m), 1, m);
	for (int i = 0; i < (int)ans.size(); ++i) {
		cout << string(ans[i], 'a'+ans.size()-i-1);
	}
	cout << '\n';
	return 0;
}
