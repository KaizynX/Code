#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
char s[1000010];
signed main() {
	scanf("%s", s);
	ll ans = 0;
	for (int i = 0; s[i]; i++) {
		ans += (s[i] == 'e' && s[i + 1] == 'd' && s[i + 2] == 'g'
			&& s[i + 3] == 'n' && s[i + 4] == 'b');
	}
	printf("%lld\n", ans);
	return 0;
}
