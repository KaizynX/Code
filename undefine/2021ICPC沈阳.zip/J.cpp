#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int dis[11][11][11][11];
array<int,4>Q[100005];


signed main(){
	memset(dis,-1,sizeof(dis));
	int L=0,R=0;
	dis[0][0][0][0]=0;
	Q[++R]=array<int,4>{0,0,0,0};
	while(L<R){
		array<int,4>now=Q[++L];
		for(int i=0;i<4;i++)for(int j=i;j<4;j++){
			array<int,4>tmp=now;
			for(int k=i;k<=j;k++)tmp[k]=(tmp[k]+1)%10;
			if(dis[tmp[0]][tmp[1]][tmp[2]][tmp[3]]==-1){
				dis[tmp[0]][tmp[1]][tmp[2]][tmp[3]]=dis[now[0]][now[1]][now[2]][now[3]]+1;
				Q[++R]=array<int,4>{tmp[0],tmp[1],tmp[2],tmp[3]};
			}
			tmp=now;
			for(int k=i;k<=j;k++)tmp[k]=(tmp[k]+9)%10;
			if(dis[tmp[0]][tmp[1]][tmp[2]][tmp[3]]==-1){
				dis[tmp[0]][tmp[1]][tmp[2]][tmp[3]]=dis[now[0]][now[1]][now[2]][now[3]]+1;
				Q[++R]=array<int,4>{tmp[0],tmp[1],tmp[2],tmp[3]};
			}
		}
	}
	int q;
	scanf("%d",&q);
	while(q--){
		char A[5],B[5];
		scanf("%s%s",A,B);
		int a=(B[0]-A[0]+10)%10;
		int b=(B[1]-A[1]+10)%10;
		int c=(B[2]-A[2]+10)%10;
		int d=(B[3]-A[3]+10)%10;
		printf("%d\n",dis[a][b][c][d]);
	}
	return 0;
}
