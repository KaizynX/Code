#include<bits/stdc++.h>
using namespace std;
#define int ll
typedef long long ll; typedef pair<int, int> pii;
const int N = 100010;
ll read() { ll x; scanf("%lld", &x); return x; }
#define repeat(i, a, b) for (int i = a, ib = b; i < ib; i++)
#define fi first
#define se second
#define T complex<double>
#define lf double
const lf eps = 1e-9;
struct mat {
	static const int N = 3;
	vector<T> a[N];
	T det;
	void r_div(int x, int m, T k) {
		T r = T(1) / k;
		repeat (i, 0, m) a[x][i] *= r;
		det *= k;
	}
	void r_plus(int x, int y, int m, T k) {
		repeat (i, 0, m) a[x][i] += a[y][i] * k;
	}
	bool gauss(int n, int m) {
		det = 1;
		repeat (i, 0, n) {
			int t = -1;
			repeat (j, i, n) if (abs(a[j][i]) > eps) { t = j; break; }
			if (t == -1) { det = 0; return 0; }
			if (t != i) { a[i].swap(a[t]); det = -det; }
			r_div(i, m, a[i][i]);
			repeat (j, 0, n) if (j != i && abs(a[j][i]) > eps)
				r_plus(j, i, m, -a[j][i]);
		}
		return 1;
	}
} a, b;
//#define a b.a
signed main() {
	int TT = read();
	while (TT--) {
		lf x, y;
		a.a[0].assign(4, 0);
		a.a[1].assign(4, 0);
		a.a[2].assign(4, 0);
		repeat (i, 0, 3) {
			x = read(), y = read(); T z(x, y);
			x = read(), y = read(); T w(x, y);
			a.a[i][0] = z; a.a[i][1] = T(1);
			a.a[i][2] = -w; a.a[i][3] = z * w;
		}
		b = a;
		x = read(), y = read();
		T z(x, y);
		if (a.gauss(3, 4)) {
			T f = (a.a[0][3] * z + a.a[1][3]) / (z + a.a[2][3]);
			printf("%.12f %.12f\n", f.real(), f.imag());
		} else {
			repeat (i, 0, 2) b.a[i][2] = -b.a[i][2];
			b.gauss(2, 3);
			T f = (b.a[0][2] * z + b.a[1][2]);
			printf("%.12f %.12f\n", f.real(), f.imag());
		}
	}
	return 0;
}

