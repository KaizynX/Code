#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e6+5;

template <typename T, typename U = std::greater<T>>
struct ST {
	static const int NN = 31-__builtin_clz(N)+3;
	static const T INF = 1e9;
	int lg2[N];
	U cmp = U();
	T rmq[N][NN];
	ST() {
		for (int i = 2; i < N; ++i) lg2[i] = lg2[i>>1]+1;
	}
	T mv(const T &x, const T &y) { return cmp(x, y) ? x : y; }
	void build(T a[], const int &n) {
		for (int i = n; i; --i) {
			rmq[i][0] = a[i];
			for (int j = 1; j <= lg2[n-i+1]; ++j)
				rmq[i][j] = mv(rmq[i][j-1], rmq[i+(1<<(j-1))][j-1]);
		}
	}
	T query(int l, int r) {
//		if (l > r) return query(r, l);
		int k = lg2[r-l+1];
		return mv(rmq[l][k], rmq[r-(1<<k)+1][k]);
	}
};

int sa[N], rk[N<<1], height[N];
void SA(const char *s, const int &n) {
#define cmp(x, y, w) oldrk[x] == oldrk[y] && oldrk[x+w] == oldrk[y+w]
	static int oldrk[N<<1], id[N], px[N], cnt[N], m;
	memset(cnt, 0, sizeof(int)*(m = 128));
	for (int i = 1; i <= n; ++i) ++cnt[rk[i] = s[i]];
	for (int i = 1; i <= m; ++i) cnt[i] += cnt[i-1];
	for (int i = n; i; --i) sa[cnt[rk[i]]--] = i;
	for (int w = 1, p, i; w <= n; w <<= 1, m = p) {
		for (p = 0, i = n; i > n-w; --i) id[++p] = i;
		for (i = 1; i <= n; ++i) if (sa[i] > w) id[++p] = sa[i]-w;
		memset(cnt+1, 0, sizeof(int)*m);
		for (i = 1; i <= n; ++i) ++cnt[px[i] = rk[id[i]]];
		for (i = 1; i <= m; ++i) cnt[i] += cnt[i-1];
		for (i = n; i; --i) sa[cnt[px[i]]--] = id[i];
		swap(oldrk, rk);
		for (p = 0, i = 1; i <= n; ++i) rk[sa[i]] = cmp(sa[i], sa[i-1], w) ? p : ++p;
	}
	for (int i = 1, k = 0; i <= n; ++i) {
		if (k) -- k;
		while (s[i+k] == s[sa[rk[i]-1]+k]) ++k;
		height[rk[i]] = k;
	}
#undef cmp
}

int n;
int L[N], R[N], ans[N], vis[N];
vector<int> stk, del[N];
char s[N];
ST<int, less<int>> st;

int lcp(int x, int y) {
	if (x > y) swap(x, y);
	return st.query(x+1, y);
}

signed main() {
	scanf("%s", s+1);
	n = strlen(s+1);
	SA(s, n);
	st.build(height, n);
	stk.clear();
	for (int i = 1; i <= n; ++i) {
		while (stk.size() && sa[stk.back()] > sa[i]) stk.pop_back();
		if (stk.size()) L[i] = stk.back();
		stk.push_back(i);
	}
	stk.clear();
	for (int i = n; i; --i) {
		while (stk.size() && sa[stk.back()] > sa[i]) stk.pop_back();
		if (stk.size()) R[i] = stk.back();
		stk.push_back(i);
	}
	for (int i = 1; i <= n; ++i) {
		int len = 0;
		if (L[i]) len = max(len, lcp(i, L[i]));
		if (R[i]) len = max(len, lcp(i, R[i]));
		del[sa[i]+len-1].emplace_back(i);
		cout << L[i] << ' ' << R[i] << '=' << len << "\n";
	}
	
//	for (int i = 1; i <= n; ++i) cout << sa[i] << " \n"[i==n];
//	for (int i = 1; i <= n; ++i) cout << rk[i] << " \n"[i==n];
//	for (int i = 1; i <= n; ++i) cout << height[i] << " \n"[i==n];
	
	for (int i = n, l = n; i; --i) {
		for (int j : del[i]) vis[j] = 1;
		while (vis[l]) --l;
		ans[i] = sa[l];
		vis[rk[i]] = 1;
	}
	for (int i = 1; i <= n; ++i) {
		printf("%d %d\n", ans[i], i);
	}
	return 0;
}		 
