#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int M=1e6+5;
int n,A[M];
ll sum[M];
int main(){
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&A[i]);
	sort(A+1,A+1+n);
	for(int i=1;i<=n;i++)sum[i]=sum[i-1]+A[i];
	int res=0,j=1;
	for(int i=1;i<n;i++){
		if(i<n&&A[i]==A[i+1])continue;
		while(j<n&&sum[j+1]<1ll*A[i+1]*(j+1))j++;
		res=max(res,j-i);
	}
	printf("%d\n",res);
	return 0;
}
