#include <bits/stdc++.h>
using namespace std;


void solve() {
	int a, b;
	scanf("%d%d", &a, &b);
	if (a < b) {
		if ((b - a) % 2 == 1) {
			puts("1");
		} else {
			puts("2");
		}
	} else if (a > b) {
		if ((a - b) % 2 == 0) {
			puts("1");
		} else {
			puts("2");
		}
	} else {
		puts("3");
	}
}
int main() {
	int T; scanf("%d", &T);
	while (T--) {
		solve();
	}
	return 0;
}
