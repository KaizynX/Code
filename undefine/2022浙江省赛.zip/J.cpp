#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const double PI=acos(-1);
int cas,a,b,ang=0,top;
double X[10],Y[10];
double dis(double x1,double y1,double x2,double y2){
	return sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
}
void solve(double x1,double y1,double x2,double y2){
//	printf("%lf %lf %lf %lf\n",x1,y1,x2,y2);
	double d=dis(x1,y1,x2,y2);
	double len=sqrt(1-d*d/4);
	double x=(x1+x2)/2,y=(y1+y2)/2;
	double dx=y2-y1,dy=x1-x2;
	double tmp=sqrt(dx*dx+dy*dy);
	dx/=tmp,dy/=tmp;
	double X1=x+dx*len;
	double Y1=y+dy*len;
	double X2=x-dx*len;
	double Y2=y-dy*len;
//	printf("d=%lf len=%lf dx=%lf dy=%lf\n",d,len,dx,dy);
//	printf("-- %lf %lf\n",x,y);
//	printf("-- %lf %lf\n",X1,Y1);
//	printf("-- %lf %lf\n",X2,Y2);
	if(dis(0,0,X1,Y1)<dis(0,0,X2,Y2))swap(X1,X2),swap(Y1,Y2);
	X[++top]=X1;
	Y[top]=Y1;
}
void solve(int a,int b){
	solve(cos(a/180.0*PI),sin(a/180.0*PI),cos(b/180.0*PI),sin(b/180.0*PI));
}
int main(){
	while((ang+1)/180.0*PI<2*asin(sqrt(2)/4))ang++;
	scanf("%d",&cas);
	while(cas--){
		scanf("%d%d",&a,&b);
		if(a>b)b+=360;
		int flag=0;
		top=0;
		if(b-a>180)swap(a,b),flag=1,b+=360;
//		printf("a=%d b=%d flag=%d\n",a,b,flag);
		X[++top]=cos(a/180.0*PI);
		Y[top]=sin(a/180.0*PI);
		if(a==b);
		else if(b-a<=90){
			solve(a,b);
			X[++top]=cos(b/180.0*PI);
			Y[top]=sin(b/180.0*PI);
		}
		else if(b-a<=90+ang){
			solve(a,a+90);
			solve(X[top],Y[top],cos(b/180.0*PI),sin(b/180.0*PI));
			X[++top]=cos(b/180.0*PI);
			Y[top]=sin(b/180.0*PI);
		}
		else if(b-a<=180){
			solve(a,a+90);
			X[++top]=cos((a+90)/180.0*PI);
			Y[top]=sin((a+90)/180.0*PI);
			solve(X[top],Y[top],cos(b/180.0*PI),sin(b/180.0*PI));
			X[++top]=cos(b/180.0*PI);
			Y[top]=sin(b/180.0*PI);
		}
		printf("%d\n",top-1);
		if(flag==0)for(int i=1;i<=top;i++)printf("%.12lf %.12lf\n",X[i],Y[i]);
		else for(int i=top;i>=1;i--)printf("%.12lf %.12lf\n",X[i],Y[i]);
	}
	return 0;
}
