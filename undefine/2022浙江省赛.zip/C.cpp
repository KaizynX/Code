#include<bits/stdc++.h>
using namespace std;
const int M=1e5+5;
int n,m,x,A[M],B[M];
int main(){
	scanf("%d%d%d",&n,&m,&x);
	for(int i=1;i<=n;i++)scanf("%d",&A[i]);
	for(int i=1;i<=m;i++)scanf("%d",&B[i]);
	int res=0;
	for(int i=1;i<=n;i++)if(A[i]>=x)res++;
	for(int i=1;i<=m;i++)if(B[i]<=x)res++;
	printf("%d\n",res);
	return 0;
}
