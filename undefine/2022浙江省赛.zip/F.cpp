#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int M=2e5+5;
struct node{
	int id,a,b,sign,op;
};
int n,m,A[M],X[M],Y[M];
vector<pair<int,int> >vi[M];
vector<node>Q[M];
void add(ll *bit,int x,int v){
	while(x<=n)bit[x]+=v,x+=x&-x;
}
ll query(ll *bit,int x){
	int res=0;
	while(x)res+=bit[x],x-=x&-x;
	return res;
}
int L[M<<2],R[M<<2];
ll ans[M],bit[M],bit1[M],bit2[M];
int main(){
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&A[i]);
	scanf("%d",&m);
	for(int i=1;i<=m;i++){
		int a,b;
		scanf("%d%d",&a,&b);
		if(a>b)swap(a,b);
		X[i]=a,Y[i]=b;
		vi[a].push_back(make_pair(b,n+i));
		vi[b].push_back(make_pair(a,n+m+i));
		if(A[a]+1<A[b]){
			Q[b].push_back((node){i,A[a]+1,A[b]-1,+1,1});
			Q[a].push_back((node){i,A[a]+1,A[b]-1,-1,1});
		}
		if(A[a]>A[b]+1){
			Q[b].push_back((node){i,A[b]+1,A[a]-1,+1,2});
			Q[a].push_back((node){i,A[b]+1,A[a]-1,-1,2});
		}
	}
	for(int i=1;i<=n;i++)vi[i].push_back(make_pair(i,i));
	for(int i=1;i<=n;i++){
		for(auto it:vi[i])L[it.second]=query(bit,A[it.first]-1);
		add(bit,A[i],1);
	}
	memset(bit,0,sizeof(bit));
	for(int i=n;i>=1;i--){
		for(auto it:vi[i])R[it.second]=query(bit,A[it.first]-1);
		add(bit,A[i],1);
	}
	for(int i=1;i<=n;i++){
		for(auto it:Q[i]){
			if(it.op==1){
				ans[it.id]+=it.sign*query(bit1,it.b);
				ans[it.id]-=it.sign*query(bit1,it.a-1);
			}
			else{
				ans[it.id]+=it.sign*query(bit2,it.b);
				ans[it.id]-=it.sign*query(bit2,it.a-1);
			}
		}
		add(bit1,A[i],min(L[i]-1,R[i]+1)-min(L[i],R[i]));
		add(bit2,A[i],min(L[i]+1,R[i]-1)-min(L[i],R[i]));
	}
	for(int i=1;i<=m;i++){
		ans[i]+=min(L[n+i],R[n+i]+(A[X[i]]<A[Y[i]]))-min(L[X[i]],R[X[i]]);
		ans[i]+=min(L[n+m+i]+(A[Y[i]]<A[X[i]]),R[n+m+i])-min(L[Y[i]],R[Y[i]]);
	}
	ll res=0;
	for(int i=1;i<=n;i++)res+=min(L[i],R[i]);
	for(int i=1;i<=m;i++)printf("%lld\n",res+ans[i]);
//	for(int i=1;i<=n+m+m;i++)printf("%d : %d %d\n",i,L[i],R[i]);
//	printf("res=%lld\n",res);
	return 0;
}
