#include <bits/stdc++.h>
using namespace std;

const int N = 1e3 + 5;

char s[N][N];

bool check(int x, int y) {
	for (int i = 0; i < 6; i++)
	for (int j = 0; j < 6; j++) {
		if (i == 0 || i == 5 || j == 0 || j == 5
		|| (i == 1 && j == 1)
		|| (i == 1 && j == 4)
		|| (i == 4 && j == 1)
		|| (i == 4 && j == 4)) {
			if (s[x + i][y + j] != '#') return false;
		} else {
			if (s[x + i][y + j] != '.') return false;
		}
	}
	return true; 
}

int main() {
	int n, m; scanf("%d%d", &n, &m);
	for (int i = 0; i < n; i++) {
		scanf("%s", s[i]);
	}
	pair<int, int> pre = {1000000, 0};
	int c = 0, tot = 0;
	for (int i = 0; i < n - 5; i++)
	for (int j = 0; j < m - 5; j++) {
		if (check(i, j)) {
//			cout << i << ' ' << j << endl;
			if (pre == make_pair(i, j - 7)) {
				c++;
			}
			tot++;
			pre = {i, j};
		}
	}
	
	pre = {1000000, 0};
	for (int j = 0; j < m - 5; j++)
	for (int i = 0; i < n - 5; i++) {
		if (check(i, j)) {
			if (pre == make_pair(i - 7, j)) {
				c++;
			}
			pre = {i, j};
		}
	}
	
	printf("%d %d\n", c, tot - c * 2);
	return 0;
}
