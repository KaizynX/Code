#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int M=1005;
struct node{
	int id;
	double t;
	bool operator <(const node &A)const{
		return t>A.t; 
	}
};
int n,X[M],Y[M],v1,v2,mark[M];
double mi[M];
double dist(int a,int b){
	double d=sqrt(1ll*(X[a]-X[b])*(X[a]-X[b])+
		1ll*(Y[a]-Y[b])*(Y[a]-Y[b]));
	if(a==0)return d/v1;
	return min(d,3.0*v2)/v2+max(0.0,(d-3.0*v2))/v1;
}
priority_queue<node>Q;
int main(){
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d%d",&X[i],&Y[i]);
	scanf("%d%d%d%d",&X[0],&Y[0],&X[n+1],&Y[n+1]);
	scanf("%d%d",&v1,&v2);
	for(int i=0;i<=n+1;i++)mi[i]=1e18;
	Q.push((node){0,0});
	mi[0]=0;
	while(!Q.empty()){
		int id=Q.top().id;
		double t=Q.top().t;
		Q.pop();
		if(mark[id])continue;
		mark[id]=1;
		for(int i=1;i<=n+1;i++)if(i!=id){
			double tmp=t+dist(id,i);
			if(tmp<mi[i]){
				Q.push((node){i,tmp});
				mi[i]=tmp;
			}
		}
	}
	printf("%.12lf\n",mi[n+1]);
	return 0;
}
