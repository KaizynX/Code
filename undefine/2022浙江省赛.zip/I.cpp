#include <bits/stdc++.h>
using namespace std;

const int N = 2e6 + 10;

int len[N], h[N];
char s[N];
int peek[N], odd[N];

void manacher() {
	int n = strlen(s) * 2 + 1;
	for (int i = n - 1; i >= 0; i--)
		s[i + 1] = (i % 2 == 0 ? '*' : s[i / 2]);
	n++;
	s[0] = '#'; s[n++] = 0;
	len[0] = 0;
	int mx = 0, id = 0;
	for (int i = 1; i < n - 1; i++) {
		if (i < mx) len[i] = min(mx - i, len[id * 2 - i]);
		else len[i] = 1;
		while (s[i - len[i]] == s[i + len[i]]) len[i]++;
		if (len[i] + i > mx) mx = len[i] + i, id = i;
		if (i % 2 == 1) {
			h[i] = len[i] - 1;
		} else {
			h[i] = len[i] - 1;
		}
	}
}
int n;
int win[N];
bool getwin(int);
bool left(int x) {
	if (peek[x - 2] && h[x - 2] < h[x]) {
		return 1;
	} else {
		return odd[x - 1] ^ 1;
	}
}
bool right(int x) {
	if (peek[x + 2] && h[x + 2] < h[x]) {
		return 1;
	} else {
		return odd[x + 1] ^ 1;
	}
}
bool getwin(int x) {
	if (win[x] != -1) return win[x];
	if (x == 1) {
		win[x] = left(x); 
	} else if (x == n * 2 + 1) {
		win[x] = right(x); 
	} else {
		win[x] = left(x) || right(x);
	}
	return win[x];
}

void solve() {
	int q; scanf("%d%d", &n, &q); 
	scanf("%s", s);
	manacher();
//	puts(s);
	h[1] = 1e9, h[n * 2 + 1] = 1e9;
	memset(odd, -1, sizeof odd); 
	memset(win, -1, sizeof win); 
//		for (int i = 0; i <= n * 2 + 1; i++) printf("%d", h[i]);
//		puts("");
	for (int i = 1; i <= n * 2 + 1; i++) {
		if (h[i] > h[i - 1] && h[i] > h[i + 1]) {
			peek[i] = 1;
		}
		if (h[i] < h[i - 1] && h[i] < h[i + 1]) {
			odd[i] = 0;
		}
	}
	for (int i = 1; i < n * 2 + 1; i++) {
		if (peek[i] == 0 && odd[i] == -1 && odd[i - 1] != -1) {
			odd[i] = odd[i - 1] ^ 1;
		}
	}
	for (int i = n * 2; i >= 0; i--) {
		if (peek[i] == 0 && odd[i] == -1 && odd[i + 1] != -1) {
			odd[i] = odd[i + 1] ^ 1;
		}
	}
//		for (int i = 0; i <= n * 2 + 1; i++) printf("%d ", peek[i]);
//		puts("");
//		for (int i = 0; i <= n * 2 + 1; i++) printf("%d ", odd[i]);
//		puts("");
//		for (int i = 1; i < n * 2 + 1; i++)
//			if (peek[i]) printf("%d ", getwin(i));
//		puts("");
	while (q--) {
		int l, r; scanf("%d%d", &l, &r);
		int H = r - l + 1;
		int x = l + r;
//		cout << "xH: " << x << ' ' << H << endl;
		if (h[x] >= H) puts("Budada");
		else if (peek[x] == 1) {
//			cout << "peek" << endl;
			puts(getwin(x) ? "Putata" : "Budada");
		} else if (peek[x + 1] && peek[x - 1]) {
//			cout << "double peek" << endl; 
			int f = 0;
			if (H - 1 > h[x - 1]) {
				if (getwin(x - 1) == 0) f = 1;
			}
			if (H - 1 > h[x + 1]) {
				if (getwin(x + 1) == 0) f = 1;
			}
			puts(f ? "Putata" : "Budada");
		} else {
			puts(odd[x] ? "Putata" : "Budada");
		}
	}
}
int main() {
	int T; T = 1; // scanf("%d", &T);
	while (T--) {
		solve();
	}
	return 0;
}
