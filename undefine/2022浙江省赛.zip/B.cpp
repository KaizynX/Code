#include <bits/stdc++.h>
using namespace std;

const int N = 1e5 + 10;

char s[N];

int main() {
	puts("");
	return 0;
}
