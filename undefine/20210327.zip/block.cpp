/*
 * @Author: Kaizyn
 * @Date: 2021-03-27 09:22:33
 * @LastEditTime: 2021-03-27 10:58:21
 */
#include <bits/stdc++.h>

using namespace std;

const int N = 3e3+7;
const int M = N*N/2;

int n, cnt;
int nex[M][26], num[M], exist[M], jump[N][26];
string s, t;

signed main() {
#ifdef ONLINE_JUDGE
  ios::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);
  freopen("block.in", "r", stdin);
  freopen("block.out", "w", stdout);
#endif
  cin >> n >> s >> t;
  memset(jump[n], -1, sizeof(jump[n]));
  for (int i = n-1; i >= 0; --i) {
    memcpy(jump[i], jump[i+1], sizeof(jump[i]));
    jump[i][s[i]-'a'] = i;
  }
  int ans = 0;
  for (int l = 0, c; l < n; ++l) {
    for (int r = l, i = 0, p = 0; r < n; ++r, ++i) {
      c = t[r]-'a';
      if (!nex[p][c]) nex[p][c] = ++cnt;
      p = nex[p][c];
      i = jump[i][c];
      if (i == -1) break;
      if (!exist[p]) {
        ++ans;
        exist[p] = 1;
      }
    }
  }
  cout << ans << '\n';
  return 0;
}
/*
5
bcabc
bbcca

20
egebejbhcfabgegjgiig
edfbhhighajibcgfecef
*/