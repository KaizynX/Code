#include <bits/stdc++.h>

using namespace std;

const int Maxn = 1e5+7;

int n, res = 0x7fffffff;
map<int, vector<int>> p;
map<pair<int, int>, int> vis;

int main()
{
    freopen("card.in", "r", stdin);
    freopen("card.out", "w", stdout);
    cin >> n;
    for(int i = 0, a, b; i < n; ++i)
    {
        cin >> a >> b;
        if(vis.count(make_pair(a, b))) continue;
        p[a].push_back(b);
        vis.insert(make_pair(make_pair(a, b), 1));
    }
    for(map<int, vector<int>>::iterator it = p.begin(); it != p.end(); ++it)
    {
        vector<int> &v = it->second;
        sort(v.begin(), v.end());
        for(int i = 0; i < v.size(); ++i)
        {
            int pos = upper_bound(v.begin()+i, v.end(), v[i]+n-1)-v.begin();
            res = min(res, n-pos+i);
            if(pos == v.size()) break;
        }
    }
    cout << res << endl;
    return 0;
}
