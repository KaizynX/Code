#include <cstdio>
#include <iostream>
#define LL long long 

using namespace std;

const int Maxn = 40+5;

int n,num;
LL k,ans;
LL a[Maxn];

void dfs(int last, LL now)
{
	ans++;
	for(int i=last+1;i<=num;++i)
	{
		if(now+a[i]<=k)
		{
			dfs(i,now+a[i]);
		}
	}
}

int main()
{
	freopen("champion.in","r",stdin);
	freopen("champion.out","w",stdout);
	scanf("%d%lld",&n,&k);
	for(int i=1;i<=n;++i)
	{
		scanf("%lld",&a[++num]);
		if(a[num]>k)num--;
	}
	dfs(0,0);
	printf("%lld",ans);
	return 0;
}
