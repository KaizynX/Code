#include <cstdio>
#include <iostream>
#include <cstring>
using namespace std;

const int Maxn=5000+5;
const int Maxt=10+5;

int T;
string s;
int l;
bool a[Maxn];
//a[]==0  "("   a[]==1  ")"
bool pd()
{
	int cnt=0;
	for(int i=0;i<l;++i)
	{
		if(a[i]==0)cnt++;
		else if(a[i]==1)
		{
			if(cnt<=0)return 0;
			cnt--;
		}
	}
	if(cnt!=0)return 0;
	return 1;
}

void solve()
{
	l=s.length();
	//memset(a,0,sizeof a);
	for(int i=0;i<l;++i)
	{
		if(s[i]=='(')a[i]=0;
		else if(s[i]==')')a[i]=1;
	}
	if(pd()==1)
	{
		printf("possible\n");
		return;
	}
	for(int i=0;i<l;++i)
	{
		for(int j=i;j<l;++j)
		{
			for(int k=i;k<=j;++k)
			{
				a[i]=!a[i];
			}
			if(pd()==1)
			{
				printf("possible\n");
				return;
			}
			for(int k=i;k<=j;++k)
			{
				a[i]=!a[i];
			}
		}
	}
	printf("impossible\n");
	return;
}

int main()
{	
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		cin>>s;
		solve();
	}
	return 0;
}
