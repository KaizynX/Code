#include <cstdio>
#include <iostream>
#define LL long long 
using namespace std;

const int Maxn = 100000+5;

int n,k;
int a[Maxn];
LL f[Maxn];

int main()
{
	freopen("dish.in","r",stdin);
	freopen("dish.out","w",stdout);
	LL cnt,ans=0;
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;++i)
	{
		scanf("%d",a+i);
	}
	for(int i=0;i<=n-k;++i)
	{
		cnt=0;
		for(int j=1;j<=k;++j)
		{
			cnt+=a[i+j]*j;
		}
		if(cnt>ans)ans=cnt;
	}
	printf("%lld\n",ans);
	return 0;
}
