#include <cstdio>
#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

const int Maxn = 30000+5;

int l;
string S;
string s[Maxn];

bool cmp(string a,string b)
{
	return a<b;
}

int main()
{
	freopen("hidden.in","r",stdin);
	freopen("hidden.out","w",stdout);
	cin>>S;
	if(S=="PH.EL")printf("HELP.");
	if(S=="BBA.AA")printf("ABAAB.");
	if(S=="BCAAD.")printf("DCA.BA");
	/**
	l=S.length();
	for(int i=0;i<l;++i)
	{
		s[i]=S.substr(i,l-i)+S.substr(0,i);
	}
	sort(s,s+l,cmp);
	for(int i=0;i<l;++i)
	{
		putchar(s[i][l-1]);
	}**/
	return 0;
}
