#include <cstdio>
#include <cstring>
#include <iostream>

using namespace std;

const int Maxn = 1e2+7;

int k[Maxn];
string key, mi;

int main()
{
	freopen("vigenere.in", "r", stdin);
	freopen("vigenere.out", "w", stdout);
	cin >> key >> mi;
	for(int i = 0; i < key.length(); ++i)
		if(key[i] >= 'a' && key[i] <= 'z') k[i] = key[i]-'a';
		else k[i] = key[i]-'A';
	for(int i = 0, m, isup, pos, tmp; i < mi.length(); ++i)
	{
		isup = 0;
		pos = i%key.length();
		if(mi[i] >= 'a' && mi[i] <= 'z') m = mi[i]-'a';
		else isup = 1, m = mi[i]-'A';
		tmp = (m-k[pos]+26)%26;
		putchar((isup ? 'A' : 'a')+tmp);
	}
	return 0;
}
