#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>

using namespace std;

const int Maxn = 1e3+7;

int n;

struct Prime
{
	int a, b;
	bool operator < (const Prime &c) const
	{
		return a*b < c.a*c.b;
	}
} p[Maxn];

struct BigInteger
{
	const static int WIDTH = 1e4;

	int v[Maxn], len;

	BigInteger(int num = 0)
	{
		len = 0;
		memset(v, 0, sizeof v);
		do{
			v[++len] = num%WIDTH;
			num /= WIDTH;
		} while(num);
	}

	bool operator < (const BigInteger &b) const
	{
		if(len != b.len) return len < b.len;
		for(int i = len; i; --i)
			if(v[i] != b.v[i]) return v[i] < b.v[i];
		return false;
	}

	BigInteger operator * (const int b) const
	{
		BigInteger res;
		res.len = len;
		for(int i = 1; i <= len; ++i)
		{
			res.v[i] += v[i]*b;
			res.v[i+1] += res.v[i]/WIDTH;
			res.v[i] %= WIDTH;
		}
		while(res.v[res.len+1]) res.len++;
		return res;
	}

	BigInteger operator *= (const int b)
	{
		return *this = *this*b;
	}

	BigInteger operator / (const int b) const
	{
		BigInteger res;
		res.len = len;
		int now = 0;
		for(int i = len; i; --i)
		{
			now = now*WIDTH+v[i];
			res.v[i] = now/b;
			now %= b;
		}
		while(res.len > 1 && !res.v[res.len]) res.len--;
		return res;
	}
};

template <typename T> inline T max(T &a, T &b)
{
	return a < b ? b : a;
}

ostream& operator << (ostream &os, BigInteger &big)
{
	os << big.v[big.len];
	char tmp[10];
	for(int i = big.len-1; i; --i)
	{
		sprintf(tmp, "%04d", big.v[i]);
		os << tmp;
	}
	return os;
}

int main()
{
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	cin >> n;
	for(int i = 0; i <= n; ++i)
		cin >> p[i].a >> p[i].b;
	sort(p+1, p+n+1);
	BigInteger cnt = p[0].a, ans = 0;
	for(int i = 1; i <= n; ++i)
	{
		ans = max(ans, cnt/p[i].b);
		cnt *= p[i].a;
	}
	cout << ans << endl;
	return 0;
}
