#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>

using namespace std;

const int Maxn = 1e5+7;

int n, m, s, X0;
pair<int, int> res[Maxn], ans[Maxn];

struct Point
{
	int h, fir, sec;
	Point() { fir = 0; sec = 0; }
} p[Maxn];

struct Query
{
	int s, x, id;
	bool operator < (const Query &b) const
	{
		if(s == b.s) return x < b.x;
		return s < b.s;
	}
} q[Maxn];

int main()
{
	freopen("drive.in", "r", stdin);
	freopen("drive.out", "w", stdout);
	scanf("%d", &n);
	for(int i = 1; i <= n; ++i)
		scanf("%d", &p[i].h);
	scanf("%d%d", &X0, &m);
	for(int i = 1; i <= m; ++i)
	{
		scanf("%d%d", &q[i].s, &q[i].x);
		q[i].id = i;
	}
	sort(q+1, q+m+1);
	// init the fir and sec nearest point
	for(int i = 1, dis, disf, diss; i < n; ++i)
	{
		for(int j = 2; j <= n; ++j)
		{
			if(!p[i].fir)
			{
				p[i].fir = j;
				continue;
			}
			dis = abs(p[i].h - p[j].h);
			disf = abs(p[i].h - p[p[i].fir].h);
			if(!p[i].sec)
			{
				if(make_pair(dis, p[j].h) < make_pair(disf, p[p[i].fir].h))
				{
					p[i].sec = p[i].fir;
					p[i].fir = j;
				}
				else p[i].sec = j;
			}
			diss = abs(p[i].h - p[p[i].sec].h);
			if(make_pair(dis, p[j].h) < make_pair(diss, p[p[i].sec].h))
			{
				p[i].sec = j;
				if(make_pair(dis, p[j].h) < make_pair(disf, p[p[i].fir].h))
					swap(p[i].fir, p[i].sec);
			}
		}
	}
	int curq = 1;
	for(int i = 1, tmp, flag, dist, disa, disb, curp; i < n; ++i)
	{
		dist = 0; disa = 0; disb = 0;
		flag = 1; curp = i;
		while(dist < X0 || (q[curq].s == i && q[curq].x > dist))
		{
			tmp = 0;
			if(flag) // A
			{
				if(p[curp].sec)
					tmp = abs(p[curp].h-p[p[curp].sec].h);
				if(q[curq].s == i && dist+tmp > q[curq].x)
				{
					res[q[curq].id] = make_pair(disa, disb);
					curq++;
				}
				if(dist <= X0 && dist+tmp > X0)
					ans[i] = make_pair(disa, disb);
				dist += tmp;
				disa += tmp;
				curp = p[curp].sec;
			}
			else // B
			{
				if(p[curp].fir)
					tmp = abs(p[curp].h-p[p[curp].fir].h);
				if(q[curq].s == i && dist+tmp > q[curq].x)
				{
					res[q[curq].id] = make_pair(disa, disb);
					curq++;
				}
				if(dist <= X0 && dist+tmp > X0)
					ans[i] = make_pair(disa, disb);
				dist += tmp;
				disb += tmp;
				curp = p[curp].fir;
			}
			if(!curp) break;
		}
		if(dist <= X0) ans[i] = make_pair(disa, disb);
		while(q[curp].s == i)
		{
			res[q[curp].id] = make_pair(disa, disb);
			curp++;
		}
	}
	int kkk = 1;
	for(int i = 2; i <= n; ++i)
	{
		if(ans[i].second == 0)
		{
			if(ans[kkk].second == 0 && p[kkk].h < p[i].h)
				kkk = i;
		}
		else if(ans[kkk].second == 0) continue;
		else
		{
			double dkkk = ans[kkk].first/ans[kkk].second;
			double di = ans[i].first/ans[i].second;
			if(di < dkkk) kkk = i;
		}
	}
	for(int i = 1; i <= m; ++i)
		printf("%d %d\n", res[i].first, res[i].second);
	return 0;
}
